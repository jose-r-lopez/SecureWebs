﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace FileSync
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Clear();
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapMvcAttributeRoutes();
            //para que haya routing cuando se pide un fichero
            routes.RouteExistingFiles = true;

            routes.MapRoute(
             name: "Static",
             url: "FileSync/Static/view/{id}",
             defaults: new { controller = "Static", action = "Index" }
         );

            routes.MapRoute(
              name: "File",
              url: "FileSync/Files/{*catchall}",
              defaults: new { controller = "File", action = "Index" }
          );
            
            routes.MapRoute(
                name: "Default",
                url: "FileSync/{controller}/{action}/",
                defaults: new { controller = "Home", action = "Index", catchll = UrlParameter.Optional}
            );

        }
    }
}
