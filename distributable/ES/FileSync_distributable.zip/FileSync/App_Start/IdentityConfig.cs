﻿using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using FileSync.Models;
using System;
using System.Net.Mail;
using System.Configuration;
using System.Net;
using FileSync.DAL;

namespace FileSync
{
    
    public class ApplicationUserManager : UserManager<ApplicationUser>
    {
        public ApplicationUserManager(IUserStore<ApplicationUser> store)
            : base(store)
        {
        }

        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options, IOwinContext context) 
        {
            var manager = new ApplicationUserManager(new UserStore<ApplicationUser>(context.Get<FileSyncContext>()));
          
            manager.UserValidator = new UserValidator<ApplicationUser>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };
            // Configure la lógica de validación de contraseñas
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = 6,
                RequireNonLetterOrDigit = true,
                RequireDigit = true,
                RequireLowercase = true,
                RequireUppercase = true,
                
            };

            manager.UserLockoutEnabledByDefault = false;
            manager.EmailService = new EmailService();


            var dataProtectionProvider = options.DataProtectionProvider;
            if (dataProtectionProvider != null)
            {
                manager.UserTokenProvider = new DataProtectorTokenProvider<ApplicationUser>(dataProtectionProvider.Create("ASP.NET Identity"));
            }
            return manager;
        }
    }

    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            var email = new MailMessage(Convert.ToString(ConfigurationManager.AppSettings["FromMailAddress"]), message.Destination)
            {
                Subject = message.Subject,
                Body = message.Body,
                IsBodyHtml = true
            };

            var mailClient = new SmtpClient(
                Convert.ToString(ConfigurationManager.AppSettings["Host"]),
                Convert.ToInt32(ConfigurationManager.AppSettings["EmailPort"]))
            {
                UseDefaultCredentials = false,
                Credentials =
                    new NetworkCredential(
                        Convert.ToString(ConfigurationManager.AppSettings["EmailUsername"]),
                        Convert.ToString(ConfigurationManager.AppSettings["EmailPassword"])),
                EnableSsl = true
            };

            return mailClient.SendMailAsync(email);
        }
    }
}
