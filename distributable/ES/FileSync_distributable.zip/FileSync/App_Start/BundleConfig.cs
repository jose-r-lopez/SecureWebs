﻿using System.Web;
using System.Web.Optimization;

namespace FileSync
{
    public class BundleConfig
    {

        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jQuery/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jQueryVal/jquery.validate*",
                         "~/Scripts/jQueryUnobtrusive/jquery.unobtrusive*"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                "~/Scripts/jQueryUI/jquery-ui-{version}.js",
                "~/Scripts/jQueryUI/jquery.ui-contextmenu.js"));

            bundles.Add(new StyleBundle("~/Content/jQueryUI/themes/css").Include(
              "~/Content/jQueryUI/themes/base/*.css"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryupload").Include(
                       "~/Scripts/jQuery.FileUpload/jquery.iframe-transport.js",
                       "~/Scripts/jQuery.FileUpload/jquery.fileupload.js",
                       "~/Scripts/jQuery.FileUpload/jquery.fileupload-process.js"));

            bundles.Add(new StyleBundle("~/Content/anonymous/css").Include(
                      "~/Content/fileSync/anonymousStyle.css"));

            bundles.Add(new StyleBundle("~/Content/css/file").Include(
                      "~/Content/fileSync/siteStyle.css"));

            bundles.Add(new StyleBundle("~/Content/datatables/css").Include(
                     "~/Content/dataTables/jquery.dataTables.css"));

            bundles.Add(new ScriptBundle("~/bundles/datatables/js").Include(
                   "~/Scripts/dataTables/jquery.dataTables.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/fancyBox").Include(
                      "~/Scripts/fancybox/jquery.fancybox.pack.js",
                      "~/Scripts/fancybox/jquery.fancybox-buttons.js"));

            bundles.Add(new StyleBundle("~/Content/fancyBox/css").Include(
                      "~/Content/fancybox/jquery.fancybox.css",
                      "~/Content/fancybox/jquery.fancybox-buttons.css"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/shared").Include(
                      "~/Scripts/fileSync/Shared/*.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/photo").Include(
                      "~/Scripts/fileSync/Photo/*.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/deleted").Include(
                     "~/Scripts/fileSync/Deleted/*.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/sharedFile").Include(
                    "~/Scripts/fileSync/SharedFile/*.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/profile").Include(
                    "~/Scripts/fileSync/Profile/*.js"));


            bundles.Add(new ScriptBundle("~/bundles/fileSync/file/share").Include(
                    "~/Scripts/fileSync/File/Share.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/file/").Include(
                    "~/Scripts/fileSync/File/Index.js"));

            bundles.Add(new ScriptBundle("~/bundles/fileSync/file/search").Include(
                  "~/Scripts/fileSync/File/Search.js"));

            BundleTable.EnableOptimizations = true;
        }
    }
}
