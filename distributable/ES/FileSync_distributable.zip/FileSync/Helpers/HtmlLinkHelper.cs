﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc.Html;
using System.Web.Mvc;
using System.Web.Routing;

namespace FileSync.Helpers
{
    /// <summary>
    /// Helper encargado de generar enlaces HTML con la clase "current". Esto se usará en los menús para desacar el elemento seleccionado en un
    /// momento concreto.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public static class HtmlLinkHelper
    {
        /// <summary>
        /// Crea un enlace HTML con la clase current. Es una versión mejorada del ActionLink del framework.
        /// </summary>
        /// <param name="htmlHelper">Helper</param>
        /// <param name="linkText">Texto del enlace</param>
        /// <param name="actionName">Nombre del action</param>
        /// <param name="controllerName">Nombre del controlador</param>
        /// <returns>Enlace HTML (MvcHtmlString)</returns>
        public static MvcHtmlString MenuLink(this HtmlHelper htmlHelper, string linkText, string actionName, string controllerName)
        {
            string currentAction = htmlHelper.ViewContext.RouteData.GetRequiredString("action");
            string currentController = htmlHelper.ViewContext.RouteData.GetRequiredString("controller");
            if (actionName == currentAction && controllerName == currentController)
            {
                return htmlHelper.ActionLink(
                    linkText,
                    actionName,
                    controllerName,
                    null,
                    new
                    {
                        @class = "current"
                    });
            }
            return htmlHelper.ActionLink(linkText, actionName, controllerName);
        }

        /// <summary>
        /// Crea un enlace HTML con la clase current. Es una versión mejorada del RouteLink del framework.
        /// </summary>
        /// <param name="htmlHelper">Helper</param>
        /// <param name="linkText">Texto del enlace</param>
        /// <param name="controllerName">Nombre del controlador</param>
        /// <param name="routeValues">Nombre del route</param>
        /// <returns>Enlace HTML (MvcHtmlString)</returns>
        public static MvcHtmlString MenuRouteLink(this HtmlHelper htmlHelper, string linkText, string controllerName, object routeValues = null)
        {
            string currentAction = htmlHelper.ViewContext.RouteData.GetRequiredString("action");
            string currentController = htmlHelper.ViewContext.RouteData.GetRequiredString("controller");
            if (controllerName == currentController)
            {

                return htmlHelper.RouteLink(linkText, controllerName, routeValues, new
                {
                    @class = "current"
                });
            }
            return htmlHelper.RouteLink(linkText, controllerName, routeValues);
     
        }
    }
}