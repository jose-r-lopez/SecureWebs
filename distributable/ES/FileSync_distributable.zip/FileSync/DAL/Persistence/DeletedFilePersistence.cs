﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FileSync.DAL
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con los ficheros borrados.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class DeletedFilePersistence : IDeletedFilePersistence
    {
        /// <summary>
        ///  Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();

        public IList<File> getDeletedFiles(string userID){
            return (from f in fileSync.Files
                    from d in fileSync.DeletedFiles
                    where f.Id.Equals(d.FileId) && f.UserId.Equals(userID) 
                    select f).ToList();
        }

        public IList<File> getDeletedFiles(string userID,string searchText)
        {
            return (from f in fileSync.Files
                    from d in fileSync.DeletedFiles
                    where f.Id.Equals(d.FileId) && f.Filename.Contains(searchText) && f.UserId.Equals(userID)
                    select f).ToList();
        }

        public DeletedFile getDeletedFile(string userID, int fileID)
        {
            return (from f in fileSync.Files
                    from d in fileSync.DeletedFiles
                    where d.FileId.Equals(f.Id) && f.UserId.Equals(userID) && d.FileId.Equals(fileID)
                    select d).SingleOrDefault();
        }

        public void removeDeletedFile(DeletedFile dfile, File file) {
            fileSync.DeletedFiles.Remove(dfile);

        }

        public void removeDeletedFile(DeletedFile dfile)
        {
            fileSync.DeletedFiles.Remove(dfile);
            fileSync.SaveChanges();
        }

        public void createDeletedFile(int fileID, string binName)
        {
            DeletedFile deleted = new DeletedFile();
            deleted.FileId = fileID;
            deleted.BinName = binName;

            //fileSync.DeletedFiles.Attach(deleted);
            fileSync.Entry(deleted).State = EntityState.Added;
           
            //fileSync.DeletedFiles.Add(deleted);
            fileSync.SaveChanges();

        }
          
    }
}