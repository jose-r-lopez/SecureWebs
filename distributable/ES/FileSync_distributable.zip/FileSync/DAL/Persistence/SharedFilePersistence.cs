﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using System.Collections.Generic;
using System.Linq;

namespace FileSync.DAL.Persistence
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con los ficheros compartidos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class SharedFilePersistence : ISharedFilePersistence
    {
        /// <summary>
        /// Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();

        public SharedFile getSharedFile(int fileID, string userID) {
            return (from d in fileSync.SharedFiles.Include("File")
                    where d.Id.Equals(fileID) && d.ShareUserId.Equals(userID)
                    select d).SingleOrDefault();
        }
 

        public SharedFile getSharedFileFromNotification(int notificationID) {
            return (from s in fileSync.SharedFiles.Include("File")
                    where s.Notification.Id.Equals(notificationID)
                    select s).SingleOrDefault();
        }


        public IList<SharedFile> getApprovedSharedFiles(string userID) {
            return (from s in fileSync.SharedFiles.Include("File").Include("User")
                    where s.ShareUserId.Equals(userID) && s.Approved
                    select s).ToList();
        }

         public List<SharedFile> getApprovedSharedFilesFromSameUser(int fileID, string userID) {
                 return (from s in fileSync.SharedFiles.Include("File")
                        where s.FileId.Equals(fileID) && s.UserId.Equals(userID) && s.Approved
                        select s).ToList();
         }

         public IList<SharedFile> getApprovedSharedFiles(string userID, string name)
         {
             return (from s in fileSync.SharedFiles.Include("File")
                     where s.ShareUserId.Equals(userID) && s.File.Filename.Contains(name) && s.Approved
                     select s).ToList();
         }


         public SharedFile getApproveSharedFile(int fileID, string userID)
         {
             return (from s in fileSync.SharedFiles.Include("File")
                    where s.Id.Equals(fileID) && s.ShareUserId.Equals(userID) && s.Approved
                    select s).SingleOrDefault();
             
         }

        public void createSharedFile(bool approved, int fileID, string userID, string sharedUserID, Notification notification) {
            SharedFile sharedFile = new SharedFile();
            sharedFile.Approved = approved;
            sharedFile.FileId = fileID;
            sharedFile.ShareUserId = sharedUserID;
            sharedFile.UserId = userID;
            sharedFile.Notification = notification;
            
            fileSync.SharedFiles.Add(sharedFile);
            fileSync.SaveChanges();
        }

        public bool existsSharedFile(string userID, string shareUserID, int shareFileID) {
            return (from u in fileSync.SharedFiles.Include("File")
                    where u.ShareUserId.Equals(shareUserID) && u.UserId.Equals(userID) && u.FileId == shareFileID
                    select u).Any();
        }

        public void removeSharedFileFromNotification(int notificationID) {
            SharedFile file = getSharedFileFromNotification(notificationID);
            fileSync.Notifications.Remove(file.Notification);
            fileSync.SharedFiles.Remove(file);
            fileSync.SaveChanges();
        }

        public void removeSharedFile(SharedFile file)
        {
            fileSync.SharedFiles.Remove(file);
            fileSync.SaveChanges();

        }

        public void approveSharedFile(SharedFile file)
        {
            file.Approved = true;
            fileSync.SaveChanges();
        }

        public void createShareWithNotificacion(Notification notification, SharedFile sharedFile)
        {
            fileSync.Notifications.Add(notification);
            fileSync.SharedFiles.Add(sharedFile);
            fileSync.SaveChanges();
        }
    }
}
