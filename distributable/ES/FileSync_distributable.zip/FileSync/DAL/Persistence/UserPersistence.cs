﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using FileSync.Models.ViewModels;
using System;
using System.Linq;

namespace FileSync.DAL.Persistence
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con los usuarios.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class UserPersistence : IUserPersistence
    {
        /// <summary>
        /// Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();

        public ApplicationUser getUser(string userID) {
            return (from d in fileSync.Users
                    where d.Id.Equals(userID)
                    select d).SingleOrDefault();
        }

        public UserDetails getUserDetails(string email)
        { 
            return (from u in fileSync.Users
                    where u.Email.Equals(email)
                    select new UserDetails
                    {
                        email = u.Email,
                        realname = u.Realname,
                        surname = u.Surname
                    }).SingleOrDefault();
        }

        public string getUserIDFromEmail(string email) {
            return (from u in fileSync.Users
                    where u.Email.Equals(email)
                    select u.Id).SingleOrDefault();
        }

        public int setUserCompleteName(string userID, string name, string surname) {
            var user = getUser(userID);
            if (user != null)
            {
                user.Surname = surname;
                user.Realname = name;
                return fileSync.SaveChanges();
            }
            else
                return 0;
        }

        public void addUserStorage(string userID, double storage) {
            ApplicationUser user = getUser(userID);
            user.Storage += storage;
            fileSync.SaveChanges();
        }

        public void subtractUserStorage(string userID, double storage)
        {
            ApplicationUser user = getUser(userID);
            user.Storage -= storage;
            fileSync.SaveChanges();
        }

        public string getEmailFromUser(string userID) { 
            return (from u in fileSync.Users
                    where u.Id.Equals(userID)
                        select u.Email).SingleOrDefault();
        }
    }
}