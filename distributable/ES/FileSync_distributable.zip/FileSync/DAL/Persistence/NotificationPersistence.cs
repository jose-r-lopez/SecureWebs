﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileSync.DAL.Persistence
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con las notificaciones.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class NotificationPersistence : INotificationPersistence
    {
        /// <summary>
        /// Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();

        public List<Notification> getReceivedNotifications(string UserID) {
            return (from n in fileSync.Notifications
                    where n.ReceiverId.Equals(UserID)
                    select n).ToList();
        }

        public Notification createNotification(string senderID, string receiverID, string notificationText, bool onlyNotification) {
            Notification notification = new Notification();
            notification.SenderId = senderID;
            notification.ReceiverId = receiverID;
            notification.Text = notificationText;
            notification.onlyNotification = onlyNotification;
            fileSync.Notifications.Add(notification);
            fileSync.SaveChanges();
            return notification;
        }

        /*public Notification createNotification(string senderID, string receiverID, string notificationText, bool onlyNotification)
        {
            Notification notification = new Notification();
            notification.SenderId = senderID;
            notification.ReceiverId = receiverID;
            notification.Text = notificationText;
            notification.onlyNotification = onlyNotification;
            fileSync.Notifications.Add(notification);
            fileSync.SaveChanges();
            return notification;
        }*/

        public Notification getNotification(int notificationID){
            return (from n in fileSync.Notifications
                    where n.Id.Equals(notificationID)
                    select n).SingleOrDefault();
        }

        public void removeNotification(int notificationID)
        {
            fileSync.Notifications.Remove(getNotification(notificationID));
            fileSync.SaveChanges();
        }

        public void deleteNotification(int notificationID) {
            Notification rejectedNotification = (from n in fileSync.Notifications
                                                 where n.Id.Equals(notificationID)
                                                 select n).SingleOrDefault();
            fileSync.Notifications.Remove(rejectedNotification);
            fileSync.SaveChanges();
        }

        public int getNumberOfReceivedNotifications(string userID)
        {
           return (from n in fileSync.Notifications
                   where n.ReceiverId.Equals(userID)
                   select n).Count();
        }
    }
}