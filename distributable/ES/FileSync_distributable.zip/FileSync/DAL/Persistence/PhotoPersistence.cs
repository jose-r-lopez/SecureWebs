﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace FileSync.DAL.Persistence
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con las fotos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class PhotoPersistence : IPhotoPersistence
    {
        /// <summary>
        /// Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();

        public IList<File> getFotos(string userID) {

            var photos = (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.Type.StartsWith("image") && d.Deleted == false
                    select d).ToList();

            photos.ForEach(t => fileSync.Entry(t).Reload());
            return photos;
        }

        public File getPhoto(string userID, int photoID) {
            
            return  (from d in fileSync.Files
                     where d.UserId.Equals(userID) && d.Id == photoID & d.Type.StartsWith("image") && d.Deleted == false
                    select d).SingleOrDefault();
        }
    }
}