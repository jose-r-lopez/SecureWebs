﻿using FileSync.DAL.Persistence.interfaces;
using FileSync.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FileSync.DAL
{
    /// <summary>
    /// Clase que implementa la persistencia relacionada con los ficheros.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class FilePersistence : IFilePersistence
    {
        /// <summary>
        /// Instancia de FileSyncContext, permite el acceso a la base de datos.
        /// </summary>
        private FileSyncContext fileSync = new FileSyncContext();


        public File getDeletedFile(string userID, int fileID)
        {
            return (from f in fileSync.Files
                    where f.Id.Equals(fileID) && f.UserId.Equals(userID) && f.Deleted == true
                    select f).SingleOrDefault();
        }

        public File getNotDeletedFile(string userID, int fileID)
        {
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.Id == fileID && d.Deleted == false
                    select d).SingleOrDefault();
        }

        public File getNotDeletedFile(string userID, string parent, string name)
        {
            return (from f in fileSync.Files
                    where f.UserId.Equals(userID) && f.ParentPath.Equals(parent) && f.Filename.Equals(name) && f.Deleted == false
                    select f).SingleOrDefault();
        }

        public List<File> getNotDeletedFiles(string userID, string parent)
        {
              return (from d in fileSync.Files
                      where d.UserId.Equals(userID) && d.ParentPath.Equals(parent) && d.Deleted == false
                      select d).ToList();

        }

        public List<File> getFilesByName(string userID, string name)
        {
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.Filename.Contains(name) && d.Deleted == false
                    select d).ToList();
        }

        public List<File> getFolders(string userID,string parentPath){
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.IsFolder == true && d.ParentPath.Equals(parentPath) && d.Deleted == false
                    select d).ToList();
        }

        public File getFolder(string userID, int fileID)
        {
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.Id == (fileID) && d.Deleted == false && d.IsFolder
                    select d).SingleOrDefault();
        }

        public void removeFile(File file) {
            fileSync.Files.Remove(file);
            fileSync.SaveChanges();
        }

        public List<File> getFiles(string userID, string parent)
        {
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.ParentPath.Equals(parent)
                    select d).ToList();
        }

        public List<File> getDeletedFiles(string userID, string parent)
        {
            return (from d in fileSync.Files
                    where d.UserId.Equals(userID) && d.ParentPath.Equals(parent) && d.Deleted == true
                    select d).ToList();
        }

        public void changeDeletedState(File file, bool state){
            file.Deleted = state;
            fileSync.SaveChanges();
        }

        public File createFile(string name, string parentPath, bool isFolder, string contentType, string userID, string Icon, int size)
        {
            File file = new File();
            file.Filename = name;
            file.IsFolder = isFolder;
            file.ParentPath = parentPath;
            file.Type = contentType;
            file.Deleted = false;
            file.UserId = userID;
            file.Icon = Icon;
            file.size = size;
            file.uploadDate = DateTime.Now;
            fileSync.Files.Add(file);
            fileSync.SaveChanges();
            return file;
        }

        public void changeParentPath(File file, string newParentPath)
        {
            file.ParentPath = newParentPath;
            fileSync.SaveChanges();
        }

        public File changeDeletedState(string userID, int fileID, bool state)
        {
            File fileQuery = getFile(userID, fileID);

            fileQuery.Deleted = state;
            fileSync.SaveChanges();
            return fileQuery;
        }

        public void changeFileName(string userID, int fileID, string newname)
        {
            File file = getNotDeletedFile(userID, fileID);
            file.Filename = newname;
            fileSync.SaveChanges();
        }

        public void updateFolderSize(string folderParentPath, string folderName, int size, string userID){
            File folder = getNotDeletedFile(userID, folderParentPath, folderName);
            folder.size += size;
            fileSync.SaveChanges();
        }

        private File getFile(string userID, int fileID)
        {
            return (from f in fileSync.Files
                    where f.Id.Equals(fileID) && f.UserId.Equals(userID) 
                    select f).SingleOrDefault();
        }
    }
}
