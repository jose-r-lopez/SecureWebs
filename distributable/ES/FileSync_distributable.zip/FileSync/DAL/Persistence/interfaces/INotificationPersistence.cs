﻿using FileSync.Models;
using System.Collections.Generic;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de la clase que gestiona la persistencia de las notificaciones
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface INotificationPersistence
    {
        /// <summary>
        /// Obtiene todas las notificaciones recibidas por un usuario.
        /// </summary>
        /// <param name="UserID">Id del usuario</param>
        /// <returns>Lista de notificaciones de un usuario</returns>
         List<Notification> getReceivedNotifications(string UserID);

        /// <summary>
        /// Borra una notificación
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        void deleteNotification(int notificationID);

        /// <summary>
        /// Obtiene el número de notificaciones recibidas por un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Número de notificaciones recibidas.</returns>
        int getNumberOfReceivedNotifications(string userID);

        /// <summary>
        /// Guarda una notificación en la base de datos.
        /// </summary>
        /// <param name="senderID">Id del usuario que envía la notificación</param>
        /// <param name="receiverID">Id del usuario que recibe la notificación</param>
        /// <param name="notificationText">Texto de la notificación</param>
        /// <param name="onlyNotification">Indica si corresponde a un fichero compartido(true) o no (false)</param>
        /// <returns></returns>
        Notification createNotification(string senderID, string receiverID, string notificationText, bool onlyNotification);

        /// <summary>
        /// Borra una notificación.
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        void removeNotification(int notificationID);

        /// <summary>
        /// Obtiene una notificación por su id.
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        /// <returns>Notificación</returns>
        Notification getNotification(int notificationID);
    }
}