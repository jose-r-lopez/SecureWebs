﻿using FileSync.Models;
using FileSync.Models.ViewModels;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de la clase que gestiona la persistencia de los usuarios.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IUserPersistence
    {
        /// <summary>
        /// Obtiene un usuario por su id.
        /// </summary>
        /// <param name="id">Id del usuario</param>
        /// <returns>Usuario del sistema.</returns>
        ApplicationUser getUser(string id);

        /// <summary>
        /// Cambia el nombre y los apellidos de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="name">Nuevo nombre</param>
        /// <param name="surname">Nuevo apellido</param>
        /// <returns>Número de filas cambiadas en la base de datos.</returns>
        int setUserCompleteName(string userID, string name, string surname);

        /// <summary>
        /// Obtiene el id de un usuario según su email.
        /// </summary>
        /// <param name="email">Email del usuario</param>
        /// <returns>Id del usuario</returns>
        string getUserIDFromEmail(string email);

        /// <summary>
        /// Añade al almacenamiento usado por el usuario una cantidad en megabytes.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="storage">Cantidad a añadir al almacenamiento</param>
        void addUserStorage(string userID, double storage);

        /// <summary>
        /// Resta al almacenamiento usado por el usuario una cantidad en megabytes.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="storage">Cantidad a restar al almacenamiento</param>
        void subtractUserStorage(string userID, double storage);

        /// <summary>
        /// Obtiene el email de un usuario según su id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Email del usuario</returns>
        string getEmailFromUser(string userID);

        /// <summary>
        /// Obtiene los detalles (UserDetails) de un usuario según su id.
        /// </summary>
        /// <param name="email">Email del usuario</param>
        /// <returns>Objeto UserDetails</returns>
        UserDetails getUserDetails(string email);
    }
}