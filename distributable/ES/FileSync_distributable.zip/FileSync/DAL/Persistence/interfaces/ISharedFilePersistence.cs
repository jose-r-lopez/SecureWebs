﻿using FileSync.Models;
using System.Collections.Generic;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de la clase que gestiona la persistencia de los ficheros compartidos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface ISharedFilePersistence
    {
        /// <summary>
        /// Obtiene un fichero compartido según su id.
        /// </summary>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Entidad SharedFile con los datos de la compartición</returns>
        SharedFile getSharedFile(int fileID, string userID);

        /// <summary>
        /// Comprueba si existe una comaprtición entre dos usuarios del mismo fichero.
        /// </summary>
        /// <param name="userID">Id del usuario propietario</param>
        /// <param name="shareUserID">Id del usuario con el que se desea compartir.</param>
        /// <param name="shareFileID">Id del fichero a compartir.</param>
        /// <returns>True si existe compartición, false en caso contrario</returns>
        bool existsSharedFile(string userID, string shareUserID, int shareFileID);

        /// <summary>
        /// Crea y guarda la entidad SharedFile en la base de datos.
        /// </summary>
        /// <param name="approved">Boolean que indica si está aprobada la compartición</param>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario propietario del fichero</param>
        /// <param name="sharedUserID">Id del usuario con el que se desea compartir.</param>
        /// <param name="notification">Notificación asociada a la compartición.</param>
        void createSharedFile(bool approved, int fileID, string userID, string sharedUserID, Notification notification);

        /// <summary>
        /// Obtiene todas las comparticiones (SharedFile) de un usuario que ha aprobado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista de ficheros compartidos.</returns>
        IList<SharedFile> getApprovedSharedFiles(string userID);

        /// <summary>
        /// Obtiene la entidad SharedFile a partir del id de la notificación asociada.
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        /// <returns>Entidad SharedFile asociada a la notificación</returns>
        SharedFile getSharedFileFromNotification(int notificationID);

        /// <summary>
        /// Borra un fichero compartido que debe ser obtenido por el id de la notificación asociada.
        /// </summary>
        /// <param name="notificationID">Id de la notificación.</param>
        void removeSharedFileFromNotification(int notificationID);
        
        /// <summary>
        /// Obtiene todos las entidades SharedFile que han sido aprobados por los usuarios y cuyo propietario es el mismo.
        /// </summary>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario propietario de los ficheros.</param>
        /// <returns>Lista de ficheros compartidos.</returns>
        List<SharedFile> getApprovedSharedFilesFromSameUser(int fileID, string userID);

        /// <summary>
        /// Borra una compartición.
        /// </summary>
        /// <param name="file">fichero compartido a borrar.</param>
        void removeSharedFile(SharedFile file);

        /// <summary>
        /// Obtiene un fichero compartido por id que haya sido aprobado.
        /// </summary>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Fichero compartido o null en caso de que no exista.</returns>
        SharedFile getApproveSharedFile(int fileID, string userID);

        /// <summary>
        /// Aprueba un fichero compartido.
        /// </summary>
        /// <param name="file">Fichero compartido cuyo estado pasa a aprobado.</param>
        void approveSharedFile(SharedFile file);

        /// <summary>
        /// Obtiene todas las comparticiones aprobadas por el usuario cuyo nombre de fichero contenga el texto que se pasa como parámetro.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="name">Texto que debe contener el nombre</param>
        /// <returns>Lista de ficheros compartidos. </returns>
        IList<SharedFile> getApprovedSharedFiles(string userID, string name);

        /// <summary>
        /// Crea y guarda una entidad SharedFile junto con su notificación asociada.
        /// </summary>
        /// <param name="notification">Notificación de compartición.</param>
        /// <param name="sharedFile">Entidad que representa una notificación</param>
        void createShareWithNotificacion(Notification notification, SharedFile sharedFile);
    }
}