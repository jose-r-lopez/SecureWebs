﻿using FileSync.Models;
using System.Collections.Generic;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de la clase que gestiona la persistencia de los ficheros borrados
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IFilePersistence
    {
        /// <summary>
        /// Obtiene una entidad File marcada como borrada.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Entidad File marcada como borrada</returns>
        File getDeletedFile(string userID, int fileID);
        
        /// <summary>
        /// Marca un fichero como borrado.
        /// </summary>
        /// <param name="file">Fichero a borrar</param>
        void removeFile(File file);

        /// <summary>
        /// Cambia el estado de un fichero. El estado indica si está borrado o no, true si lo está false en caso contrario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="state">Nuevo estado del fichero</param>
        /// <returns>Entidad file con el estado cambiado.</returns>
        File changeDeletedState(string userID, int fileID, bool state);

        /// <summary>
        /// Obtiene todos los ficheros de un usuario que se encuentren en un path determinado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parent">Path de los ficheros.</param>
        /// <returns>Lista de ficheros(File)</returns>
        List<File> getFiles(string userID, string parent);

        /// <summary>
        /// Obtiene todos los ficheros (File) de un path determinado que han sido marcados como borrados.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parent">Path de los ficheros</param>
        /// <returns>Lista de ficheros</returns>
        List<File> getDeletedFiles(string userID, string parent);

        /// <summary>
        /// Cambia el estado de un fichero.El estado indica si está borrado o no, true si lo está false en caso contrario.
        /// </summary>
        /// <param name="file">Fichero cuyo estado se debe de cambiar</param>
        /// <param name="state">Nuevo estado</param>
        void changeDeletedState(File file, bool state);

        /// <summary>
        /// Obtiene todos los ficheros, de un path concreto, que no han sido marcados como borrados.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parent">Path de los ficheros</param>
        /// <returns>Lista de ficheros no eliminados</returns>
        List<File> getNotDeletedFiles(string userID, string parent);

        /// <summary>
        /// Obtiene un fichero por nombre y path. Su estado debe de ser no eliminado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parent">Path del fichero</param>
        /// <param name="name">Nombre del fichero</param>
        /// <returns>Fichero no eliminado cuyo nombre y path es el de los parámetros, null si no existe.</returns>
        File getNotDeletedFile(string userID, string parent, string name);

        /// <summary>
        /// Cambia el nombre a un fichero.
        /// </summary>
        /// <param name="file">Fichero cuyo nombre de ser cambiado</param>
        /// <param name="newName">Nuevo nombre</param>
        void changeFileName(string userID, int fileID, string newname);

        /// <summary>
        /// Obtiene todos los ficheros de tipo carpeta y de un path concreto. 
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parentPath">Path de los ficheros</param>
        /// <returns>Lista de ficheros de tipo carpeta.</returns>
        List<File> getFolders(string userID, string parentPath);

        /// <summary>
        /// Obtiene un fichero de tipo carpeta por id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Fichero de tipo carpeta, null si no existe.</returns>
        File getFolder(string userID, int fileID);

        /// <summary>
        /// Obtiene un fichero (no borrado) por id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Devuelve un fichero no borrado.</returns>
        File getNotDeletedFile(string userID, int fileID);

        /// <summary>
        /// Cambia el path de un fichero.
        /// </summary>
        /// <param name="file">Fichero cuyo path debe ser cambiado</param>
        /// <param name="newParentPath">Nuevo path</param>
        void changeParentPath(File file, string newParentPath);

        /// <summary>
        /// Guarda una entidad File en la base de datos. 
        /// </summary>
        /// <param name="name">Nombre del fichero.</param>
        /// <param name="parentPath">Path del fichero</param>
        /// <param name="isFolder">Indica si es o no una carpeta.True si lo es, false en caso contrario.</param>
        /// <param name="contentType">Tipo MIME del fichero</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="Icon">Clase html para mostrar el icono</param>
        /// <param name="size">Tamaño del fichero.</param>
        /// <returns>Entidad File con los datos de un fichero físico.</returns>
        File createFile(string name, string parentPath, bool isFolder, string contentType, string userID, string Icon, int size);

        /// <summary>
        /// Actualiza en la base de datos el tamaño de un fichero de tipo carpeta.
        /// </summary>
        /// <param name="folderParentPath">Path del fichero</param>
        /// <param name="folderName">Nombre de la carpeta</param>
        /// <param name="size">Nuevo tamaño</param>
        /// <param name="userID">Id del usuario</param>
        void updateFolderSize(string folderParentPath, string folderName, int size, string userID);

        /// <summary>
        /// Obtiene ficheros cuyo nombre contenga el texto pasado como parámetro.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="name">Texto</param>
        /// <returns>Lista de ficheros cuyo nombre contiene el texto pasado como parámetro.</returns>
        List<File> getFilesByName(string userID, string name);

    }
}