﻿using FileSync.Models;
using System.Collections.Generic;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de la clase que gestiona la persistencia de las fotos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IPhotoPersistence
    {
        /// <summary>
        /// Obtiene todas las fotos de un usuario, entidades File tipo MIME esté relacionado con fotos
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista de fotos.</returns>
        IList<File> getFotos(string userID);

        /// <summary>
        /// Obtiene una photo por id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="photoID">Id de la foto</param>
        /// <returns>Entidad file que corresponde a una foto.</returns>
        File getPhoto(string userID, int photoID);
    }
}