﻿using FileSync.Models;
using System.Collections.Generic;

namespace FileSync.DAL.Persistence.interfaces
{
    /// <summary>
    /// Interfaz de clase que gestiona la persistencia de los ficheros borrados
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IDeletedFilePersistence
    {
        /// <summary>
        /// Obtiene todos los ficheros borrados (Entidad File asociada) de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista de los ficheros del usuario.</returns>
        IList<File> getDeletedFiles(string userID);

        /// <summary>
        /// Obtiene un fichero borrado de un usuario. (DeletedFile)
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Fichero borrado del usuario</returns>
        DeletedFile getDeletedFile(string userID, int fileID);

        /// <summary>
        /// Borra la entidad DeletedFile.
        /// </summary>
        /// <param name="dfile">Entidad deletedFile a borrar</param>
        /// <param name="file">Entidad File asociada a la entidad DeletedFile</param>
        void removeDeletedFile(DeletedFile dfile, File file);

        /// <summary>
        /// Borra la entidad DeletedFile.
        /// </summary>
        /// <param name="dfile">Entidad deletedFile a borrar</param>
        void removeDeletedFile(DeletedFile dfile); 
        
        /// <summary>
        /// Crea una entidad DeletedFile.
        /// </summary>
        /// <param name="fileID">Id del fichero borrado.</param>
        /// <param name="binName">Nombre del fichero borrado en la papelera.</param>
        void createDeletedFile(int fileID, string binName);

        /// <summary>
        /// Obtiene todos los ficheros borrados cuyo nombre contenga el texto introducido como parámetro.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="searchText">Texto a buscar</param>
        /// <returns>Lisa de ficheros (File) que estén marcados como borrado y cuyo nombre contenga el texto buscado.</returns>
        IList<File> getDeletedFiles(string userID, string searchText);
    }
}