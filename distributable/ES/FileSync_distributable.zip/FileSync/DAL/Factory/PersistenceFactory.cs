﻿using FileSync.DAL.Factory;
using FileSync.DAL.Persistence;
using FileSync.DAL.Persistence.interfaces;
using System;

namespace FileSync.DAL.factory
{
    /// <summary>
    /// Factoría que crea las instancias para acceder a la capa de persistencia.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class PersistenceFactory : IPersistenceFactory
    {
        /// <summary>
        /// Instancia de persistencia que gestiona las fotos.
        /// </summary>
        private IPhotoPersistence photoPersistence = null;

        /// <summary>
        /// Instancia de persistencia que gestiona los usuarios.
        /// </summary>
        private IUserPersistence userPersistence = null;

        /// <summary>
        /// Instancia de persistencia que gestiona las notificaciones.
        /// </summary>
        private INotificationPersistence notificationPersistence = null;

        /// <summary>
        /// Instancia de persistencia que gestiona los ficheros.
        /// </summary>
        private IFilePersistence filePersistence = null;

        /// <summary>
        /// Instancia de persistencia que gestiona los archivos compartidos.
        /// </summary>
        private ISharedFilePersistence sharedPersistence = null;

        /// <summary>
        /// Instancia de persistencia que gestiona el borrado dearchivos.
        /// </summary>
        private IDeletedFilePersistence deletedPersistence = null;

        /// <summary>
        /// Atributo utilizado para acceder a la clase (Singleton).
        /// </summary>
        private static readonly Lazy<IPersistenceFactory> instance = new Lazy<IPersistenceFactory>(() => new PersistenceFactory());

        private PersistenceFactory() { }

        public static IPersistenceFactory Instance
        {
            get
            {
                return instance.Value;
            }
        }

        public IPhotoPersistence getPhotoPersistence() {
            if (photoPersistence == null)
                photoPersistence = new PhotoPersistence();

            return photoPersistence;
        }

        public IUserPersistence getUserPersistence()
        {
            if (userPersistence == null)
                userPersistence = new UserPersistence();

            return userPersistence;
        }

        public INotificationPersistence getNotificationPersistence()
        {
            if (notificationPersistence == null)
                notificationPersistence = new NotificationPersistence();

            return notificationPersistence;
        }

        public IFilePersistence getFilePersistence()
        {
            if (filePersistence == null)
                filePersistence = new FilePersistence();

            return filePersistence;
        }

        public ISharedFilePersistence getSharedFilePersistence()
        {
            if (sharedPersistence == null)
                sharedPersistence = new SharedFilePersistence();

            return sharedPersistence;
        }

        public IDeletedFilePersistence getDeletedFilePersistence()
        {
            if (deletedPersistence == null)
                deletedPersistence = new DeletedFilePersistence();

            return deletedPersistence;
        }
    }
}