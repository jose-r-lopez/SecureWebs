﻿using FileSync.DAL.Persistence.interfaces;

namespace FileSync.DAL.Factory
{
    /// <summary>
    /// Interfaz de la factoría que crea las instancias para acceder a la capa de persistencia.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IPersistenceFactory
    {
        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona las fotos.
        /// </summary>
        /// <returns>Instancia de PhotoPersistence</returns>
        IPhotoPersistence getPhotoPersistence();

        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona los usuarios.
        /// </summary>
        /// <returns>Instancia de UserPersistence</returns>
        IUserPersistence getUserPersistence();

        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona las notificaciones.
        /// </summary>
        /// <returns>Instancia de NotificationPersistence </returns>
        INotificationPersistence getNotificationPersistence();

        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona los ficheros.
        /// </summary>
        /// <returns>Instancia de FilePersistence</returns>
        IFilePersistence getFilePersistence();

        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona los ficheros compartidos.
        /// </summary>
        /// <returns>Instancia de SharedFilePersistence</returns>
        ISharedFilePersistence getSharedFilePersistence();

        /// <summary>
        /// Obtiene una instancia de la clase de persistencia que gestiona los ficheros borrados.
        /// </summary>
        /// <returns>Instancia de DeletedFilePersistence</returns>
        IDeletedFilePersistence getDeletedFilePersistence();
    }
}