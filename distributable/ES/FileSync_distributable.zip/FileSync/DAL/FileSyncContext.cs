﻿using FileSync.Models;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace FileSync.DAL
{
    /// <summary>
    /// Contexto de la base de datos, clase que gestiona cómo se crea la base de datos y las tablas que contendrá.
    /// El framework EntityFramework permite la creación automática de la base de datos en base a las propiedades
    /// de esta clase.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class FileSyncContext : IdentityDbContext<ApplicationUser>
    {

        public FileSyncContext()
            : base("FileSyncConnection", throwIfV1Schema: false)
        {
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.ProxyCreationEnabled = true;
            this.Configuration.AutoDetectChangesEnabled = true;
            Database.SetInitializer<FileSyncContext>(new DropCreateDatabaseIfModelChanges<FileSyncContext>());    
        }

        /// <summary>
        /// Propiedad que indica que se debe crear una tabla para guardar las entidades tipo File. Se puede
        /// usar esta propiedad para añadir, eliminar o modificar elementos.
        /// </summary>
        public DbSet<File> Files { get; set; }

        /// <summary>
        /// Propiedad que indica que se debe crear una tabla para guardar las entidades tipo DeletedFile. Se puede
        /// usar esta propiedad para añadir, eliminar o modificar elementos.
        /// </summary>
        public DbSet<DeletedFile> DeletedFiles { get; set; }

        /// <summary>
        /// Propiedad que indica que se debe crear una tabla para guardar las entidades tipo Notification. Se puede
        /// usar esta propiedad para añadir, eliminar o modificar elementos.
        /// </summary>
        public DbSet<Notification> Notifications { get; set; }

        /// <summary>
        /// Propiedad que indica que se debe crear una tabla para guardar las entidades tipo SharedFile. Se puede
        /// usar esta propiedad para añadir, eliminar o modificar elementos.
        /// </summary>>
        public DbSet<SharedFile> SharedFiles { get; set; }

        /// <summary>
        /// Permite indicar cómo se va a crear la base de datos. Se indica que la relación entre Notification y SharedFile es
        /// más compleja, al corresponder a un SharedFile una notificación de forma opcional. Esto quiere decir que si se elimina la Notification
        /// no se debe eliminar el SharedFile. Por defecto las relaciones que se pueden realizar a través de las propiedades de cada modelo
        /// sólo permiten relaciones 1 a 1 siempre con borrado en cascada.
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Entity<SharedFile>().HasOptional(s =>s.Notification).WithOptionalPrincipal().WillCascadeOnDelete(false);
        }

        public static FileSyncContext Create()
        {
            return new FileSyncContext();
        }
    }
}