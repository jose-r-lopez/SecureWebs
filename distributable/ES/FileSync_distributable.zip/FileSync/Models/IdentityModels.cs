﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileSync.Models
{
    /// <summary>
    /// Clase del modelo que representa los datos de un usuario. Esta clase extiende de IdentityUser.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ApplicationUser : IdentityUser
    {
        /// <summary>
        /// Enlace necesario para poder acceder a los ficheros (File) de un usuario.
        /// </summary>
        public virtual ICollection<File> Files { get; set; }

        /// <summary>
        /// Nombre real del usuario.
        /// </summary>
        [Required]
        public string Realname { get; set; }

        /// <summary>
        /// Apellidos del usuario.
        /// </summary>
        [Required]
        public string Surname { get; set; }

        /// <summary>
        /// Capacidad utilizada por el usuario, en megabytes.
        /// </summary>
        [Required]
        public double Storage { get; set; }

        /// <summary>e
        /// Email del usuario. Es necesario sobrescribir la propiedad de la clase IdentityUser para establecer que el email será único.
        /// </summary>
        [Required]
        [Index("userEmail", 1, IsUnique = true)]
        public override string Email { get; set; }

        /// <summary>
        /// Obtiene el objeto necesario para la gestión de usuarios.
        /// </summary>
        /// <param name="manager">Manejador de usuarios</param>
        /// <returns>Objeto necesario para la gestión de usuarios.</returns>
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            return userIdentity;
        }

        public ApplicationUser() {
            Files = new List<File>();
        }
    }

}