﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileSync.Models
{
    /// <summary>
    /// Clase del modelo que representa los datos de un fichero que ha sido marcado como borrado.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class DeletedFile
    {
        /// <summary>
        /// Id del fichero (DeletedFile)
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Id del fichero (File), se necesita para obtener los datos originales del fichero.
        /// </summary>
        [Required]
        [Index("fileID", IsUnique = true)]
        public int FileId { get; set; }

        /// <summary>
        /// Nombre que el fichero tiene en la papelera (puede ser diferente o igual al original)
        /// </summary>
        [Required]
        public string BinName { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al fichero (File) asociado.
        /// </summary>
        [ForeignKey("FileId")]
        public virtual File File { get; set; }

    }
}