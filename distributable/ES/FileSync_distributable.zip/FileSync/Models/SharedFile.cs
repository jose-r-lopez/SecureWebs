﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileSync.Models
{
    /// <summary>
    /// Clase del modelo que representa un fichero compartido
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class SharedFile
    {
        /// <summary>
        /// Id de la entidad.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Id del fichero.
        /// </summary>
        [Index("UsersFileShared", 1, IsUnique = true)]
        public int FileId { get; set; }

        /// <summary>
        /// Id del usuario que es propietario del fichero
        /// </summary>
        [Index("UsersFileShared", 2, IsUnique = true)]
        public string UserId { get; set; }

        /// <summary>
        /// Id del usuario destino de la compartición.
        /// </summary>
        [Index("UsersFileShared", 3, IsUnique = true)]
        public string ShareUserId { get; set; }

        /// <summary>
        /// Boolean que indica si está o no aprobada la compartición.
        /// </summary>
        [Required]
        public bool Approved { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al usuario propietario del fichero.
        /// </summary>
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al usuario destino de la compartición.
        /// </summary>
        [ForeignKey("ShareUserId")]
        public virtual ApplicationUser ShareUser{ get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al fichero.
        /// </summary>
        [ForeignKey("FileId")]
        public virtual File File { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder a la notificación que creó la compartición.
        /// </summary>
        public virtual Notification Notification { get; set; }
    }
}