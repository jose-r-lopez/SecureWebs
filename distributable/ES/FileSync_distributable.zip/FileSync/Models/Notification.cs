﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileSync.Models
{
    /// <summary>
    /// Clase del modelo que representa una notificación de usuario.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class Notification
    {
        /// <summary>
        /// Id de la notificación.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Id del usuario que envia la notificación.
        /// </summary>
        public string SenderId { get; set; }

        /// <summary>
        /// Id del usuario que recibe la notificación.
        /// </summary>
        public string ReceiverId { get; set; }

        /// <summary>
        /// Texto de la notificación.
        /// </summary>
        [Required]
        public string Text { get; set; }

        /// <summary>
        /// Boolean que indica si la notificación está asociada o no a una compartición.
        /// </summary>
        [Required]
        public bool onlyNotification { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al usuario que envía la notificación.
        /// </summary>
        [ForeignKey("SenderId")]
        public virtual ApplicationUser Sender { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al usuario que recibe la notificación.
        /// </summary>
        [ForeignKey("ReceiverId")]
        public virtual ApplicationUser Receiver { get; set; }


    }
}