﻿using System.ComponentModel.DataAnnotations;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos del formulario que permite restablecer la contraseña.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ResetPasswordViewModel
    {
        /// <summary>
        /// Correo electrónico del usuario
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "Correo electrónico")]
        public string Email { get; set; }

        /// <summary>
        /// Contraseña del usuario
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; }

        /// <summary>
        /// Repetición de la contraseña del usuario
        /// </summary>
        [DataType(DataType.Password)]
        [Display(Name = "Confirmar contraseña")]
        [Compare("Password", ErrorMessage = "La contraseña y la contraseña de confirmación no coinciden.")]
        public string ConfirmPassword { get; set; }

        /// <summary>
        /// Código de seguridad
        /// </summary>
        public string Code { get; set; }
    }
}