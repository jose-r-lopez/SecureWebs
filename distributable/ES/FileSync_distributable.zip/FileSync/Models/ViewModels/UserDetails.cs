﻿
namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos de un usuario.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class UserDetails
    {
        /// <summary>
        /// Nombre real del usuario
        /// </summary>
        public string realname { get; set; }
        
        /// <summary>
        /// Apellidos del usuario
        /// </summary>
        public string surname { get; set; }

        /// <summary>
        /// Correo del usuario
        /// </summary>
        public string email { get; set; }
    }
}