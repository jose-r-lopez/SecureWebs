﻿using System.ComponentModel.DataAnnotations;
namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos del formulario que permite cambiar el nombre a un usuario.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ChangeNameViewModel
    {
        /// <summary>
        /// Nuevo nombre del usuario
        /// </summary>
        [Required]
        [StringLength(50, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 3)]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Nuevo apellido del usuario
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 3)]
        [Display(Name = "Apellidos")]
        public string Surname { get; set; }
    }
}