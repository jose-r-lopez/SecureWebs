﻿using System.ComponentModel.DataAnnotations;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos a introducir en el formulario que permite el inicio de sesión.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class LoginViewModel
    {
        /// <summary>
        /// Email del usuario
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "Correo electrónico")]
        public string email { get; set; }

        /// <summary>
        /// Contraseña del usuario
        /// </summary>
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string password { get; set; }
    }
}