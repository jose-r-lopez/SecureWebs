﻿using System.ComponentModel.DataAnnotations;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos del primer formulario que permite recuperar el acceso a la cuenta.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ForgotPasswordViewModel
    {
        /// <summary>
        /// Email del usuario que tiene una cuenta en el sistema.
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "Correo electrónico")]
        public string Email { get; set; }
    }
}