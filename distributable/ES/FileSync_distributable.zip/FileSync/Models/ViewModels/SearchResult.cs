﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos de los resultados de una búsqueda.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class SearchResult
    {
        /// <summary>
        /// Nombre del fichero resultado
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Path del fichero resultado.
        /// </summary>
        public string Location { get; set; }

        public SearchResult(string name, string location)
        {
            this.Name = name;
            this.Location = location;
        }
    }
}