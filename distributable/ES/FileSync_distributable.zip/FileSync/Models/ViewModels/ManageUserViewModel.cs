﻿using System.ComponentModel.DataAnnotations;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos a introducir en el formulario que permite el cambio de contraseña.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ManageUserViewModel
    {
        /// <summary>
        /// Antigua contraseña.
        /// </summary>
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña actual")]
        public string OldPassword { get; set; }

        /// <summary>
        /// Nueva contraseña.
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Nueva contraseña")]
        public string NewPassword { get; set; }

        /// <summary>
        /// Repetición de la nueva contraseña.
        /// </summary>
        [DataType(DataType.Password)]
        [Display(Name = "Confirmar la nueva contraseña")]
        [Compare("NewPassword", ErrorMessage = "La nueva contraseña y la contraseña de confirmación no coinciden.")]
        public string ConfirmPassword { get; set; }
    }
}