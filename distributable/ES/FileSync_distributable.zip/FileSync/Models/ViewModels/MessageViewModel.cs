﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa los datos de cualquier mensaje de error o de éxito que pueda aparecer en la aplicación.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class MessageViewModel
    {
        /// <summary>
        /// Mensaje a mostrar
        /// </summary>
        public string Message{get; set;}
        
        /// <summary>
        /// Tipo del mensaje 
        /// </summary>
        public string Type{get; set;}

        public MessageViewModel(string type, string message) {
            Message = message;
            Type = type;
        }
    }
}