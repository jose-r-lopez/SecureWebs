﻿using System;
using System.Collections.Generic;

namespace FileSync.Models.ViewModels
{
    /// <summary>
    /// Clase del modelo que representa las propiedades de un fichero o de un fichero compartido.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class PropertiesViewModel
    {
        /// <summary>
        /// Nombre del fichero
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Extensión del fichero
        /// </summary>
        public string Extension { get; set; }
        
        /// <summary>
        /// Tamaño del fichero
        /// </summary>
        public double Size { get; set; }
        
        /// <summary>
        /// Fecha de subida
        /// </summary>
        public DateTime UploadedDate { get; set; }
        
        /// <summary>
        /// Lista de emails de los usuario con los que se ha compartido el fichero
        /// </summary>
        public IList<string> Shared { get; set; }
        
        /// <summary>
        /// Boolean que indica si es propietario del fichero.
        /// </summary>
        public bool isOwner { get; set; }

        public PropertiesViewModel() {
            Shared = new List<string>();
        }
    }
}