﻿using FileSync.DAL;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace FileSync.Models
{
    /// <summary>
    /// Clase del modelo que representa los datos de un fichero.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class File
    {
        /// <summary>
        /// Id del fichero.
        /// </summary>
        [Index("FileUser", 1, IsUnique = true)]
        public int Id { get; set; }

        /// <summary>
        /// Nombre del fichero.
        /// </summary>
        [Required]
        public string Filename { get; set; }

        /// <summary>
        /// Boolean que indica si es una carpeta.
        /// </summary>
        [Required]
        public bool IsFolder { get; set; }
    
        /// <summary>
        /// Tipo del fichero. No es obligatorio, una carpeta tiene este campo a null.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Path de la carpeta padre del fichero.
        /// </summary>
        [Required]
        public string ParentPath { get; set; }

        /// <summary>
        /// Boolean que indica si el fichero ha sido borrado.
        /// </summary>
        [Required]
        public bool Deleted { get; set; }

        /// <summary>
        /// Tamaño del fichero en megabytes.
        /// </summary>
        [Required]
        public long size { get; set; }

        /// <summary>
        /// Fecha en la que se ha subido el fichero.
        /// </summary>
        [Required]
        public DateTime uploadDate { get; set; }

        /// <summary>
        /// Icono que representa el tipo de fichero.
        /// </summary>
        [Required]
        public string Icon {get; set;}

        /// <summary>
        /// Id del usuario que tiene el fichero.
        /// </summary>
        [Required]
        [Index("FileUser", 2, IsUnique = true)]
        public string UserId { get; set; }

        /// <summary>
        /// Enlace necesario para poder acceder al usuario (User) asociado.
        /// </summary>
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }


        public File() { }

        /// <summary>
        /// Muestra si un fichero (de tipo carpeta) contiene otras carpetas.
        /// </summary>
        /// <returns>False en caso de que contenga carpetas, true en caso contrario.</returns>
        public bool hasFolders()
        {
            FileSyncContext fileSync = new FileSyncContext();

            if (this.IsFolder)
            {
                return (from d in fileSync.Files
                        where d.UserId.Equals(this.UserId) && d.ParentPath.Equals(this.ParentPath + this.Filename + "\\") && d.Deleted == false && d.IsFolder
                        select d).Any();

            }

            return true;
        }

        public long getFolderSize(string userID) {
            FileSync.Managers.Factory.IManagersFactory managersFactory = FileSync.Managers.Factory.ManagersFactory.Instance;
 
            if (!this.Deleted && this.IsFolder) {
                return FileSync.Controllers.FileUtils.GetDirectorySize(new System.IO.DirectoryInfo(this.ParentPath + this.Filename));
            }
            if (this.Deleted && this.IsFolder)
            {
                var file = managersFactory.getDeletedFileManager().getDeletedFile(userID, this.Id);
                return FileSync.Controllers.FileUtils.GetDirectorySize(new System.IO.DirectoryInfo(managersFactory.getDeletedFileManager().getDeletedFilesUserPath(userID) + file.BinName));
            }

            return 0;
        }

    }

}