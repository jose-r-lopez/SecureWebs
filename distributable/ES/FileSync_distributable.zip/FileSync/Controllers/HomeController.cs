﻿using System.Linq;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using FileSync.Models.ViewModels;
using FileSync.Models;
using FileSync.Managers;
using FileSync.Managers.Factory;
using System.Web.Security;
using System.Collections.Generic;
using System.Runtime.Remoting.Contexts;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionadas con las operaciones que no necesitan inicio de sesión.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class HomeController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;

        /// <summary>
        /// Permite el inico de sesión, cuando se accede al formulario (petición GET).
        /// </summary>
        /// <param name="confirmEmail">Parámetro opcional, si se confirma un email se muestra la pantalla de inicio de sesión 
        /// con un mensaje que indica el éxito de la operación.</param>
        /// <returns>Devuelve la pantalla de inicio de sesión.</returns>
        [AllowAnonymous]
        [HttpGet]
        public ActionResult Index(string confirmEmail = "")
        {
            if (confirmEmail.Equals("Success"))
                ViewBag.Email = "Correo confirmado. Proceda a iniciar sesión";

            return View();
        }

        /// <summary>
        /// Permite el inicio de sesión cuando se ha rellenado el formulario (petición POST).
        /// </summary>
        /// <param name="model">Modelo de la vista (LoginViewModel) que contiene todos los datos del formulario.</param>
        /// <returns>Redirecciona al Index de FileController si no hay errores, en caso de error se muestra de nuevo el formulario con
        /// los errores.</returns>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Index(LoginViewModel model)
        {

            if (ModelState.IsValid)
            {
                var user = await managersFactory.getUserManager().getUserAppManager(HttpContext).FindByNameAsync(model.email);
                if (user != null)
                {
                    if (!await managersFactory.getUserManager().getUserAppManager(HttpContext).IsEmailConfirmedAsync(user.Id))
                    {
                        ModelState.AddModelError("", "El email no ha sido confirmado.");
                    }
                    else
                    {
                        user = await managersFactory.getUserManager().getUserAppManager(HttpContext).FindAsync(model.email, model.password);
                        if (user != null)
                        {
                            await managersFactory.getUserManager().SignInAsync(user, false, HttpContext);

                            var login = managersFactory.getUserManager().getUserAppManager(HttpContext).FindById(user.Id);
                            Session["user"] = null;

                            if (Session["user"] == null && login != null)
                                Session["user"] = login.Realname + " " + login.Surname;

                            Session["notifications"] = managersFactory.getUserManager().getNumberOfReceivedNotifications(user.Id);

                            return RedirectToRoute("File", new { catchall = "" });

                        }
                        else
                        {
                            ModelState.AddModelError("", "Contraseña incorrecta.");
                        }
                    }
                    
                }else
                {
                    ModelState.AddModelError("", "Nombre de usuario incorrecto.");
                }
                
             }
            return View(model);
        }

        /// <summary>
        /// Permite el registro de usuarios (petición GET).
        /// </summary>
        /// <returns>Devuelve la Vista que contiene el formulario para realizar el registro.</returns>
        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// Permite el registro de usuarios (petición POST). Se envía un correo al usuario con un enlace para confirmar el correo.
        /// En cuanto se confirme el correo el registro se completa.
        /// </summary>
        /// <param name="model">Modelo de la vista (RegisterViewModel) que contiene los datos del formulario del registro.</param>
        /// <returns>Devuelve la pantalla con el resultado del registro si no hay ningún error o el formulario de nuevo en caso de error.</returns>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors);

            if (ModelState.IsValid)
            {
                var user = new ApplicationUser()
                {
                    UserName = model.Email,
                    Email = model.Email,
                    Realname = model.Name,
                    Surname = model.Surname,
                    Storage = 0
                    
                };

                IdentityResult result = await  managersFactory.getUserManager().getUserAppManager(HttpContext).CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                   
                    var code = await  managersFactory.getUserManager().getUserAppManager(HttpContext).GenerateEmailConfirmationTokenAsync(user.Id);
                    var callbackUrl = Url.Action("ConfirmEmail", "Home", new { userId = user.Id, code = code }, 
                                                        protocol: Request.Url.Scheme);
                    string body = "<h1>FileSync - Confirmar registro</h1><p>Por favor, " +
                                  "confirma tu cuenta accediendo al siguiente <a href=\"" + 
                                  callbackUrl + "\">enlace</a>. En cuando acceda podrá iniciar sesión en " +
                                  "FileSync sin problemas.</p><p>Este mensaje se ha enviado automáticamente, " +
                                  "por favor no responda al mismo.";
                    await  managersFactory.getUserManager().getUserAppManager(HttpContext).SendEmailAsync(user.Id, "Confirma tu cuenta", body);

                    return RedirectToAction("RegisterResult", "Home");
                }
                else
                {
                    
                    AddErrors(result,true);
                }
            }

            return View(model);
        }
        
        /// <summary>
        /// Permite cerrar la sesión del usuario.
        /// </summary>
        /// <returns>Redirecciona a la pantalla de login. (Index de HomeController)</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            managersFactory.getUserManager().SignOut(HttpContext);
            Session.Clear();
            Session.Abandon();

            var user = HttpContext.User.Identity.IsAuthenticated;
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Permite confirmar el email de un usuario. El registro no se ha realizado completamente hasta que el correo introducido
        /// ha sido validado.
        /// </summary>
        /// <param name="userId">Id del usuario.</param>
        /// <param name="code">Código de seguridad.</param>
        /// <returns>Redirecciona a Index de Homecontroller en caso de éxito, en caso de error se muestra una pantalla de error.</returns>
        [AllowAnonymous]
        public async Task<ActionResult> ConfirmEmail(string userId, string code)
        {

            if (userId == null || code == null)
            {
                return View("Error");
            }
            var result = await  managersFactory.getUserManager().getUserAppManager(HttpContext).ConfirmEmailAsync(userId, code);
            if (result.Succeeded)
            {
                var path = UserManager.globalPath;
                managersFactory.getFileManager().createUserFilesPath(path, userId);
                managersFactory.getDeletedFileManager().createDeletedFileUserPath(path, userId);
                managersFactory.getFileSharedManager().createUserSharePath(path, userId);

                return RedirectToAction("Index", new { confirmEmail = "Success" });
            }
            return View("Error");
        }

        /// <summary>
        /// Devuelve el resultado del registro.
        /// </summary>
        /// <returns>Pantalla de éxito del registro.</returns>
        [AllowAnonymous]
        public ActionResult RegisterResult()
        {
            return View();
        }

        /// <summary>
        /// Permite obtener una nueva contraseña al usuario (PASO 1 , POST). Se obtiene el email del usuario que ha introducido
        /// y si éste existe se envía un correo con un enlace al formulario donde se introducirá la nueva contraseña.
        /// </summary>
        /// <param name="model">Modelo de la vista (ForgotPasswordViewModel) que contiene el email de la cuenta que se desea recuperar.</param>
        /// <returns>Devuelve el propio formulario en caso de error o una pantalla que indica el éxito de la operación.</returns>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {

            if (ModelState.IsValid)
            {
                var user = await managersFactory.getUserManager().getUserAppManager(HttpContext).FindByNameAsync(model.Email);
                if (user == null )  
                {
                    ModelState.AddModelError("", "El usuario no existe.");
                    return View();
                }
                if(!(await  managersFactory.getUserManager().getUserAppManager(HttpContext).IsEmailConfirmedAsync(user.Id))){
                    ModelState.AddModelError("", "El email no está confirmado.");
                    return View();
                }

                string code = await  managersFactory.getUserManager().getUserAppManager(HttpContext).GeneratePasswordResetTokenAsync(user.Id);
                var callbackUrl = Url.Action("ResetPassword", "Home", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);

                string body = "<h1>FileSync - Restablecer Contraseña</h1> <p>Para restablecer la contraseña, haga clic <a href=\"" +
                               callbackUrl + "\">aquí</a>. Cuando pulse el enlace aparecerá un " +
                               "formulario que debe rellenar para poder iniciar sesión de nuevo en FileSync.</p> " +
                               "<p> Si no quiere restablecer su contraseña, ignore este email.</p>" +
                               "<p>Este mensaje ha sido enviado automáticamente, por favor no responda al mismo.";

                await  managersFactory.getUserManager().getUserAppManager(HttpContext).SendEmailAsync(user.Id, "Restablecer contraseña", body);

                return RedirectToAction("ForgotPasswordConfirmation", "Home");
            }

            return View(model);
        }

        /// <summary>
        /// Permite obtener una nueva contraseña al usuario (PASO 2). A este método se accede desde el correo del usuario.
        /// Muestra el formulario que permite introducir la nueva contraseña.
        /// </summary>
        /// <param name="code">Código de seguridad.</param>
        /// <returns>Devuelve el formulario para introducir la contraseña en caso de que el código sea correcto.</returns>
        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            if (code == null)
            {
                return View("Error");
            }
            return View();
        }

        /// <summary>
        /// Permite obtener una nueva contraseña al usuario (PASO 3, POST). Guarda la nueva contraseña para permitir de nuevo el acceso.
        /// </summary>
        /// <param name="model">Modelo de la vista (ResetPasswordViewModel) con el email y la nueva contraseña de un usuario.</param>
        /// <returns>Devuelve o un mensaje de confirmación en caso de éxito o un mensaje de error en caso contrario.</returns>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {

            if (ModelState.IsValid)
            {
                var user = await  managersFactory.getUserManager().getUserAppManager(HttpContext).FindByNameAsync(model.Email);
                if (user == null)
                {
                    ModelState.AddModelError("", "No se encontró ningún usuario.");
                    return View();
                }
                IdentityResult result = await  managersFactory.getUserManager().getUserAppManager(HttpContext).
                                                    ResetPasswordAsync(user.Id, model.Code, model.Password);
                if (result.Succeeded)
                {
                    return RedirectToAction("ResetPasswordConfirmation", "Home");
                }
                else
                {
                    AddErrors(result,false);
                    return View();
                }
            }

            return View(model);
        }

        /// <summary>
        /// Devuelve la vista con un mensaje de confirmación de la operación "Recuperación de contraseña".
        /// </summary>
        /// <returns>Vista con mensaje de confirmación.</returns>
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        /// <summary>
        /// Confirmación de que se ha introducido el correo correctamente en el PASO 1 de "Recuperación de contraseña".
        /// </summary>
        /// <returns>Vista con mensaje de confirmación.</returns>
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        /// <summary>
        /// Permite obtener una nueva contraseña al usuario (PASO 1 , GET).
        /// </summary>
        /// <returns>Vista que contiene el formulario que permite introducir el correo de un usuario para poder recuperar el acceso.</returns>
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        private void AddErrors(IdentityResult result,bool register)
        {
            foreach (var error in result.Errors)
            {
                    ModelState.AddModelError("", error);
            }
        }

    }
}