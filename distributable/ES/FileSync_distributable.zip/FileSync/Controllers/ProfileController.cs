﻿using FileSync.Managers;
using FileSync.Managers.Factory;
using FileSync.Models;
using FileSync.Models.ViewModels;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionadas con las operaciones del perfil.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class ProfileController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;

        /// <summary>
        /// Muestra el perfil, datos de usuario y notificaciones.
        /// </summary>
        /// <returns>Vista actualizada del perfil de un usuario.</returns>
        public ActionResult Index()
        {
            string userID = UserManager.UserID(HttpContext);
            IList<Notification> notifications = managersFactory.getUserManager().getReceivedNotifications(userID);
            var user = managersFactory.getUserManager().getUser(userID);

            Session["notifications"] = notifications.Count();
            TempData["storage"] = Math.Round(user.Storage, 2).ToString().Replace(",", ".");

            if (Session["message"] != null) {
                MessageViewModel message = (MessageViewModel)Session["message"];
                ViewData.Add(new KeyValuePair<string, object>("Message", message));
                Session["message"] = null;
            }

            return View(notifications);
        }

        /// <summary>
        /// Muestra el formulario que permite cambiar la contraseña a un usuario. (GET)
        /// </summary>
        /// <returns>Vista que contiene el formulario que permite cambiar la contraseña.</returns>
        public ActionResult ChangePassword()
        {
            return View();
        }

        /// <summary>
        /// Cambia la contraseña del usuario (POST).
        /// </summary>
        /// <param name="model">Modelo de la vista (ManageUserViewModel) que contiene la nueva contraseña del usuario.</param>
        /// <returns>La vista del perfil si no hubo fallos o el formulario de nuevo en caso contrario.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ManageUserViewModel model)
        {

            if (ModelState.IsValid)
            {
                IdentityResult result = await managersFactory.getUserManager().getUserAppManager(HttpContext).ChangePasswordAsync(User.Identity.GetUserId(), model.OldPassword, model.NewPassword);
                if (result.Succeeded)
                {
                    var user = await managersFactory.getUserManager().getUserAppManager(HttpContext).FindByIdAsync(User.Identity.GetUserId());
                    await managersFactory.getUserManager().SignInAsync(user, false, HttpContext);
                    MessageViewModel message = new MessageViewModel("Información", "Contraseña cambiada con éxito");
                    Session["message"] = message;
                    return RedirectToAction("Index");
                }
                else
                {
                    AddErrors(result);
                }
            }

            return View(model);

        }

        /// <summary>
        /// Muestra el formulario que permite cambiar de nombre al usuario. (GET)
        /// </summary>
        /// <returns>Devuelve la vista que contiene el formulario.</returns>
        public ActionResult ChangeName()
        {
            return View();
        }

        /// <summary>
        /// Cambia el nombre a un usuario.
        /// </summary>
        /// <param name="model">Modelo de la vista (ChangeNameViewModel) que contiene el nuevo nombre del usuario.</param>
        /// <returns>Devuelve la Vista del perfil en caso de éxito o de nuevo el formulario en caso contrario.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangeName(ChangeNameViewModel model)
        {

            if (ModelState.IsValid)
            {
                int result = managersFactory.getUserManager().setCompleteName(UserManager.UserID(HttpContext), model.Name, model.Surname);
                if (result == 0)
                    return View(model);

                Session["user"] = model.Name + " " + model.Surname;
                MessageViewModel message = new MessageViewModel("Información", "Nombre cambiado con éxito");
                Session["message"] = message;
                return Redirect("Index");
            }

            return View(model);
        }

        /// <summary>
        /// Borra una notificación de un usuario.
        /// </summary>
        /// <param name="id">Id de la notificación.</param>
        /// <returns>Devuelve el perfil con la lista de notificaciones actualizada.</returns>
        public ActionResult DeleteNotification(string id)
        {
            int notificationID = Convert.ToInt16(id);
            managersFactory.getUserManager().deleteNotification(notificationID);

            if (Session["notifications"] != null)
             Session["notifications"] = (int)Session["notifications"]-1;

            return Redirect(Request.UrlReferrer.ToString());
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }
    }
}