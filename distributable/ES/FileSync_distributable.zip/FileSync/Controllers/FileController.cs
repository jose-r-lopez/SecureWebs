﻿using FileSync.Managers;
using FileSync.Managers.Factory;
using FileSync.Controllers.Utils;
using FileSync.Models;
using FileSync.Models.ViewModels;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionas con sus ficheros.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class FileController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;

        /// <summary>
        /// Se ejecuta cuando el usuario pide la lista de sus ficheros.
        /// </summary>
        /// <param name="catchall">Path de la carpeta que el usuario quiere visualizar</param>
        /// <returns>View con la lista de ficheros actualizada.</returns>
        public ActionResult Index(string catchall = "")
        {
            string pathInfo = FileUtils.getCleanPath(catchall);
            string path = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;
            
            if (!System.IO.Directory.Exists(path) || catchall.EndsWith("/"))
            {
                return new HttpNotFoundResult("No se ha encontrado el fichero");
            }

            IList<FileSync.Models.File> files = managersFactory.getFileManager().getNotDeletedFiles(UserManager.UserID(HttpContext), path);

            Session["pathInfo"] = pathInfo;

            char[] delimiterChars = { '\\' };
            string[] breadcrumbs = pathInfo.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);
            Session["breadcrumb"] = breadcrumbs;

            return View(files);

        }

        /// <summary>
        /// Crea una carpeta de un usuario,
        /// </summary>
        /// <param name="newFolder">Nombre de la carpeta.</param>
        /// <returns>PartialView _table con la lista de ficheros actualizada.</returns>
        [HttpPost]
        public ActionResult Create(string newFolder)
        {
            string pathInfo = (string)Session["pathInfo"];
            string parentPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;
            string[] splitPathInfo = pathInfo.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);


            if (!checkName(newFolder, pathInfo))
            {
                return setPartialViewTableWithMessage("Error", "No se permite ese nombre", parentPath);
            }
            else if (splitPathInfo.Length >= 5)
            {
                return setPartialViewTableWithMessage("Error", "Ha llegado al límite de carpetas consecutivas, no se pueden crear más.", parentPath);
            }
            else
            {
                string folderPath = parentPath + newFolder;
                bool isExists = System.IO.Directory.Exists(folderPath);
                if (!isExists)
                {
                    managersFactory.getFileManager().createFolder(newFolder, parentPath, UserManager.UserID(HttpContext));
                    return setPartialViewTable(parentPath);
                }
                else
                {
                    return setPartialViewTableWithMessage("Error", "Esa carpeta ya existe", parentPath);
                }
            }
        }

        private bool checkName(string newFolder, string pathInfo)
        {
            if (pathInfo.Equals("\\") &&
               (newFolder.Equals(managersFactory.getDeletedFileManager().getDeletedFilesUserPath(HttpContext)) ||
               newFolder.Equals(managersFactory.getFileSharedManager().getUserSharedPath(HttpContext))))
                return false;
            if (String.IsNullOrEmpty(newFolder))
                return false;

            return true;
            
        }

        /// <summary>
        /// Cambia el nombre de un fichero (File).
        /// </summary>
        /// <param name="newName">Nuevo nombre del fichero.</param>
        /// <param name="fileID">ID del fichero.</param>
        /// <returns>PartialView _table con la lista de ficheros actualizada.</returns>
        [HttpPost]
        public ActionResult ChangeName(string newName, string fileID)
        {
            int selected = Convert.ToInt32(fileID);
            string pathInfo = (string)Session["pathInfo"];
            string parentPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;

            if (!checkName(newName, pathInfo))
            {
                return setPartialViewTableWithMessage("Error", "Error al cambiar el nombre", parentPath);
            }

            if (!managersFactory.getFileManager().changeName(selected, UserManager.UserID(HttpContext), newName))
            {
                return setPartialViewTableWithMessage("Error", "Error al cambiar el nombre", parentPath);
            } 
            return setPartialViewTable(parentPath);
        }

        /// <summary>
        /// Obtiene las propiedades de un fichero.
        /// </summary>
        /// <param name="fileID">Id del fichero.</param>
        /// <returns>PartialView _PropertiesDialog con las propiedades del fichero (PropertiesViewModel)</returns>
        [HttpPost]
        public ActionResult Properties(string fileID)
        {
            int selected = Convert.ToInt32(fileID);

            //Si existe el fichero para el usuario
            var fileQuery = managersFactory.getFileManager().getNotDeletedFileByID(UserManager.UserID(HttpContext), selected);
            string extension = System.IO.Path.GetExtension(fileQuery.ParentPath + fileQuery.Filename);
            string nameWithoutExt = System.IO.Path.GetFileNameWithoutExtension(fileQuery.ParentPath + fileQuery.Filename);

            PropertiesViewModel pVM = new PropertiesViewModel();
            pVM.Name = nameWithoutExt;
            if(fileQuery.IsFolder){
                pVM.Extension = "No tiene extensión";
                pVM.Size = Math.Round(ByteToMegabyteConverter.Convert(fileQuery.getFolderSize(fileQuery.UserId)), 2);
            }
            else { 
                pVM.Extension = extension;
                pVM.Size = Math.Round(ByteToMegabyteConverter.Convert(fileQuery.size), 2);
            }

            pVM.UploadedDate = fileQuery.uploadDate;
            pVM.isOwner = true;

            var sharedFile = managersFactory.getFileSharedManager().getApprovedSharedFilesSameUser(selected, UserManager.UserID(HttpContext));

            foreach (SharedFile sFile in sharedFile)
            {
                pVM.Shared.Add(sFile.ShareUser.Email);
            }

            return PartialView("_PropertiesDialog", pVM);
        }

        /// <summary>
        /// Muestra todas las carpetas del usuario. Es el primer paso para mover un fichero en una carpeta.
        /// La primera vez se obtienen las carpetas del primer nivel y se debe de guardar el id del fichero a mover,
        /// por ello fileID tendrá valor la primera vez y parentPath estará vacío. Cuando se pidan de nuevo los ficheros del primer nivel
        /// o se pidan los ficheros del segundo nivel fileID no tendrá valor y parentPath si.
        /// </summary>
        /// <param name="fileID">Id del fichero a mover</param>
        /// <param name="parentPath">Path de las carpetas a mostrar.</param>
        /// <returns>Devuelve la partialView _Tree con las carpetas del sistema que están contenidas en ParentPath.</returns>
        [HttpPost]
        public ActionResult ShowFolders(int fileID = -1, string parentPath = "")
        {
            parentPath = FileUtils.getCleanMovePath(parentPath);

            string path = managersFactory.getFileManager().getUserFilePath(HttpContext) + parentPath;
            IList<FileSync.Models.File> folders = managersFactory.getFileManager().getFolders(UserManager.UserID(HttpContext), path);

            if (fileID != -1)
                Session["fileToMove"] = fileID;

            //que no aparezca el dialogo la primera vez en caso de que no haya carpetas
            if (fileID != -1 && (folders == null || folders.Count == 0))
            {
                return setPartialViewTableWithMessage("Error", "No existen carpetas a las que mover el fichero.", path);
            }

            return PartialView("_Tree", folders);
        }

        /// <summary>
        /// Mueve un fichero a otra carpeta distinta a la original. El id del fichero a mover se obtuvo en ShowFolders que se ha ejecutado previamente.
        /// </summary>
        /// <param name="selectedFolder">Id de la carpeta destino.</param>
        /// <returns>Devuelve el partialView _Table con la lista de ficheros actualizada, en caso de erro también devuelve un mensaje.</returns>
        [HttpPost]
        public ActionResult Move(int selectedFolder)
        {
            var userID = UserManager.UserID(HttpContext);
            string pathInfo = (string)Session["pathInfo"];
            string userPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;

            if (selectedFolder < 0)
            {
                return setPartialViewTableWithMessage("Error", "No se puede mover a esa carpeta.", userPath);
            }

            var folder = managersFactory.getFileManager().getFolder(userID, selectedFolder);
            if (folder == null || !folder.IsFolder)
            {
                return setPartialViewTableWithMessage("Error", "No se puede mover a esa carpeta.", userPath);
            }

            //recoger el fichero/carpeta a mover
            int fileID = -1;
            if (Session["fileToMove"] != null)
            {
                fileID = (int)Session["fileToMove"];
                Session["fileToMove"] = null;
            }
            else {
                return setPartialViewTableWithMessage("Error", "No se puede mover a esa carpeta.", userPath);
            }

            File file = managersFactory.getFileManager().getNotDeletedFileByID(userID, fileID);
            string parentName = System.IO.Path.GetFileName(file.ParentPath.Remove(file.ParentPath.Length - 1));
            string parentOfParent = System.IO.Directory.GetParent(file.ParentPath.Remove(file.ParentPath.Length - 1)).FullName + "\\";
            File parent = managersFactory.getFileManager().getNotDeletedFile(userID, parentOfParent, parentName);

            IList<int> ids = new List<int>();
            ids.Add(file.Id);
            if (parent != null)
            {
                ids.Add(parent.Id);
            }
          
            managersFactory.getFileManager().getFilesID(userID, file, ids);

            if (ids.Contains(selectedFolder))
            {
                return setPartialViewTableWithMessage("Error", "No se puede mover a esa carpeta.", userPath);
            }
            //si no existe la carpeta
            if (folder != null && file != null && folder.IsFolder && folder.Id != file.Id)
            {
                managersFactory.getFileManager().move(file, folder, userID);
                return setPartialViewTableWithMessage("Correcto", "La carpeta se ha movido con éxito.", userPath);
            }
            else
            {
                return setPartialViewTableWithMessage("Error", "La carpeta o el fichero no existe.", userPath);
            }
        }

        /// <summary>
        /// Sube un fichero al sistema.
        /// </summary>
        /// <param name="uploadedFile">Fichero a subir.</param>
        /// <returns>Devuelve el partialView _Table con la lista de ficheros actualizada.</returns>
        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase uploadedFile)
        {
            string pathInfo = (string)Session["pathInfo"];
            string parentPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;

            if (ByteToMegabyteConverter.Convert(uploadedFile.ContentLength) > UserManager.maxFileSize)
            {
                return setJsonTableWithMessage("Error", "Archivo demasiado grande.", parentPath);
            }
            else
            {
                var user = managersFactory.getUserManager().getUser(UserManager.UserID(HttpContext));
                if (user.Storage + ByteToMegabyteConverter.Convert(uploadedFile.ContentLength) > UserManager.maxStorage)
                {
                    return setJsonTableWithMessage("Error", "No tiene espacio para el fichero que intenta subir.", parentPath);
                }
                else
                {
                    // Validate the uploaded file
                    if (uploadedFile == null)
                    {
                        return setJsonTableWithMessage("Error", "Error al subir el archivo.", parentPath);
                    }
                    else if (!checkName(uploadedFile.FileName, pathInfo))
                    {
                        return setJsonTableWithMessage("Error", "Error al subir el archivo, nombre no permitido.", parentPath);
                    }
                    else
                    {

                        if (System.IO.File.Exists(parentPath + uploadedFile.FileName))
                        {
                            return setJsonTableWithMessage("Error", "El archivo ya existe.", parentPath);
                        }
                        else
                        {
                            managersFactory.getFileManager().upload(uploadedFile, parentPath, UserManager.UserID(HttpContext));
                            //actualizar capacidad
                            managersFactory.getUserManager().addToStorage(UserManager.UserID(HttpContext), Convert.ToInt64(uploadedFile.ContentLength));
                            return setJsonTable(parentPath);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Obtiene los datos de un usuario según su email.
        /// </summary>
        /// <param name="userEmail">Email del usuario.</param>
        /// <returns>Json con los datos del usuario (nombre y email)</returns>
        public ActionResult GetShareUser(String userEmail)
        {

            if (!userEmail.Equals(User.Identity.Name))
            {
                UserDetails user = managersFactory.getUserManager().getUserDetails(userEmail);

                if (user != null)
                {
                    string name = user.realname + " " + user.surname;
                    return Json(new { Email = user.email, Name = name });
                }
                else
                {
                    return Json("No se ha encontrado");
                }
            }
            return Json("Un usuario no puede compartir consigo mismo");
        }

        /// <summary>
        /// Busca ficheros en la lista normal, en la lista de compartidos y en la lista de eliminados por nombre.
        /// </summary>
        /// <param name="searchText">Palabra que debe contener el nombre.</param>
        /// <returns>Devuelve la lista de resultados (View Search).</returns>
        public ActionResult Search(string searchText)
        {
            IList<SearchResult> results = new List<SearchResult>();
            if (!String.IsNullOrEmpty(searchText)) { 
                    
                //buscar en ficheros normales, en ficheros compartidos y en la papelera
                managersFactory.getFileManager().searchFiles(UserManager.UserID(HttpContext), searchText, results);
                managersFactory.getFileSharedManager().searchSharedFile(UserManager.UserID(HttpContext), searchText, results);
                managersFactory.getDeletedFileManager().searchDeletedFiles(UserManager.UserID(HttpContext), searchText, results);
                TempData["searchText"] = searchText;
               
            }
            return View(results);
            
        }

        private PartialViewResult setPartialViewTableWithMessage(String title, String text, string parentPath)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            IList<Models.File> files = managersFactory.getFileManager().getNotDeletedFiles(UserManager.UserID(HttpContext), parentPath);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));
            return PartialView("_Table", files);
        }

        private PartialViewResult setPartialViewTable(string parentPath)
        {
            return PartialView("_Table", managersFactory.getFileManager().getNotDeletedFiles(UserManager.UserID(HttpContext), parentPath));
        }

        private JsonResult setJsonTableWithMessage(string title, string text, string parentPath)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            IList<File> files = managersFactory.getFileManager().getNotDeletedFiles(UserManager.UserID(HttpContext), parentPath);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));

            return Json(new
            {
                status = "error",
                vista = new TransformRazorToString().Transform("_Table", files, ControllerContext)
            });
        }
        private JsonResult setJsonTable(string parentPath)
        {
            IList<Models.File> files = managersFactory.getFileManager().getNotDeletedFiles(UserManager.UserID(HttpContext), parentPath);

            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_Table", files, ControllerContext)
            }
                );
        }
    }
}