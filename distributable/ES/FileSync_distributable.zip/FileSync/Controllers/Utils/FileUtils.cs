﻿using System;
using System.IO;
using System.Web;

namespace FileSync.Controllers
{
    /// <summary>
    /// Clase de utilidad que permite realizar acciones relacionadas con los ficheros de los usuarios.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public static class FileUtils
    {
        /// <summary>
        /// Permite obtener el identificador del icono a enseñar en la lista de ficheros.
        /// </summary>
        /// <param name="type">Tipo de icono de un fichero.</param>
        /// <returns>Decuelve la clase(html) que se debe usar en la lista de ficheros.</returns>
        public static String getIcon(string type)
        {
            if(type.Equals("Folder")){
                return "folder";
            }
            if (type.StartsWith("audio")) {
                return "audio";
            }
            else if (type.StartsWith("image")) {
                return "img";
            }
            else if (type.StartsWith("video"))
            {
                return "video";
            }
            else if (type.StartsWith("application"))
            {
                if (type.Contains("excel") || type.Contains("sheet") || type.Contains("spreadsheet"))
                {
                    return "exc";
                }

                else if (type.Contains("word") || type.Contains("document"))
                {
                    return "doc";
                }

                else if (type.Contains("powerpoint"))
                {
                    return "ppt";
                }

                else if (type.Contains("pdf"))
                {
                    return "pdf";
                }

                else if (type.Contains("zip"))
                {
                    return "zip";
                }
            }
           

            return "all";

        }

        /// <summary>
        /// Obtiene el nombre que debe de tener un fichero en una carpeta. Si el nombre que debería tener el fichero ya se encuentra en la
        /// carpeta se debe de obtener un índice que se concatenará con el nombre para crear el nuevo nombre que tendrá el fichero.
        /// </summary>
        /// <param name="basepath">Path de la carpeta donde se introduce el fichero y del fichero cuyo nombre se debe de obtener.</param>
        /// <param name="filename">Nombre que debería tener el fichero.</param>
        /// <returns>Devuelve el mismo nombre que se introduce como parámetro en caso de que en la carpeta no contenga 
        /// ya un fichero con ese nombre, en caso contrario devuelve un nuevo nombre.
        /// </returns>
        public static string getName(string basepath, string filename)
        {
            string path = basepath + filename;
            String filenameWOExt = System.IO.Path.GetFileNameWithoutExtension(path);
            String ext = System.IO.Path.GetExtension(path);
            int n = 1;
            do
            {
                path = System.IO.Path.Combine(basepath, String.Format("{0} ({1}){2}", filenameWOExt, (n++), ext));
            }
            while (System.IO.File.Exists(path));


            return System.IO.Path.GetFileName(path);
        }

        /// <summary>
        /// Obtiene el tamaño de una carpeta de un usuario. Se recorren todos los ficheros y se va acumulando el tamaño de éstos.
        /// </summary>
        /// <param name="path">Path del directorio</param>
        /// <returns>Devuelve el tamaño total del directorio.</returns>
        public static long GetDirectorySize(DirectoryInfo d)
        {
            long size = 0;
            // Add file sizes.
            FileInfo[] fis = d.GetFiles();
            foreach (FileInfo fi in fis)
            {
                size += fi.Length;
            }
            // Add subdirectory sizes.
            DirectoryInfo[] dis = d.GetDirectories();
            foreach (DirectoryInfo di in dis)
            {
                size += GetDirectorySize(di);
            }
            return size;
        }

        /// <summary>
        /// Limpia el path de manera que sólo contenga "\",nunca esté vacío y siempre acabe en "\".
        /// </summary>
        /// <param name="path">Path a limpiar.</param>
        /// <returns>Devuelve un path limpio</returns>
        public static string getCleanPath(string path)
        {
            path = path.Replace("/", "\\");
            if (path.Equals(""))
            {
                return "\\";
            }
            else
            {
                return "\\" + path + "\\";
            }
        }

        /// <summary>
        /// Limpia el path de manera que sólo contenga "\",nunca esté vacío.
        /// </summary>
        /// <param name="path">Path a limpiar.</param>
        /// <returns>Devuelve un path limpio</returns>
        public static string getCleanDownloadPath(string path)
        {
            path = path.Replace("/", "\\");
            if (path.Equals(""))
            {
                return "\\";
            }
            else
            {
                return "\\" + path;
            }
        }

        /// <summary>
        /// Limpia el path de manera que sólo contenga "\", nunca esté vacío y acabe en "\" en caso de que no esté vacío. 
        /// </summary>
        /// <param name="path">Path a limpiar.</param>
        /// <returns>Devuelve un path limpio</returns>
        public static string getCleanMovePath(string path)
        {
            path = HttpUtility.UrlDecode(path);
            path = path.Replace("/", "\\");
            if (!path.Equals("") && !path.EndsWith("\\"))
            {
                path = "\\" + path + "\\";
            }
            else
            {
                path = "\\" + path;
            }

            return path;
        }
    }
} 