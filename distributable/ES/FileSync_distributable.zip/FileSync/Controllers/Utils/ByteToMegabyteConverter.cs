﻿
namespace FileSync.Controllers.Utils
{
    /// <summary>
    /// Clase encargada de convertir de byte a megabyte.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ByteToMegabyteConverter
    {
        /// <summary>
        /// Convierte de bytes a megabytes.
        /// </summary>
        /// <param name="bytes">Número en bytes que se debe convertir.</param>
        /// <returns>Devuelve los bytes del paramétro convertidos a megabytes.</returns>
        public static double Convert(long bytes)
        {
            return (bytes / 1024f) / 1024f;
        }
    }
}