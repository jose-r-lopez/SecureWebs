﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace FileSync.Controllers.Utils
{
    /// <summary>
    /// Clase que transforma una vista parcial (MVC 5) en un string para poder ser enviado a través de JSON.
    /// </summary>
    public class TransformRazorToString 
    {
        /// <summary>
        /// Transforma una partialView en una cadena de texto para poder enviar el html por JSON.
        /// </summary>
        /// <param name="viewName">Nombre de la vista parcial.</param>
        /// <param name="model">Modelo a usar en la vista.</param>
        /// <param name="context">Contexto del controlador en el que se ejecute el método.</param>
        /// <returns>Devuelve una cadena con el contenido de la pantalla.</returns>
        public string Transform(string viewName, object model,ControllerContext context)
        {
            context.Controller.ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(context,
                                                                         viewName);
                var viewContext = new ViewContext(context, viewResult.View,
                                            context.Controller.ViewData, context.Controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(context, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }
    }
}