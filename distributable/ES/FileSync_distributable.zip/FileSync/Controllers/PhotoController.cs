﻿using FileSync.Managers;
using FileSync.Managers.Factory;
using FileSync.Models;
using System;
using System.Web.Mvc;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionadas con la galería de fotos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class PhotoController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;

        /// <summary>
        /// Devuelve la lista de fotos de un usuario.
        /// </summary>
        /// <returns>Vista que contiene la lista de fotos.</returns>
        public ActionResult Index()
        {
            return View(managersFactory.getFileManager().getPhotos(UserManager.UserID(HttpContext)));
        }

        /// <summary>
        /// Obtiene un objeto System.File que corresponda a una foto para poder ser mostrada en la etiqueta img del lenguaje html.
        /// </summary>
        /// <param name="stringID">Id de la foto</param>
        /// <returns>Objeto File con la información de la foto.</returns>
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public FileContentResult ViewPhoto(string stringID) {

            int photoID = Convert.ToInt32(stringID);
            File photo = managersFactory.getFileManager().getPhoto(UserManager.UserID(HttpContext), photoID);
           

            byte[] contents = System.IO.File.ReadAllBytes(photo.ParentPath + photo.Filename);
            string mimeType = photo.Type;
            Response.AppendHeader("Content-Disposition", "inline; filename=" + photo.Filename);
            return File(contents, mimeType);
        }
    }
}