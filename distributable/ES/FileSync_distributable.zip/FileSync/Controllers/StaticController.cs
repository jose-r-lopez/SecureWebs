﻿using System;
using System.Web;
using System.Web.Mvc;
using FileSync.Managers;
using FileSync.Managers.Factory;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionadas con la descarga y vista previa de ficheros (File y SharedFile).
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class StaticController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;
        
        /// <summary>
        /// Vista previa de un fichero (File). Si no se puede realizar la vista previa en el navegador se descargará el fichero.
        /// </summary>
        /// <param name="fileID">Id del fichero.</param>
        /// <returns>Devuelve un objeto System.File que se podrá usar para visualizar el contenido del fichero en el navegador.</returns>
        public ActionResult Index(int id)
        {

            int selected = Convert.ToInt32(id);
            var file = managersFactory.getFileManager().getNotDeletedFileByID(UserManager.UserID(HttpContext), selected);

            if (file == null)
            {
                return new HttpNotFoundResult("No se ha encontrado el fichero");
            } else {
                byte[] contents = System.IO.File.ReadAllBytes(file.ParentPath + file.Filename);
                string mimeType = file.Type;
                Response.AppendHeader("Content-Disposition", "inline; filename=" + file.Filename.Replace(",",""));
                return File(contents, mimeType);
            }

        }

        /// <summary>
        /// Vista previa de un fichero compartido. (SharedFile). Si no se puede realizar la vista previa en el navegador se descargará el fichero.
        /// </summary>
        /// <param name="id">Id del fichero compartido</param>
        /// <returns>Devuelve un objeto System.File que se podrá usar para visualizar el contenido del fichero en el navegador.</returns>
        public ActionResult Shared(string id)
        {

            int fileID = Convert.ToInt16(id);
            string path = managersFactory.getFileSharedManager().getUserSharedPath(HttpContext);
            var file = managersFactory.getFileSharedManager().getApprovedSharedFile(fileID, UserManager.UserID(HttpContext));
            if (file != null) {
                byte[] contents = System.IO.File.ReadAllBytes(path + "/" + file.File.Filename);
                string mimeType = file.File.Type;
                Response.AppendHeader("Content-Disposition", "inline; filename=" + file.File.Filename.Replace(",", ""));
                return File(contents, mimeType);
            }
            return null;
        }

        /// <summary>
        /// Permite la descarga de un fichero compartido (SharedFile)
        /// </summary>
        /// <param name="id">Id del fichero</param>
        /// <returns>Devuelve un objeto System.File necesario para realizar la descarga.</returns>
        public FileResult DownloadShare(string id)
        {

            int fileID = Convert.ToInt32(id);
            string path = managersFactory.getFileSharedManager().getUserSharedPath(HttpContext);
            var file = managersFactory.getFileSharedManager().getApprovedSharedFile(fileID, UserManager.UserID(HttpContext));

            if (file != null && !file.File.IsFolder)
            {
                string fileName = file.File.Filename;
                byte[] fileBytes = System.IO.File.ReadAllBytes(path + fileName);
                return File(fileBytes, "application/octet-stream", fileName);
            }

            return null;
        }

        /// <summary>
        /// Permite la descarga de un fichero (File).
        /// </summary>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Devuelve un objeto System.File necesario para realizar la descarga.</returns>
        public FileResult Download(string fileID)
        {
       
            int selected = Convert.ToInt32(fileID);
            var fileQuery = managersFactory.getFileManager().getNotDeletedFileByID(UserManager.UserID(HttpContext), selected);

            if (fileQuery != null && !fileQuery.IsFolder)
            {
                byte[] fileBytes = System.IO.File.ReadAllBytes(fileQuery.ParentPath + fileQuery.Filename);
                string fileName = fileQuery.Filename;
                return File(fileBytes, "application/octet-stream", fileName);
            }

            return null;
        }

    }
}