﻿using FileSync.Controllers.Utils;
using FileSync.Managers;
using FileSync.Managers.Factory;
using FileSync.Models;
using FileSync.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve todas las peticiones del usuario relacionadas con sus ficheros compartidos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class SharedFileController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;

        /// <summary>
        /// Comparte un fichero entre varios usuarios. Por cada compartición se crea una notificación. Los usuarios que reciban la notificación
        /// tendrán que aceptarla para que la compartición se realice completamente.
        /// Se crea un objeto SharedFile no aprobado que será actualizado o borrado en cuanto el usuario que reciba la notificación 
        /// decida si aceptarla o rechazarla.
        /// </summary>
        /// <param name="shareUser">Id del usuario que quiere compartir un fichero.</param>
        /// <param name="fileID">Id del fichero a compartir.</param>
        /// <param name="shareIDs">Id de los usuario que recibirán la notificación.</param>
        /// <returns>Devuelve la vista actualizada de los ficheros del usuario que contendrá un mensaje con el resultado dela operación.</returns>
        public ActionResult Index(string shareUser, string fileID, string shareIDs)
        {
            int shareFileID = Convert.ToInt16(fileID);
            string userID = UserManager.UserID(HttpContext);

            string pathInfo = (string)Session["pathInfo"];
            string parentPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;

            char[] delimiterChars = { ' ' };
            string[] ids = shareIDs.Split(delimiterChars,StringSplitOptions.RemoveEmptyEntries);

            File file = managersFactory.getFileManager().getNotDeletedFileByID(userID, shareFileID);
            if (file == null || file.IsFolder)
            {
                return setJsonFileTableWithMessage("Error", "Error al compartir.", parentPath);
            }

            bool result = true;

            if (ids.Count() < 6) { 
                for (int i = 0; i < ids.Count(); i++)
                {
                    string currentEmail = ids[i].Remove(0, 1);
                    currentEmail = currentEmail.Remove((currentEmail.Length - 1), 1);
                    if (!managersFactory.getFileSharedManager().createShare(currentEmail, userID, shareFileID, User.Identity.Name, file.Filename))
                    {
                        result = false;
                    }
                }

                if (!result) {
                    return setJsonFileTableWithMessage("Error", "Error al compartir.", parentPath);
                }

               return setJsonFileTable(parentPath);
            }

            return setJsonFileTableWithMessage("Error", "Es posible que no haya podido compartir el fichero con algún usuario.", parentPath);
        }

        /// <summary>
        /// Muestra la lista de ficheros compartidos.
        /// </summary>
        /// <returns>Devuelve la Vista que contiene la lista de ficheros que han sido compartidos con el usuario.</returns>
        [HttpGet]
        public ActionResult Files()
        {
            return View(managersFactory.getFileSharedManager().getApprovedSharedFiles(UserManager.UserID(HttpContext)));
        }

        /// <summary>
        /// Acepta una compartición de un fichero. Cuando acepta la compartición se aprueba el SharedFile asociado. 
        /// Se crea una notificación para indicar al propierario del fichero que se ha aceptado la compartición.
        /// Se copia el fichero a la carpeta de compartidos del usuario que acepta la compartición (actualizando el almacenamiento del usuario).
        /// </summary>
        /// <param name="id">Id de la notificación.</param>
        /// <returns>Vista con el perfil con la lista de notificaciones actualizada.</returns>
        public ActionResult Accept(string id)
        {
            int notificationID = Convert.ToInt16(id);
            double storage = managersFactory.getUserManager().getUser(UserManager.UserID(HttpContext)).Storage;

            //se copia el fichero del usuario1 a la carpeta compartida del usuario2
            SharedFile sharedFile = managersFactory.getFileSharedManager().getSharedFileFromNotification(notificationID);
            if (sharedFile.File != null && !sharedFile.File.IsFolder && System.IO.File.Exists(sharedFile.File.ParentPath + sharedFile.File.Filename))
            {
                if (storage + ByteToMegabyteConverter.Convert(sharedFile.File.size) > 100)
                {
                    MessageViewModel message = new MessageViewModel("Error", "Error al aceptar la compartición. Almacenamiento máximo alcanzado.");
                    Session["message"] = message;
                    return RedirectToAction("Index", "Profile");
                }
                else
                {
                    managersFactory.getUserManager().addToStorage(UserManager.UserID(HttpContext), sharedFile.File.size);
                    string path = managersFactory.getFileSharedManager().getUserSharedPath(HttpContext);
                    managersFactory.getFileSharedManager().acceptSharing(sharedFile.File, path, sharedFile);

                    managersFactory.getUserManager().createAcceptNotification(sharedFile.Notification.ReceiverId, sharedFile.Notification.SenderId, sharedFile.File.Filename);
                    managersFactory.getUserManager().removeNotification(sharedFile.Notification.Id);

                    if (Session["notifications"] != null)
                        Session["notifications"] = (int)Session["notifications"] - 1;

                    return Redirect(Request.UrlReferrer.ToString());
                }
            }

            MessageViewModel messageError = new MessageViewModel("Error", "Error al aceptar la compartición. Puede que el fichero a compartir no exista.");
            Session["message"] = messageError;
            return RedirectToAction("Index", "Profile");
        }

        /// <summary>
        /// Rechaza una notificación. Se elimina la notificación que se rechaza y se elimina el SharedFile asociado.
        /// Se crea una nueva notificación para indicar al propietario del fichero que un usuario ha rechazado la compartición.
        /// </summary>
        /// <param name="id">Id de la notificación</param>
        /// <returns>Vista con el perfil con la lista de notificaciones actualizada.</returns>
        public ActionResult Reject(string id)
        {
            int notificationID = Convert.ToInt16(id);
            Notification rejectedNotification = managersFactory.getUserManager().getNotification(notificationID);
            SharedFile shared = managersFactory.getFileSharedManager().getSharedFileFromNotification(notificationID);

            if (rejectedNotification == null || shared.File == null)
            {
                MessageViewModel messageError = new MessageViewModel("Error", "Error al rechazar la compartición.");
                Session["message"] = messageError;
                return RedirectToAction("Index", "Profile");
            }

            managersFactory.getUserManager().createRejectNotification(rejectedNotification.ReceiverId, rejectedNotification.SenderId, shared.File.Filename);

            //eliminar en la bbdd la linea de Shared correspondiente
            managersFactory.getFileSharedManager().removeFromNotification(notificationID);

            if (Session["notifications"] != null && (int)Session["notifications"] > 0)
                Session["notifications"] = (int)Session["notifications"] - 1;

            return Redirect(Request.UrlReferrer.ToString());
        }

        /// <summary>
        /// Borra una compartición entre dos usuarios.
        /// </summary>
        /// <param name="id">Id de la compartición (SharedFile)</param>
        /// <returns>Devuelve la partialView _SharedTable actualizada con la lista de ficheros compartidos.</returns>
        public ActionResult DeleteSharing(string id)
        {
            int selected = Convert.ToInt32(id);
            var fileQuery = managersFactory.getFileSharedManager().getApprovedSharedFile(selected, UserManager.UserID(HttpContext));
            
            if (fileQuery == null)
            {
                return setJsonTableWithMessage("Error", "Error al borrar la compartición.");
            }
         
            string path = managersFactory.getFileSharedManager().getUserSharedPath(HttpContext);
            managersFactory.getUserManager().subtractStorage(UserManager.UserID(HttpContext), fileQuery.File.size);

            if (System.IO.File.Exists(path + fileQuery.File.Filename))
                System.IO.File.Delete(path + fileQuery.File.Filename);

            managersFactory.getFileSharedManager().remove(fileQuery);

            return setJsonTable();
        }

        /// <summary>
        /// Obtiene las propiedades de un fichero compartido.
        /// </summary>
        /// <param name="id">Id del fichero compartido (SharedFile)</param>
        /// <returns>PartialView _PropertiesDialog con las propiedades del fichero (PropertiesViewModel)</returns>
        public ActionResult GetProperties(string id)
        {
            int selected = Convert.ToInt32(id);

            //Si existe el fichero para el usuario
            var fileQuery = managersFactory.getFileSharedManager().getApprovedSharedFile(selected, UserManager.UserID(HttpContext));
            if (fileQuery == null) {
                return setJsonTableWithMessage("Error", "Error al obtener las propiedades.");
            }

            string path = managersFactory.getFileSharedManager().getUserSharedPath(HttpContext);
            string extension = System.IO.Path.GetExtension(path + fileQuery.File.Filename);
            string nameWithoutExt = System.IO.Path.GetFileNameWithoutExtension(path + fileQuery.File.Filename);

            PropertiesViewModel pVM = new PropertiesViewModel();
            pVM.Name = nameWithoutExt;
            pVM.Extension = extension;
            pVM.UploadedDate = fileQuery.File.uploadDate;
            pVM.Size = Math.Round(ByteToMegabyteConverter.Convert(fileQuery.File.size), 2);
            pVM.isOwner = false;
            pVM.Shared.Add(fileQuery.User.Email);

            return PartialView("_PropertiesDialog", pVM);
        }

        private JsonResult setJsonTableWithMessage(string title, string text)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));

            IList<SharedFile> sharedFiles = managersFactory.getFileSharedManager().getApprovedSharedFiles(UserManager.UserID(HttpContext));
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_SharedTable", sharedFiles, ControllerContext)
            }, JsonRequestBehavior.AllowGet);
        }

        private JsonResult setJsonFileTableWithMessage(string title, string text, string parentPath)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));
            return Json(new
            {
                
                status = "success",
                vista = new TransformRazorToString().Transform("_Table", managersFactory.getFileManager().getNotDeletedFiles(
                                                                    UserManager.UserID(HttpContext), parentPath), ControllerContext)
            },JsonRequestBehavior.AllowGet);
        }

        private JsonResult setJsonTable()
        {
            IList<SharedFile> sharedFiles = managersFactory.getFileSharedManager().getApprovedSharedFiles(UserManager.UserID(HttpContext));
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_SharedTable", sharedFiles, ControllerContext)
            });
        }

        private JsonResult setJsonFileTable(string parentPath)
        {
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_Table", managersFactory.getFileManager().getNotDeletedFiles(
                                                                    UserManager.UserID(HttpContext), parentPath), ControllerContext)
            });
        } 
    }
}