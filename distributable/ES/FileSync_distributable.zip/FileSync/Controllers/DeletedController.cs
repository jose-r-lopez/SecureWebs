﻿using FileSync.Managers;
using FileSync.Managers.Factory;
using FileSync.Controllers.Utils;
using FileSync.Models;
using System;
using System.Linq;
using System.Web.Mvc;
using FileSync.Models.ViewModels;
using System.Collections.Generic;
using System.Web.Helpers;
using System.Net.Http;

namespace FileSync.Controllers
{
    /// <summary>
    /// Controlador que resuelve las peticiones del usuario relacionadas con el borrado de ficheros.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    [Authorize]
    public class DeletedController : Controller
    {
        /// <summary>
        /// Instancia de la factoría que da acceso a los manejadores.
        /// </summary>
        private IManagersFactory managersFactory = ManagersFactory.Instance;
 
        /// <summary>
        /// Lista todos los ficheros borrados por el usuario.
        /// </summary>
        /// <returns>Devuelve la vista Index(Deleted) al que se le añade la lista de ficheros borrados.</returns>
        public ActionResult Index()
        {
            return View( managersFactory.getDeletedFileManager().getDeletedFiles(UserManager.UserID(HttpContext)));
        }

        /// <summary>
        /// Destruye definitivamente un fichero de un usuario. Se elimina todo rastro de él en el sistema.
        /// </summary>
        /// <param name="ids">Ids de los ficheros a destruir.</param>
        /// <returns>Devuelve el partialView _DeletedTable al que se le introduce la lista de ficheros actualizada.</returns>
        [HttpPost]
        public ActionResult Destroy(string[] ids)
        {
                var userID = UserManager.UserID(HttpContext);
                if (ids.Length == 0)
                {
                    return setJsonTableWithMessage("Error", "Error al destruir uno o varios ficheros.");
                }

                for (int i = 0; i < ids.Count(); i++)
                {
                    int selected = Convert.ToInt32(ids[i]);
                    File fileQuery = managersFactory.getFileManager().getDeletedFileById(userID, selected);
                    if (fileQuery == null)
                    {
                        return setJsonTableWithMessage("Error", "Error al destruir uno o varios ficheros.");
                    }

                    var binfile = managersFactory.getDeletedFileManager().getDeletedFile(userID, fileQuery.Id);
                    if (binfile == null)
                    {
                        return setJsonTableWithMessage("Error", "Error al destruir uno o varios ficheros.");
                    }

                    string binpath = managersFactory.getDeletedFileManager().getDeletedFilesUserPath(HttpContext);

                    //actualizar storage
                    managersFactory.getUserManager().subtractStorage(userID, fileQuery.size);

                    managersFactory.getDeletedFileManager().destroy(fileQuery, userID, binpath, binfile);
                    managersFactory.getFileManager().removeFile(fileQuery);
                }

                return setJsonTable();
        }

        /// <summary>
        /// Restaura los ficheros elegidos por el usuario. Al restaurar se marca el fichero (File) como no borrado y se elimina
        /// la entidad (DeletedFile) relacionada con el fichero en el sistema.
        /// </summary>
        /// <param name="ids">Ids de los ficheros a restaurar.</param>
        /// <returns>Devuelte el partialBiew _DeletedFile con la lista de ficheros eliminados actualizada.</returns>
        [HttpPost]
        public ActionResult Restore(string[] ids)
        {
            var userID = UserManager.UserID(HttpContext);
            if (ids.Length == 0)
            {
                return setJsonTableWithMessage("Error", "Error al restaurar uno o varios ficheros.");
            }

           for (int i = 0; i < ids.Count(); i++){
                int selected = Convert.ToInt32(ids[i]);

                //Si existe el fichero para el usuario
                var fileQuery = managersFactory.getFileManager().getDeletedFileById(userID, selected);
                if (fileQuery == null)
                {
                    return setJsonTableWithMessage("Error", "Error al restaurar uno o varios ficheros.");
                }
                var binfile =  managersFactory.getDeletedFileManager().getDeletedFile(userID, fileQuery.Id);
                if (binfile == null)
                {
                    return setJsonTableWithMessage("Error", "Error al restaurar uno o varios ficheros.");
                }

                string binpath =  managersFactory.getDeletedFileManager().getDeletedFilesUserPath(HttpContext);
                managersFactory.getFileManager().changeDeletedState(userID, selected, false);
                string name =  managersFactory.getDeletedFileManager().restore(fileQuery, binfile, binpath, userID);
                
                if(name != null)
                    managersFactory.getFileManager().changeName(fileQuery.Id, userID, name);
            }

           return setJsonTable();
        }

        /// <summary>
        /// Borra un fichero de un usuario. Se marca el fichero como eliminado (File) y se crea la entidad DeletedFile
        /// relacionada con el fichero.
        /// </summary>
        /// <param name="ids">Ids de los ficheros a eliminar.</param>
        /// <returns>Devuelve el partialView _Table con la lista de ficheros (normales) actualizada.</returns>
        [HttpPost]
        public ActionResult Delete(string[] ids)
        {
            string pathInfo = (string)Session["pathInfo"];
            string parentPath = managersFactory.getFileManager().getUserFilePath(HttpContext) + pathInfo;

            if (ids.Length == 0)
            {
                return setJsonFileTableWithMessage("Error", "Error al borrar uno o varios ficheros.", parentPath);
            }
            else { 
                for (int i = 0; i < ids.Count();i++ )
                {
                    int selected = Convert.ToInt32(ids[i]);
                    if (managersFactory.getFileManager().getNotDeletedFileByID(UserManager.UserID(HttpContext), selected) == null)
                    {
                        return setJsonFileTableWithMessage("Error", "Error al borrar uno o varios ficheros.", parentPath);
                    }
                    var fileQuery = managersFactory.getFileManager().changeDeletedState(UserManager.UserID(HttpContext), selected, true);
                    if (i == 0) 
                        parentPath = fileQuery.ParentPath;

                     managersFactory.getDeletedFileManager().delete(fileQuery, UserManager.UserID(HttpContext), HttpContext);
                }

                return setJsonFileTable(parentPath);
            }
        }

        private JsonResult setJsonTableWithMessage(string title, string text)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_DeletedTable",
                                 managersFactory.getDeletedFileManager().getDeletedFiles(UserManager.UserID(HttpContext)), ControllerContext)
            });
        }

        private JsonResult setJsonTable()
        {
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_DeletedTable",
                                 managersFactory.getDeletedFileManager().getDeletedFiles(UserManager.UserID(HttpContext)), ControllerContext)
            });
        }

        private JsonResult setJsonFileTableWithMessage(string title, string text, string parentPath)
        {
            MessageViewModel message = new MessageViewModel(title, text);
            ViewData.Add(new KeyValuePair<string, object>("Message", message));
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_Table", managersFactory.getFileManager().getNotDeletedFiles(
                                                                    UserManager.UserID(HttpContext), parentPath), ControllerContext)
            });
        }

        private JsonResult setJsonFileTable(string parentPath)
        {
            return Json(new
            {
                status = "success",
                vista = new TransformRazorToString().Transform("_Table", managersFactory.getFileManager().getNotDeletedFiles(
                                                                    UserManager.UserID(HttpContext), parentPath), ControllerContext)
            });
        } 
    }
    
}