﻿using FileSync.Managers.Interfaces;
using FileSync.DAL.factory;
using FileSync.Models;
using System.Collections.Generic;
using System.Web;
using System.Web.Hosting;
using System;
using FileSync.Models.ViewModels;
using FileSync.Controllers;
using FileSync.DAL.Factory;

namespace FileSync.Managers
{
    /// <summary>
    /// Clase que implementa la lógica de negocio relacionada con los ficheros.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class FileManager : IFileManager
    {
        /// <summary>
        /// Instancia de la factoría para tener acceso a la capa de persistencia.
        /// </summary>
        private IPersistenceFactory persistenceFactory = PersistenceFactory.Instance;

        public void createUserFilesPath(string path, string userID)
        {
            bool exists = System.IO.Directory.Exists(path + userID);

            if (!exists)
                System.IO.Directory.CreateDirectory(path + userID);
        }

        public string getUserFilePath(HttpContextBase context){
            return  HostingEnvironment.MapPath("/Data/" + UserManager.UserID(context));
        }

        public File getDeletedFileById(string userID, int id) {
            return  persistenceFactory.getFilePersistence().getDeletedFile(userID, id);
        }

        public IList<File> getPhotos(string userID) {
            return persistenceFactory.getPhotoPersistence().getFotos(userID);
        }

        public File getPhoto(string userID, int photoID){
            return persistenceFactory.getPhotoPersistence().getPhoto(userID, photoID);
        }

        public File getNotDeletedFile(string userID, string parent, string name)
        {
            return  persistenceFactory.getFilePersistence().getNotDeletedFile(userID, parent, name);
        }

        public File getNotDeletedFileByID(string userID, int id)
        {
            return  persistenceFactory.getFilePersistence().getNotDeletedFile(userID, id);
        }

        public void removeFile(File file)
        {
             persistenceFactory.getFilePersistence().removeFile(file);
        }

        public bool changeName(int selected, string userID, string newName)
        {
            var fileQuery = getNotDeletedFileByID(userID, selected);
            if (fileQuery == null)
            {
                return false;
            }

            if (fileQuery.IsFolder)
            {
                if (System.IO.Directory.Exists(fileQuery.ParentPath + newName))
                {
                     return false;
                }
                string oldName = fileQuery.Filename;
                changeFolderName(fileQuery, newName, userID);
                System.IO.Directory.Move(fileQuery.ParentPath + oldName, fileQuery.ParentPath + newName);
                return true;
            }
            else
            {
                if (System.IO.File.Exists(fileQuery.ParentPath + newName))
                {
                     return false;
                }
                string oldName = fileQuery.Filename;
                persistenceFactory.getFilePersistence().changeFileName(userID, fileQuery.Id, newName);
                System.IO.File.Move(fileQuery.ParentPath + oldName, fileQuery.ParentPath + newName);
                return true;
            }

        }

        public void changeFolderName(File file, string newname, string userID)
        {
            changeParentName(file.ParentPath, file.Filename, userID, newname, "");
            persistenceFactory.getFilePersistence().changeFileName(userID, file.Id, newname);
        }

        private void changeParentName(string oldparentpath, string oldname, string userID, string newname, string newparentpath)
        {
            IList<FileSync.Models.File> filesInFolder = getFiles(userID, oldparentpath + oldname + "\\");

            foreach (FileSync.Models.File f in filesInFolder)
            {
                string parentpath = f.ParentPath;
                string name = f.Filename;
                string newparent = newparentpath;

                if (newparentpath.Equals(""))
                    newparent = oldparentpath + newname;

                 persistenceFactory.getFilePersistence().changeParentPath(f, newparent + "\\");

                newparent = newparent + "\\" + f.Filename;
                changeParentName(parentpath, name, userID, newname, newparent);
                
            }
        }

        public File changeDeletedState(string userID, int FileId, bool state)
        {
            return  persistenceFactory.getFilePersistence().changeDeletedState(userID, FileId, state);
        }

        public IList<File> getNotDeletedFiles(string userID, string parentPath)
        {
            return  persistenceFactory.getFilePersistence().getNotDeletedFiles(userID, parentPath);
        }

        public void createFolder(string name, string parentPath, string userID){
             string icon = FileUtils.getIcon("Folder");
             create(name, parentPath, true, null, userID, icon, 0);
             System.IO.Directory.CreateDirectory(parentPath + name);
        }

        public IList<File> getFolders(string userID, string path)
        {
            return  persistenceFactory.getFilePersistence().getFolders(userID, path);
        }

        public void searchFiles(string userID, string searchText, IList<SearchResult> results)
        {
             IList<File> files =  persistenceFactory.getFilePersistence().getFilesByName(userID, searchText);
             foreach (FileSync.Models.File file in files)
            {
                string[] path = file.ParentPath.Split(new string[] { userID }, StringSplitOptions.None);
                path[1] = path[1].Replace("\\", "/");
                path[1] = path[1].Remove(path[1].Length - 1);
                results.Add(new SearchResult(file.Filename, path[1]));
            }
        }

        public void updateFolderSize(string parentOfParent, string parentName, int size,string userID)
        {
             persistenceFactory.getFilePersistence().updateFolderSize(parentOfParent, parentName, size, userID);
        }

        public File getFolder(string userID, int folderID)
        {
            return  persistenceFactory.getFilePersistence().getFolder(userID, folderID);
        }

        public void changeParentPath(File file, string newParentPath)
        {
             persistenceFactory.getFilePersistence().changeParentPath(file, newParentPath);
        }

        public IList<File> getFiles(string userID, string path)
        {
            return persistenceFactory.getFilePersistence().getFiles(userID, path);
        }

        public void changeParentPath(string newParentPath, int fileID, string userID)
        {

            Models.File file = getNotDeletedFileByID(userID, fileID);

            IList<FileSync.Models.File> filesInFolder = getFiles(userID, file.ParentPath + file.Filename + "\\");

            foreach (FileSync.Models.File f in filesInFolder)
            {
                changeParentPath(newParentPath + file.Filename + "\\", f.Id, userID);
            }
            changeParentPath(file, newParentPath);
        }

        public void move(File file, File folder, string userID)
        {
            string name = "";
            //si es carpeta o fichero se mueve diferente
            if (file.IsFolder)
            {
                if (System.IO.Directory.Exists(folder.ParentPath + folder.Filename + "\\" + file.Filename))
                {
                    name = FileUtils.getName(folder.ParentPath, file.Filename);
                }
                else
                {
                    name = file.Filename;
                }
                System.IO.Directory.Move(file.ParentPath + file.Filename, folder.ParentPath + folder.Filename + "\\" + name);

                //actualizar en la bbdd parent path
                changeParentPath(folder.ParentPath + folder.Filename + "\\", file.Id, userID);
                changeName(file.Id, userID, name);
            }
            else
            {
                if (System.IO.File.Exists(folder.ParentPath + folder.Filename + "\\" + file.Filename))
                {
                    name = FileUtils.getName(folder.ParentPath, file.Filename);
                }
                else
                {
                    name = file.Filename;
                }


                System.IO.File.Move(file.ParentPath + file.Filename, folder.ParentPath + folder.Filename + "\\" + name);
                changeParentPath(folder.ParentPath + folder.Filename + "\\", file.Id, userID);
                changeName(file.Id, userID, name);

            }
        }

        public void getFilesID(string userID, File file, IList<int> ids)
        {
            IList<FileSync.Models.File> filesInFolder = getFiles(userID, file.ParentPath + file.Filename + "\\");

            foreach (FileSync.Models.File f in filesInFolder)
            {
                ids.Add(f.Id);
                getFilesID(userID, f, ids);
            }
        }

        public void upload(HttpPostedFileBase uploadedFile, string parentPath,string userID)
        {
            bool error = false;

            try
            {
                // Save the file to the server
                uploadedFile.SaveAs(parentPath + uploadedFile.FileName);
            }
            catch (Exception e)
            {
                error = true;
            }

            File file = null;

            if (!error)
            {
                string icon = FileUtils.getIcon(uploadedFile.ContentType);
                file = create(uploadedFile.FileName,
                            parentPath, false, uploadedFile.ContentType, userID, icon, uploadedFile.ContentLength);

            }
        }

        private File create(string name, string parentPath, bool isFolder, string contentType, string userID, string icon, int size)
        {
            return persistenceFactory.getFilePersistence().createFile(name, parentPath, isFolder, contentType, userID, icon, size);
        }
    }
}