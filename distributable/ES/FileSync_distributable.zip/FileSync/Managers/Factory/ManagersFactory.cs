﻿using FileSync.Managers.Interfaces;
using System;

namespace FileSync.Managers.Factory
{
    /// <summary>
    /// Factoría que crea las instancias para acceder a la capa de gestores.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class ManagersFactory : IManagersFactory
    {
        /// <summary>
        /// Instancia de gestores que gestiona los ficheros.
        /// </summary>
        private IFileManager fileManager = null;

        /// <summary>
        /// Instancia de gestores que gestiona los ficheros compartidos.
        /// </summary>
        private IFileSharedManager fileSharedManager = null;

        /// <summary>
        /// Instancia de gestores que gestiona los usuarios.
        /// </summary>
        private IUserManager userManager = null;

        /// <summary>
        /// Instancia de gestores que gestiona los ficheros eliminados.
        /// </summary>
        private IDeletedFileManager deletedFileManager = null;

        /// <summary>
        /// Atributo utilizado para acceder a la clase (Singleton).
        /// </summary>
        private static readonly Lazy<IManagersFactory> instance = new Lazy<IManagersFactory>(() => new ManagersFactory());

        private ManagersFactory() { }

        public static IManagersFactory Instance
        {
            get
            {
                return instance.Value;
            }
        }

        public IFileManager getFileManager()
        {
            if (fileManager == null)
                fileManager = new FileManager();

            return fileManager;
        }

        public IFileSharedManager getFileSharedManager()
        {
            if (fileSharedManager == null)
                fileSharedManager = new FileSharedManager();
            return fileSharedManager;
        }

        public IUserManager getUserManager()
        {
            if (userManager == null)
                userManager = new UserManager();
            return userManager;
        }

        public IDeletedFileManager getDeletedFileManager()
        {
            if (deletedFileManager == null)
                deletedFileManager = new DeletedFileManager();
            return deletedFileManager;
        }
    }
}