﻿using FileSync.Managers.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FileSync.Managers.Factory
{
    /// <summary>
    /// Interfaz de la factoría que crea las instancias para acceder a la capa de gestores.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IManagersFactory
    {
        /// <summary>
        /// Obtiene una instancia de la clase que gestiona la lógica de negocio relacionada con ficheros.
        /// </summary>
        /// <returns>Instancia de FileManage</returns>
        IFileManager getFileManager();

        /// <summary>
        /// Obtiene una instancia de la clase que gestiona la lógica de negocio relacionada con los ficheros compartidos.
        /// </summary>
        /// <returns>Instancia de FileSharedManager</returns>
        IFileSharedManager getFileSharedManager();

        /// <summary>
        /// Obtiene una instancia de la clase que gestiona la lógica de negocio relacionada con los ficheros borrados.
        /// </summary>
        /// <returns>Instancia de DeletedFileManager</returns>
        IDeletedFileManager getDeletedFileManager();

        /// <summary>
        /// Obtiene una instancia de la clase que gestiona la lógica de negocio relacionada con los usuarios.
        /// </summary>
        /// <returns>Instancia de UserManager</returns>
        IUserManager getUserManager();
    }
}