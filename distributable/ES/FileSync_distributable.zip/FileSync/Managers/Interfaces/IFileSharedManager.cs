﻿using FileSync.Models;
using FileSync.Models.ViewModels;
using System.Collections.Generic;
using System.Web;

namespace FileSync.Managers.Interfaces
{
    /// <summary>
    /// Interfaz de la clase que implementa la lógica de negocio relacionada con los ficheros compartidos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IFileSharedManager
    {
        /// <summary>
        /// Crea la ruta que va a contener los ficheros compartidos aceptados por un usuario.
        /// </summary>
        /// <param name="path">Path donde la aplicación guarda los ficheros de los usuarios.</param>
        /// <param name="userID">Id del usuario</param>
        void createUserSharePath(string path, string userID);

        /// <summary>
        /// Obtiene la ruta usada para guardar los ficheros físicos que el usuario ha aceptado obtener de una compartición.
        /// </summary>
        /// <param name="context">Contexto http</param>
        /// <returns>Ruta base de los ficheros compartidos.</returns>
        string getUserSharedPath(HttpContextBase context);

        /// <summary>
        /// Crea una nueva compartición.
        /// </summary>
        /// <param name="currentEmail">Email del usuario con el que se comparte.</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="shareFileID">Id del fichero a compartir</param>
        /// <param name="name">Nombre del usuario que realiza la compartición</param>
        /// <param name="filename">Nombre del fichero que se comparte</param>
        /// <returns>True si se ha creado sin problemas la compartición,false en caso contrario.</returns>
        bool createShare(string currentEmail, string userID, int shareFileID, string name, string filename);

        /// <summary>
        /// Obtiene todas las comparticiones que un usuario ha aprobado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista de comparticiones.</returns>
        IList<SharedFile> getApprovedSharedFiles(string userID);
        
        /// <summary>
        /// Obtiene una compartición a través de la notificación asociada.
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        /// <returns>Compartición de un fichero (SharedFile)</returns>
        SharedFile getSharedFileFromNotification(int notificationID);

        /// <summary>
        /// Aprueba una compartición.
        /// </summary>
        /// <param name="file">Compartición (SharedFile) a borrar</param>
        void approve(SharedFile file);

        /// <summary>
        /// Borra una compartición que se obtiene a partir de la notificación asociada.
        /// </summary>
        /// <param name="notificationID">Id de la notificación</param>
        void removeFromNotification(int notificationID);

        /// <summary>
        /// Borra una compartición.
        /// </summary>
        /// <param name="file">SharedFile a borrar.</param>
        void remove(SharedFile file);

        /// <summary>
        /// Obtiene una compartición aprobada por su id.
        /// </summary>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario</param>
        /// <returns>SharedFile o null en caso de que no exista.</returns>
        SharedFile getApprovedSharedFile(int fileID, string userID);

        /// <summary>
        /// Obtiene todos las comparticiones que un usuario a realizado de un fichero.
        /// </summary>
        /// <param name="fileID">Id del fichero.</param>
        /// <param name="userId">Id del usuario</param>
        /// <returns>Lista de comparticiones</returns>
        IList<SharedFile> getApprovedSharedFilesSameUser(int fileID, string userId);

        /// <summary>
        /// Obtiene una lista con los fichero compartidos cuyo nombre contiene el texto de la búsqueda de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="searchText">Texto de búsqueda de un usuario.</param>
        /// <param name="results">Lista en la que se obtendrá el resultado de la búsqueda.</param>
        void searchSharedFile(string userID, string searchText, IList<SearchResult> results);

        /// <summary>
        /// Acepta una compartición.
        /// </summary>
        /// <param name="file">Fichero a compartir.</param>
        /// <param name="path">Path del fichero.</param>
        /// <param name="sharedFile">Entidad SharedFile que representa la compartición</param>
        void acceptSharing(File file, string path, SharedFile sharedFile);
    }
}