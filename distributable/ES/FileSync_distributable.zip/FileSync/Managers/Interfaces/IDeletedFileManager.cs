﻿using FileSync.Models;
using FileSync.Models.ViewModels;
using System.Collections.Generic;
using System.Web;

namespace FileSync.Managers.Interfaces
{
    /// <summary>
    /// Interfaz de la clase que implementa la lógica de negocio relacionada con los ficheros borrados.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IDeletedFileManager
    {
        /// <summary>
        /// Crea la ruta que va a contener los ficheros borrados.
        /// </summary>
        /// <param name="path">Path donde la aplicación guarda los ficheros de los usuarios.</param>
        /// <param name="userID">Id del usuario</param>
        void createDeletedFileUserPath(string path, string userID);

        /// <summary>
        /// Obtiene la ruta usada para guardar los ficheros físicos que han sido eliminados por el usuario.
        /// </summary>
        /// <param name="context">Contexto Http</param>
        /// <returns>Ruta base de los ficheros.</returns>
        string getDeletedFilesUserPath(HttpContextBase context);

        /// <summary>
        /// Obtiene la ruta usada para guardar los ficheros físicos que han sido eliminados por el usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Ruta base de los ficheros.</returns>
        string getDeletedFilesUserPath(string userID);

        /// <summary>
        /// Recorre el contenido de una carpeta para ir borrando su contenido. Usada en la operación de destruir.
        /// </summary>
        /// <param name="path">Path donde se encuentra la carpeta a recorrer.</param>
        /// <param name="userID">Id del usuario</param>
        void removeAll(string path, string userID);

        /// <summary>
        /// Marca un fichero como borrado o como no borrado. Si es una carpeta recorre todo su contenido y
        /// marca todo su contenido con el mismo estado que el padre.
        /// </summary>
        /// <param name="path">Path donde se encuentra el fichero a marcar.</param>
        /// <param name="state">Nuevo estado del fichero.</param>
        /// <param name="userID">Id del usuario</param>
        void updateDeletedFlag(string path, bool state, string userID);

        /// <summary>
        /// Obtiene una lista de todos los fichero eliminados.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista con todos los ficheros eliminados.</returns>
        IList<File> getDeletedFiles(string userID);

        /// <summary>
        /// Obtiene la entidad DeletedFile del fichero que ha sido borrado. Se busca por el id de la entidad File asociada.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id de la entidad File.</param>
        /// <returns>DeltedFile encontrado o null si no se encuentra.</returns>
        DeletedFile getDeletedFile(string userID, int fileID);

        /// <summary>
        /// Borra la entidad DeletedFile junto con la entidad File asociada.
        /// </summary>
        /// <param name="deleted">DeletedFile a borrar</param>
        /// <param name="file">File a borrar</param>
        void removeDeletedFile(DeletedFile deleted, File file);

        /// <summary>
        /// Borra la entidad DeletedFile pasada como parámetro.
        /// </summary>
        /// <param name="deleted">DeletedFile a borrar</param>
        void removeDeletedFile(DeletedFile deleted);

        /// <summary>
        /// Crea una entidad DeletedFile asociada a un fichero cuando se desea borrar éste. 
        /// </summary>
        /// <param name="fileID">Id del fichero a borrar</param>
        /// <param name="filename">Nombre del fichero en la papelera</param>
        void createDeletedFile(int fileID, string filename);

        /// <summary>
        /// Busca todos los ficheros eliminados cuyos nombre contiene el texto que el usuario ha buscado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="searchText">Texto que el usuario ha buscado.</param>
        /// <param name="results">Lista a la que se debe añadir todos los ficheros encontrados.</param>
        void searchDeletedFiles(string userID, string searchText, IList<SearchResult> results);
        
        /// <summary>
        /// Borra un fichero. Marca el fichero (File) como borrado.
        /// El fichero físico se mueve a la carpeta destinada a ser la papelera del usuario.
        /// </summary>
        /// <param name="file">Fichero a borrar</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="context">Contexto Http</param>
        void delete(File file, string userID, HttpContextBase context);

        /// <summary>
        /// Restaura un fichero. Marca como no borrado el fichero File. Si el fichero es una carpeta 
        /// y contiene otros ficheros también deben actualizarse.
        /// </summary>
        /// <param name="file">Fichero a restaurar.</param>
        /// <param name="binfile">DeletedFile asociado al fichero.</param>
        /// <param name="binpath">Path de la papelera.</param>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Nuevo nombre si al restaurar a la carpeta original ya existía un fichero con el mismo nombre.</returns>
        string restore(File file, DeletedFile binfile, string binpath, string userID);

        /// <summary>
        /// Destruye un fichero físico marcado como eliminado. Después invoca a  removeDeletedFile() para borrar la entidad File 
        /// y su entidad DeletedFile asociada.
        /// </summary>
        /// <param name="file">Entidad File a destruir.</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="binpath">Path donde se encuentra el fichero físico.</param>
        /// <param name="binfile">Entidad DeletedFile a destruir.</param>
        void destroy(File file, string userID, string binpath, DeletedFile binfile);
    }
}