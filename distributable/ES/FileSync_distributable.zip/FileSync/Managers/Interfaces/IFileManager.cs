﻿using FileSync.Models;
using FileSync.Models.ViewModels;
using System.Collections.Generic;
using System.Web;

namespace FileSync.Managers.Interfaces
{
    /// <summary>
    /// Interfaz de la clase que implementa la lógica de negocio relacionada con los ficheros.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IFileManager
    {
        /// <summary>
        /// Crea la ruta que va a contener los ficheros de un usuario concreto.
        /// </summary>
        /// <param name="path">Path donde la aplicación guarda los ficheros de los usuarios.</param>
        /// <param name="userID">Id del usuario</param>
        void createUserFilesPath(string path, string userID);

        /// <summary>
        /// Obtiene la ruta usada para guardar los ficheros físicos del usuario.
        /// </summary>
        /// <param name="context">Contexto Http</param>
        /// <returns>Ruta base de los ficheros.</returns>
        string getUserFilePath(HttpContextBase context);

        /// <summary>
        /// Obtiene un fichero borrado por su id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="id">Id del fichero.</param>
        /// <returns>Fichero cuyo id se especifica,null en caso contrario.</returns>
        File getDeletedFileById(string userID, int id);

        /// <summary>
        /// Obtiene todas las fotos de un usuario.Se buscan todos los ficheros cuyo MIME empiece por image.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista de fotos.</returns>
        IList<File> getPhotos(string userID);

        /// <summary>
        /// Obtiene una foto por su id. Se buscan en todos los ficheros cuyo MIME empiece por image.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="photoID">Id de la foto.</param>
        /// <returns>File con el id especificado, null en caso contrario.</returns>
        File getPhoto(string userID, int photoID);

        /// <summary>
        /// Obtiene un fichero no borrado por su id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id del fichero</param>
        /// <returns>Fichero con id especificado, null en caso contrario.</returns>
        File getNotDeletedFileByID(string userID, int fileID);

        /// <summary>
        /// Obtiene un fichero no borrado usando su path y su nombre.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parent">Path donde se ubica el fichero.</param>
        /// <param name="name">Nombre del fichero.</param>
        /// <returns>Fichero con path y nombre especificado, null en caso contrario.</returns>
        File getNotDeletedFile(string userID, string parent, string name);

        /// <summary>
        /// Elimina un fichero.
        /// </summary>
        /// <param name="file">Fichero a eliminar</param>
        void removeFile(File file);
 
       /// <summary>
       /// Cambia el nombre de un fichero.
       /// </summary>
       /// <param name="selected">Id del fichero</param>
       /// <param name="userID">Id del usuario</param>
       /// <param name="newName">Nuevo nombre</param>
       /// <returns>True si se realiza la operación correctamente, false en caso contrario.</returns>
        bool changeName(int selected, string userID, string newName);

        /// <summary>
        /// Cambia el estado que indica si un fichero ha sido eliminado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="FileId">Id del fichero</param>
        /// <param name="state">Estado. True si se marca como elimnado, false en caso contrario.</param>
        /// <returns>Entidad File actualizada.</returns>
        File changeDeletedState(string userID, int FileId, bool state);

        /// <summary>
        /// Obtiene todos los ficheros no eliminados de un path concreto.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="parentPath">Path donde se buscan los ficheros.</param>
        /// <returns>Lista de ficheros buscados.</returns>
        IList<File> getNotDeletedFiles(string userID, string parentPath);

        /// <summary>
        /// Obtiene todas las carpetas encontradas en un path concreto.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="path">Path donde se buscan las carpetas.</param>
        /// <returns>Lista con las carpetas encontradas en el path.</returns>
        IList<File> getFolders(string userID, string path);

        /// <summary>
        /// Obtiene todos los ficheros cuyo nombre contiene el texto que el usuario ha buscado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="searchText">Texto de la búsqueda.</param>
        /// <param name="results">Lista con todos los ficheros.</param>
        void searchFiles(string userID, string searchText, IList<SearchResult> results);

        /// <summary>
        /// Cambia el tamaño de una carpeta en la entidad File que es buscada por el nombre de su padre
        /// y el nombre de la propia carpeta. (El nombre es único en una carpeta concreta).
        /// </summary>
        /// <param name="parentOfParent">Nombre del fichero padre de la carpeta a cambiar.</param>
        /// <param name="parentName">Nombre de la carpeta a cambiar.</param>
        /// <param name="size">Nuevo tamaño de la carpeta.</param>
        /// <param name="userID">Id del usuario</param>
        void updateFolderSize(string parentOfParent, string parentName, int size,string userID);

        /// <summary>
        /// Obtiene un fichero de tipo carpeta por su id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="folderID">Id de la carpeta</param>
        /// <returns>Entidad File con los datos de la carpeta.</returns>
        File getFolder(string userID, int folderID);

        /// <summary>
        /// Cambia el path de un fichero en la entidad File pasada como parámetro.
        /// </summary>
        /// <param name="file">Fichero que debe ser cambiado</param>
        /// <param name="newParentPath">Nuevo path</param>
        void changeParentPath(File file, string newParentPath);

        /// <summary>
        /// Obtiene todos los ficheros que se encuentran en un path concreto.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="path">Path donde se encuentran los ficheros.</param>
        /// <returns>Lista de ficheros.</returns>
        IList<File> getFiles(string userID, string path);

        /// <summary>
        /// Cambia el path de un fichero, busca la entidad File por su id.
        /// </summary>
        /// <param name="newParentPath">Nuevo path del fichero.</param>
        /// <param name="fileID">Id del fichero</param>
        /// <param name="userID">Id del usuario</param>
        void changeParentPath(string newParentPath, int fileID, string userID);

        /// <summary>
        /// Crea una carpeta física y crea una entidad File.
        /// </summary>
        /// <param name="name">Nombre de la carpeta a crear.</param>
        /// <param name="parentPath">Path donde se crea la carpeta.</param>
        /// <param name="userID">Id del usuario</param>
        void createFolder(string name, string parentPath, string userID);

        /// <summary>
        /// Mueve un fichero a otra carpeta.
        /// </summary>
        /// <param name="file">Fichero a mover</param>
        /// <param name="folder">Carpeta destino del fichero</param>
        /// <param name="userID">Id del usuario</param>
        void move(File file, File folder, string userID);

        /// <summary>
        /// Sube un fichero físico y crea una entidad File.
        /// </summary>
        /// <param name="uploadedFile">Fíchero a subir</param>
        /// <param name="parentPath">Path donde se debe subir el fichero.</param>
        /// <param name="userID">Id del fichero</param>
        void upload(HttpPostedFileBase uploadedFile, string parentPath,string userID);

        /// <summary>
        /// Cambia el nombre de una carpeta.
        /// </summary>
        /// <param name="file">Fichero (de tipo carpeta) cuyo nombre va a ser cambiado.</param>
        /// <param name="filename">Nuevo nombre del fichero.</param>
        /// <param name="userID">Id del usuario</param>
        void changeFolderName(File file, string filename, string userID);

        /// <summary>
        /// Obtiene todos los ficheros que estén dentro del fichero (si es de tipo carpeta). Se introducen los ids encontrados
        /// en la lista especificada en el tercer parámetro.
        /// </summary>
        /// <param name="userID">ID del usuario</param>
        /// <param name="file">Id del fichero contenedor</param>
        /// <param name="ids">Lista de los ids de los ficheros contenidos en la carpeta.</param>
        void getFilesID(string userID, File file, IList<int> ids);
    }
}