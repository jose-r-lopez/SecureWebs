﻿using FileSync.Models;
using FileSync.Models.ViewModels;
using Microsoft.Owin.Security;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web;

namespace FileSync.Managers.Interfaces
{
    /// <summary>
    /// Interfaz de la clase que implementa la lógica de negocio relacionada con los usuarios.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public interface IUserManager
    {
        /// <summary>
        /// Obtiene el objeto ApplicationUserManager que permite varias operaciones con usuarios.
        /// </summary>
        /// <param name="context">Contexto Http</param>
        /// <returns>Objeto ApplicationUserManager</returns>
        ApplicationUserManager getUserAppManager(HttpContextBase context);

        /// <summary>
        /// Obtiene el objeto AuthenticationManager que permite varias operaciones de autenticación de usuarios.
        /// </summary>
        /// <param name="context">Contexto Http</param>
        /// <returns>Objeto AuthenticationManager</returns>
        IAuthenticationManager getAuthenticationManager(HttpContextBase context);

        /// <summary>
        /// Inicia sesión de un usuario
        /// </summary>
        /// <param name="user">Usuario que inicia sesión</param>
        /// <param name="isPersistent">Boolean que indica si es persistente o no.</param>
        /// <param name="context">Contexto http</param>
        /// <returns></returns>
        Task SignInAsync(ApplicationUser user, bool isPersistent, HttpContextBase context);

        /// <summary>
        /// Cierra sesión de un usuario.
        /// </summary>
        /// <param name="context">Contexto http</param>
        void SignOut(HttpContextBase context);

        /// <summary>
        /// Obtiene un usuario por su id.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns></returns>
        ApplicationUser getUser(string userID);
        
        /// <summary>
        /// Obtiene las notificaciones recibidas por un usuario
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns></returns>
        IList<Notification> getReceivedNotifications(string userID);

        /// <summary>
        /// Cambia el nombre y los apellidos de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="name">Nuevo nombre del usuario</param>
        /// <param name="surname">Nuevo apellido del usuario.</param>
        /// <returns></returns>
        int setCompleteName(string userID, string name, string surname);

        /// <summary>
        /// Borra la notificación de un usuario
        /// </summary>
        /// <param name="notificationID">Id de la notificación a borrar</param>
        void deleteNotification(int notificationID);

        /// <summary>
        /// Obtiene el número de notificaciones de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Número de notificaciones</returns>
        int getNumberOfReceivedNotifications(string userID);

        /// <summary>
        /// Añade el tamaño de un fichero (en megabytes) al almacenamiento usado por el usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="size">Tamaño del fichero.</param>
        void addToStorage(string userID, long size);

        /// <summary>
        /// Obtiene el email de un usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Email del usuario</returns>
        string getEmailFromUser(string userID);

        /// <summary>
        /// Borra una notificación según su id.
        /// </summary>
        /// <param name="notificationID">Id de la notificacion.</param>
        void removeNotification(int notificationID);

        /// <summary>
        /// Crea una notificación para aceptar una notificación.
        /// </summary>
        /// <param name="receiverID">Id del usuario que recibe la notificación.</param>
        /// <param name="senderID">Id del usuario que envía la notificación</param>
        /// <param name="filename">Nombre del fichero rechazado</param>
        void createAcceptNotification(string receiverID, string senderID, string filename);

        /// <summary>
        /// Crea una notificación de rechazo a una compartición.
        /// </summary>
        /// <param name="receiverID">Id del usuario que recibe la notificación.</param>
        /// <param name="senderID">Id del usuario que envía la notificación</param>
        /// <param name="filename">Nombre del fichero rechazado.</param>
        void createRejectNotification(string receiverID, string senderID, string filename);

        /// <summary>
        /// Obtiene una notificación según su id.
        /// </summary>
        /// <param name="notificationID">Id de la notificación.</param>
        /// <returns>Notificación correspondiente al id, null sino existe.</returns>
        Notification getNotification(int notificationID);

        /// <summary>
        /// Resta el tamaño de un fichero en megabytes al almacenamiento del usuario.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="size">Tamaño de un fichero.</param>
        void subtractStorage(string userID, long size);

        /// <summary>
        /// Recoge los detalles de un usuario obtenidos a partir de su email.
        /// </summary>
        /// <param name="email">Email del usuario</param>
        /// <returns>Detalles del usuario (UserDetails)</returns>
        UserDetails getUserDetails(string email);
    }
}