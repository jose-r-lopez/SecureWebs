﻿using FileSync.Managers.Interfaces;
using FileSync.DAL.factory;
using FileSync.Models;
using System.Collections.Generic;
using System.Web;
using System.Web.Hosting;
using FileSync.Controllers;
using FileSync.Models.ViewModels;
using FileSync.DAL.Factory;

namespace FileSync.Managers
{
    /// <summary>
    /// Clase que implementa la lógica de negocio relacionada con los ficheros compartidos.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class FileSharedManager : IFileSharedManager
    {
        /// <summary>
        /// Instancia de la factoría para tener acceso a la capa de persistencia.
        /// </summary>
        private IPersistenceFactory persistenceFactory = PersistenceFactory.Instance;

        public void createUserSharePath(string path, string userID)
        {
            bool exists = System.IO.Directory.Exists(path + userID + "/share" + userID);

            if (!exists)
                System.IO.Directory.CreateDirectory(path + userID + "/share" + userID);

        }

        public string getUserSharedPath(HttpContextBase context) {
            return HostingEnvironment.MapPath("/Data/" + UserManager.UserID(context) + "/share" + UserManager.UserID(context) + "//");
        }

        public bool createShare(string currentEmail, string userID, int shareFileID, string name, string filename)
        {
            string shareUserID = persistenceFactory.getUserPersistence().getUserIDFromEmail(currentEmail);
            bool exists = persistenceFactory.getSharedFilePersistence().existsSharedFile(userID, shareUserID, shareFileID);

            if (shareUserID != null && !exists)
            {
                Notification notification = new Notification();
                notification.SenderId = userID;
                notification.ReceiverId = shareUserID;
                notification.Text = "El usuario " + name + " desea compartir el fichero " + filename + " contigo.";
                notification.onlyNotification = false;

                SharedFile sharedFile = new SharedFile();
                sharedFile.Approved = false;
                sharedFile.FileId = shareFileID;
                sharedFile.ShareUserId = shareUserID;
                sharedFile.UserId = userID;
                sharedFile.Notification = notification;

                persistenceFactory.getSharedFilePersistence().createShareWithNotificacion(notification, sharedFile);
                return true;
            }

            return false;
        }

        public IList<SharedFile> getApprovedSharedFiles(string userID){
            return persistenceFactory.getSharedFilePersistence().getApprovedSharedFiles(userID);
        }

        public void approve(SharedFile file)
        {
            persistenceFactory.getSharedFilePersistence().approveSharedFile(file);
        }

        public SharedFile getSharedFileFromNotification(int notificationID)
        {
            return persistenceFactory.getSharedFilePersistence().getSharedFileFromNotification(notificationID);
        }

        public void removeFromNotification(int notificationID)
        {
            persistenceFactory.getSharedFilePersistence().removeSharedFileFromNotification(notificationID);
        }

        public void remove(SharedFile file)
        {
            persistenceFactory.getSharedFilePersistence().removeSharedFile(file);
        }

        public SharedFile getApprovedSharedFile(int fileID, string userID)
        {
            return persistenceFactory.getSharedFilePersistence().getApproveSharedFile(fileID, userID);
        }

        public IList<SharedFile> getApprovedSharedFilesSameUser(int fileID, string userId)
        {
            return persistenceFactory.getSharedFilePersistence().getApprovedSharedFilesFromSameUser(fileID, userId);
        }

        public void searchSharedFile(string userID, string searchText, IList<SearchResult> results)
        {
            IList<SharedFile> sharedFiles = persistenceFactory.getSharedFilePersistence().getApprovedSharedFiles(userID, searchText);
            foreach (FileSync.Models.SharedFile file in sharedFiles)
            {
                results.Add(new SearchResult(file.File.Filename, "Compartidos"));
            }

        }

        public void acceptSharing(File file, string path, SharedFile sharedFile){
           
            if (!file.IsFolder)
            {
                string name = "";
                if (System.IO.File.Exists(path + file.Filename))
                {
                    name = FileUtils.getName(path, file.Filename);
                }
                else
                {
                    name = file.Filename;
                }

                System.IO.File.Copy(file.ParentPath + file.Filename, path + name, true);
            }

            //actualizamos los datos de la comparticion
            approve(sharedFile);
        }
    }
}