﻿using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using FileSync.Models;
using System.Threading.Tasks;
using System.Web.Hosting;
using FileSync.Managers.Interfaces;
using FileSync.DAL.factory;
using System.Collections.Generic;
using FileSync.Controllers.Utils;
using FileSync.Models.ViewModels;
using System;
using FileSync.DAL.Factory;

namespace FileSync.Managers
{
    /// <summary>
    /// Clase que implementa la lógica de negocio relacionada con los usuarios.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class UserManager : IUserManager
    {
        /// <summary>
        /// Path donde se ubica la carpeta del usuario.
        /// </summary>
        public static string globalPath = HostingEnvironment.MapPath("/Data/");

        /// <summary>
        /// Almacenamiento máximo que puede usar un usuario.
        /// </summary>
        public const double maxStorage = 100;

        /// <summary>
        /// Tamaño de archivo máximo.
        /// </summary>
        public const double maxFileSize = 20;

        /// <summary>
        /// Instancia de ApplicationUserManager
        /// </summary>
        private ApplicationUserManager _UserAppManager;

        /// <summary>
        /// Instancia de IAuthenticationManager
        /// </summary>
        private IAuthenticationManager _AuthenticationManager;

        /// <summary>
        /// Instancia de la factoría para tener acceso a la capa de persistencia.
        /// </summary>
        private IPersistenceFactory persistenceFactory = PersistenceFactory.Instance;

        public static string UserID(HttpContextBase context)
        {
            return context.User.Identity.GetUserId();
        }

        public ApplicationUserManager getUserAppManager(HttpContextBase context)
        {
             _UserAppManager = context.GetOwinContext().GetUserManager<ApplicationUserManager>();
            return _UserAppManager;
        }

        public IAuthenticationManager getAuthenticationManager(HttpContextBase context)
        {
            _AuthenticationManager = context.GetOwinContext().Authentication;
            return _AuthenticationManager; 
        }

        public async Task SignInAsync(ApplicationUser user, bool isPersistent, HttpContextBase context)
        {
            getAuthenticationManager(context).SignOut(DefaultAuthenticationTypes.ExternalCookie);
            getAuthenticationManager(context).SignIn(new AuthenticationProperties() { IsPersistent = isPersistent }, await user.GenerateUserIdentityAsync(_UserAppManager));
        }

        public void SignOut(HttpContextBase context)
        {
            getAuthenticationManager(context).SignOut(DefaultAuthenticationTypes.ApplicationCookie);
        }

        public ApplicationUser getUser(string userID){
            return persistenceFactory.getUserPersistence().getUser(userID);
        }

        public IList<Notification> getReceivedNotifications(string userID)
        {
            return persistenceFactory.getNotificationPersistence().getReceivedNotifications(userID);
        }

        public int setCompleteName(string userID, string name, string surname)
        {
            return persistenceFactory.getUserPersistence().setUserCompleteName(userID, name, surname);
        }

        public void deleteNotification(int notificationID){
            persistenceFactory.getNotificationPersistence().deleteNotification(notificationID);
        }

        public int getNumberOfReceivedNotifications(string userID)
        {
            return persistenceFactory.getNotificationPersistence().getNumberOfReceivedNotifications(userID);
        }

        public void addToStorage(string userID, long size)
        {
            persistenceFactory.getUserPersistence().addUserStorage(userID, Math.Round(ByteToMegabyteConverter.Convert(size),2));
        }

        public void subtractStorage(string userID, long size)
        {
            persistenceFactory.getUserPersistence().subtractUserStorage(userID, Math.Round(ByteToMegabyteConverter.Convert(size),2));
        }

        public string getEmailFromUser(string userID)
        {
            return persistenceFactory.getUserPersistence().getEmailFromUser(userID);
        }

        public void removeNotification(int notificationID)
        {
            persistenceFactory.getNotificationPersistence().removeNotification(notificationID);
        }

        public void createAcceptNotification(string receiverID, string senderID, string filename)
        {
            string email = getEmailFromUser(receiverID);
            persistenceFactory.getNotificationPersistence().createNotification(receiverID, senderID,
                        "El usuario " + email + " ha aceptado compartir el fichero " + filename + " contigo", true);
        }

        public void createRejectNotification(string receiverID, string senderID, string filename)
        {
            string email = getEmailFromUser(receiverID);
            persistenceFactory.getNotificationPersistence().createNotification(receiverID, senderID,
                       "El usuario " + email + " ha rechazado compartir el fichero " + filename + " contigo", true);
        }

        public Notification getNotification(int notificationID)
        {
            return persistenceFactory.getNotificationPersistence().getNotification(notificationID);
        }

        public UserDetails getUserDetails(string email)
        {
            return persistenceFactory.getUserPersistence().getUserDetails(email);
        }
    }
}