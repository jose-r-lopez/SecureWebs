﻿using FileSync.Managers.Interfaces;
using FileSync.DAL.factory;
using FileSync.Models;
using System.Collections.Generic;
using System.Web;
using System.Web.Hosting;
using FileSync.Controllers;
using System;
using FileSync.Models.ViewModels;
using FileSync.DAL.Factory;

namespace FileSync.Managers
{
    /// <summary>
    /// Clase que implementa la lógica de negocio relacionada con los ficheros borrados.
    /// Autor: Leticia del Valle Varela
    /// </summary>
    public class DeletedFileManager : IDeletedFileManager
    {
 
        /// <summary>
        /// Instancia de la factoría para tener acceso a la capa de persistencia.
        /// </summary>
        private IPersistenceFactory persistenceFactory = PersistenceFactory.Instance;

        /// <summary>
        /// Crea la ruta que va a contener los ficheros borrados.
        /// </summary>
        /// <param name="path">Path donde la aplicación guarda los ficheros de los usuarios.</param>
        /// <param name="userID">Id del usuario</param>
        public void createDeletedFileUserPath(string path, string userID)
        {
            bool exists = System.IO.Directory.Exists(path + userID + "/bin" + userID);

            if (!exists)
                System.IO.Directory.CreateDirectory(path + userID + "/bin" + userID);
        }

        /// <summary>
        /// Obtiene la ruta usada para guardar los ficheros físicos que han sido eliminados por el usuario.
        /// </summary>
        /// <param name="context">Contexto Http</param>
        /// <returns>Ruta base de los ficheros.</returns>
        public string getDeletedFilesUserPath(HttpContextBase context)
        {
            return HostingEnvironment.MapPath("/Data/" + UserManager.UserID(context) + "/bin" + UserManager.UserID(context) + "/");

        }

        public string getDeletedFilesUserPath(string userID)
        {
            return HostingEnvironment.MapPath("/Data/" + userID + "/bin" + userID + "/");

        }


        /// <summary>
        /// Recorre el contenido de una carpeta para ir borrando su contenido. Usada en la operación de destruir.
        /// </summary>
        /// <param name="path">Path donde se encuentra la carpeta a recorrer.</param>
        /// <param name="userID">Id del usuario</param>
        public void removeAll(string path, string userID)
        {
            IList<File> filesInFolder = persistenceFactory.getFilePersistence().getDeletedFiles(userID, path + "\\");

            foreach (File file in filesInFolder)
            {

                if (file.IsFolder)
                {
                    removeAll(file.ParentPath + file.Filename, userID);
                }

                persistenceFactory.getFilePersistence().removeFile(file);
            }
        }

        /// <summary>
        /// Marca un fichero como borrado o como no borrado. Si es una carpeta recorre todo su contenido y
        /// marca todo su contenido con el mismo estado que el padre.
        /// </summary>
        /// <param name="path">Path donde se encuentra el fichero a marcar.</param>
        /// <param name="state">Nuevo estado del fichero.</param>
        /// <param name="userID">Id del usuario</param>
        public void updateDeletedFlag(string path, bool state, string userID)
        {

            IList<File> filesInFolder = persistenceFactory.getFilePersistence().getFiles(userID, path + "\\");

            foreach (File file in filesInFolder)
            {

                persistenceFactory.getFilePersistence().changeDeletedState(file, state);

                if (file.IsFolder)
                {
                    updateDeletedFlag(file.ParentPath + file.Filename, state, userID);
                }
            }

        }

        /// <summary>
        /// Obtiene una lista de todos los fichero eliminados.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Lista con todos los ficheros eliminados.</returns>
        public IList<File> getDeletedFiles(string userID){
            return persistenceFactory.getDeletedFilePersistence().getDeletedFiles(userID);
        }

        /// <summary>
        /// Obtiene la entidad DeletedFile del fichero que ha sido borrado. Se busca por el id de la entidad File asociada.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="fileID">Id de la entidad File.</param>
        /// <returns>DeltedFile encontrado o null si no se encuentra.</returns>
        public DeletedFile getDeletedFile(string userID, int fileID)
        {
            return persistenceFactory.getDeletedFilePersistence().getDeletedFile(userID, fileID);
        }

        /// <summary>
        /// Borra la entidad DeletedFile junto con la entidad File asociada.
        /// </summary>
        /// <param name="deleted">DeletedFile a borrar</param>
        /// <param name="file">File a borrar</param>
        public void removeDeletedFile(DeletedFile deleted, File file)
        {
            persistenceFactory.getDeletedFilePersistence().removeDeletedFile(deleted, file);
        }

        /// <summary>
        /// Borra la entidad DeletedFile pasada como parámetro.
        /// </summary>
        /// <param name="deleted">DeletedFile a borrar</param>
        public void removeDeletedFile(DeletedFile deleted)
        {
            persistenceFactory.getDeletedFilePersistence().removeDeletedFile(deleted);
        }

        /// <summary>
        /// Crea una entidad DeletedFile asociada a un fichero cuando se desea borrar éste. 
        /// </summary>
        /// <param name="fileID">Id del fichero a borrar</param>
        /// <param name="filename">Nombre del fichero en la papelera</param>
        public void createDeletedFile(int fileID, string filename)
        {
            persistenceFactory.getDeletedFilePersistence().createDeletedFile(fileID, filename);
        }

        /// <summary>
        /// Busca todos los ficheros eliminados cuyos nombre contiene el texto que el usuario ha buscado.
        /// </summary>
        /// <param name="userID">Id del usuario</param>
        /// <param name="searchText">Texto que el usuario ha buscado.</param>
        /// <param name="results">Lista a la que se debe añadir todos los ficheros encontrados.</param>
        public void searchDeletedFiles(string userID, string searchText, IList<SearchResult> results)
        {
            IList<FileSync.Models.File> deletedFiles = persistenceFactory.getDeletedFilePersistence().getDeletedFiles(userID, searchText);
            foreach (FileSync.Models.File file in deletedFiles)
            {
                string[] path = file.ParentPath.Split(new string[] { userID }, StringSplitOptions.None);
                results.Add(new SearchResult(file.Filename, "Papelera"));
            }

        }

        /// <summary>
        /// Borra un fichero. Marca el fichero (File) como borrado.
        /// El fichero físico se mueve a la carpeta destinada a ser la papelera del usuario.
        /// </summary>
        /// <param name="file">Fichero a borrar</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="context">Contexto Http</param>
        public void delete(File file, string userID, HttpContextBase context)
        {

            if (file.IsFolder)
            {
                updateDeletedFlag(file.ParentPath + file.Filename, true, userID);
            }

            string binpath = getDeletedFilesUserPath(context);
            //se mueve a la carpeta bin, si ya existe se renombra

            string name = "";
            if (file.IsFolder)
            {
                bool isExists = System.IO.Directory.Exists(binpath + file.Filename);
                name = getName(isExists, file.Filename, binpath);
                System.IO.Directory.Move(file.ParentPath + file.Filename, binpath + name);
            }
            else
            {
                bool isExists = System.IO.File.Exists(binpath + file.Filename);
                name = getName(isExists, file.Filename, binpath);
                System.IO.File.Move(file.ParentPath + file.Filename, binpath + name);
            }

            createDeletedFile(file.Id, name);
        }

        /// <summary>
        /// Restaura un fichero. Marca como no borrado el fichero File. Si el fichero es una carpeta 
        /// y contiene otros ficheros también deben actualizarse.
        /// </summary>
        /// <param name="file">Fichero a restaurar.</param>
        /// <param name="binfile">DeletedFile asociado al fichero.</param>
        /// <param name="binpath">Path de la papelera.</param>
        /// <param name="userID">Id del usuario</param>
        /// <returns>Nuevo nombre si al restaurar a la carpeta original ya existía un fichero con el mismo nombre.</returns>
        public string restore(File file, DeletedFile binfile, string binpath, string userID)
        {
            string name = "";

            if (file != null)
            {

                if (file.IsFolder)
                {
                    updateDeletedFlag(file.ParentPath + file.Filename, false, userID);
                    name = restoreFolder(file, binfile, binpath);
                }
                else
                {
                    name = restoreFile(file, binfile, binpath);
                }
            }

            removeDeletedFile(binfile);

            return name;  
        }

        /// <summary>
        /// Destruye un fichero físico marcado como eliminado. Después invoca a  removeDeletedFile() para borrar la entidad File 
        /// y su entidad DeletedFile asociada.
        /// </summary>
        /// <param name="file">Entidad File a destruir.</param>
        /// <param name="userID">Id del usuario</param>
        /// <param name="binpath">Path donde se encuentra el fichero físico.</param>
        /// <param name="binfile">Entidad DeletedFile a destruir.</param>
        public void destroy(File file, string userID, string binpath, DeletedFile binfile)
        {
            if (file != null)
            {
                if (file.IsFolder)
                {

                    System.IO.Directory.Delete(binpath + binfile.BinName, true);
                    removeAll(file.ParentPath + file.Filename, userID);
                }
                else
                {
                    System.IO.File.Delete(binpath + binfile.BinName);
                }
            }

            removeDeletedFile(binfile, file);
        }

        private string restoreFolder(File file, DeletedFile binfile, string binpath)
        {
            if (!System.IO.Directory.Exists(file.ParentPath))
                System.IO.Directory.CreateDirectory(file.ParentPath);

            if (!System.IO.Directory.Exists(file.ParentPath + file.Filename))
            {
                System.IO.Directory.Move(binpath + binfile.BinName, file.ParentPath + file.Filename);
                return null;
            }
            else
            {
                string name = FileUtils.getName(file.ParentPath, file.Filename);
                System.IO.Directory.Move(binpath + binfile.BinName, file.ParentPath + name);
                return name;
            }
        }

        private string restoreFile(File file, DeletedFile binfile, string binpath)
        {
            if (!System.IO.Directory.Exists(file.ParentPath))
                System.IO.Directory.CreateDirectory(file.ParentPath);

            if (!System.IO.File.Exists(file.ParentPath + file.Filename))
            {
                System.IO.File.Move(binpath + binfile.BinName, file.ParentPath + file.Filename);
                return null;
            }
            else
            {
                string name = FileUtils.getName(file.ParentPath, file.Filename);
                System.IO.File.Move(binpath + binfile.BinName, file.ParentPath + name);
                return name;
            }
        }

        private string getName(bool isExists, string filename, string binpath){
            if (!isExists)
            {
                return filename;
            }
            else
            {
                return FileUtils.getName(binpath, filename);
            }
        }
    }
}

