﻿$(document).ready(function () {
    initializeBinTable();
    createContextmenu();
    openContextMenu(); 
});


function initializeBinTable() {

    table = $('#binTable').DataTable({

        "oLanguage": {
            "sEmptyTable": "No hay ficheros eliminados"
        },
        "order": [[2, "desc"]],
        aoColumnDefs: [
          { aTargets: [0], bSortable: false }],
        "paging": false,
        "info": false,
        "aoColumns": [
            { "sClass": "dt-center" },
            { "sClass": "name" },
            { "sClass": "dt-center" },
            { "sClass": "dt-center" },
            { "sClass": "dt-center" }
        ],
        "bRetrieve": true,
        "bDestroy": true
    });
}

function openContextMenu() {
    $("#triggerPopup").click(function () {

        $(document).contextmenu("open", $(".hasbinmenu"));
        setTimeout(function () { $(document).contextmenu("close"); }, 100);
    });
}

function createContextmenu() {
    $(document).contextmenu({
        delegate: ".hasbinmenu",
        menu: "#binoptions",
        beforeOpen: function (event, ui) {
            ui.target.closest('tr').find("input").prop('checked', true);
            ids = [];
            if ($('.binfileSelect:checked').length > 1) {
                $('.binfileSelect').each(function () {
                    if ($(this).prop('checked')) {
                        var selectedID = $(this).val();
                        ids.push(selectedID);
                    }
                });
            } else {
                var selectedID = ui.target.closest('tr').find("input").val();
                ids.push(selectedID);
            }
        },
        select: function (event, ui) {

            if (ui.cmd == "destroy") 
                destroy(event, ui);
            
            if (ui.cmd == "restore") 
                restore(event, ui);
        }
    });
}


function destroy(event, ui) {

    var parms = {
        ids: ids
    };

    $.ajax({
        type: "POST",
        traditional: true,
        url: $("#destroyCM").data('request-url'),
        async: false,
        data: parms,
        dataType: "json",
        success: function (data) {
            $('#active_part').html(data.vista);
            initializeBinTable();
        }
    });
}

function restore(event, ui) {
    $("#confirmDialog").html("¿Está seguro que quiere restaurar el archivo?");

    $("#confirmDialog").dialog({
        resizable: false,
        modal: true,
        width: "25%",
        title: "Confirmar restaurar archivo",
        buttons: {
            "Si": function () {
                $(this).dialog('close');
                var parms = {
                    ids: ids
                };

                $.ajax({
                    type: "POST",
                    traditional: true,
                    url: $("#restoreCM").data('request-url'),
                    async: false,
                    data: parms,
                    dataType: "json",
                    success: function (data) {
                        $('#active_part').html(data.vista);
                        initializeBinTable();
                    }
                });
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
}