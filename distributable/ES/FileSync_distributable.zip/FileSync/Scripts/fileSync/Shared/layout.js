﻿$(document).ready(function () {
    $('#searchText').keypress(function (e) {
        if (e.which == 13) {
            $('#searchForm').submit();
        }
    });
});