﻿$(document).ready(function () {
    var value = $("#progressbar").data('storage');
    $("#progressbar").progressbar({
        value: value
    });

    $(".progress-label").text(value + "%");
    $("#notifications a").button();
    $("#profileData a").button();
});