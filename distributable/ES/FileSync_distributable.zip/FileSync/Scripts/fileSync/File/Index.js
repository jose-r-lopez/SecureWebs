﻿$(document).ready(function () {
    initializeDatatable();
    createUploader();
    createShareDialog();
    createChangeNameDialog();
    createCreateDialog();
    createUploadDialog();
    createContextMenu();
});

function createCreateDialog() {
    $("#createDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Crear carpeta",
        width: "35%",
        height: 105
    });

    $('#create').on('click', function () {
        $("#createDialog").dialog("open");
    });
}

function createUploadDialog() {
    $("#uploadDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Subir fichero",
        height: "auto",
        width: 500,
        close: function (ev, ui) {
            $("#progress .bar").text("").css('width', 0);
            $("#result").empty();
        },
        buttons: {
            Ok: function () {
                $(this).dialog("close");
            }
        },
    });

    $('#upload').on('click', function () {
        $("#uploadDialog").dialog("open");
    });
}

function initializeDatatable() {

    table = $('#filesTable').DataTable({

        "oLanguage": {
            "sEmptyTable": "No hay ficheros subidos"
        },
        "order": [[2, "desc"]],
        aoColumnDefs: [
          { aTargets: [0], bSortable: false }],
        "paging": false,
        "info": false,
        "aoColumns": [
            { "sClass": "dt-center" },
            { "sClass": "name" },
            { "sClass": "dt-center" },
            { "sClass": "dt-center" }
        ],
        "bRetrieve": true,
        "bDestroy": true
    });

}

function createUploader() {
    $('#fileupload').fileupload({
        dataType: 'json',
        singleFileUploads: true,
        autoUpload: false,
        add: function (e, data) {
            $("#progress .bar").text("").css('width', 0);
            $("#result").empty();
            var goUpload = true;

            var uploadFile = data.files[0];

            if (uploadFile.size > 20971520) {
                goUpload = false;
            }

            data.context = $('<p/>').text('Subiendo ' + uploadFile.name).appendTo('#result');
            if (goUpload == true) {
                data.submit();
            } else {
                data.context.text('Fichero demasiado grande');
            }

        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10),
                meter = $('#progress .bar'),
                percent = progress + '%';
            meter.css('width', percent).text(percent);
        },
        done: function (e, data) {

            $('#active_part').html(data.result.vista);
            initializeDatatable();

            if (data.result.status === "error") {
                $("#uploadDialog").dialog("close");
            } else {
                var uploadFile = data.files[0];
                data.context.text(uploadFile.name + ' ha sido subido con éxito.');
            }
        }
    });
}

function createContextMenu() {
    $(document).contextmenu({
        delegate: ".hasmenu",
        menu: "#options",
        beforeOpen: function (event, ui) {
            ui.target.closest('tr').find("input").prop('checked', true);

            ids = [];
            if ($('.fileSelect:checked').length > 1) {
                $('.fileSelect').each(function () {
                    if ($(this).prop('checked')) {
                        var selectedID = $(this).val();
                        ids.push(selectedID);
                    }
                });

                $(document).contextmenu("enableEntry", "changeName", false);
                $(document).contextmenu("enableEntry", "properties", false);
                $(document).contextmenu("enableEntry", "download", false);
                $(document).contextmenu("enableEntry", "share", false);
                $(document).contextmenu("enableEntry", "move", false);
            } else {

                $(document).contextmenu("enableEntry", "changeName", true);
                $(document).contextmenu("enableEntry", "properties", true);
                $(document).contextmenu("enableEntry", "download", true);
                $(document).contextmenu("enableEntry", "move", true);

                if (ui.target.closest('tr').find("img").hasClass("folder")) {
                    $(document).contextmenu("enableEntry", "share", false);
                    $(document).contextmenu("enableEntry", "download", false);
                } else {
                    $(document).contextmenu("enableEntry", "share", true);
                    $(document).contextmenu("enableEntry", "download", true);
                }

                var selectedID = ui.target.closest('tr').find("input").val();
                ids.push(selectedID);

            }
        },
        select: function (event, ui) {
            if (ui.cmd === "download") {
                download(event, ui);
            }else if (ui.cmd == "changeName") {
                changeName(event, ui);
            }else if (ui.cmd == "moveToBin") {
                moveToBin(event, ui);
            }else if (ui.cmd === "move") {
                move(event, ui);   
            }else if (ui.cmd == "properties") {
                properties(event, ui);
            }else if (ui.cmd == "share") {
                share(event, ui);
            }
        }
    });
}

function download(event, ui) {
    $.get($("#downloadCM").data('request-url'),
        { fileID: ui.target.closest("tr").find("input").val() }, function (data) {
            window.location = $("#downloadCM").data('request-url') + "?fileID=" + ui.target.closest("tr").find("input").val();
        });
}

function changeName(event, ui) {
    $(document).contextmenu("close", $(".demo"));
    oldName = ui.target.closest("tr").find(".name").text();
    fileID = ui.target.closest("tr").find("input").val();
    $("#changeNameDialog").dialog("open");

}

function createChangeNameDialog() {
    $("#changeNameDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Cambiar nombre",
        height: 130,
        width: 500,
        open: function (event, ui) {
            $("#changeNameDialog #newName").val(oldName);
            $("#changeNameDialog input[name='fileID']").val(fileID);
            oldName = "";
            fileID = "";
        }
    });

    $('#changeNameSubmit').on('click', function () {
        $("#changeNameDialog").dialog("close");
    });
}

function moveToBin(event, ui) {

        var parms = {
            ids: ids
        };

        $.ajax({
            type: "POST",
            traditional: true,
            url: $("#deleteCM").data('request-url'),
            data: parms,
            dataType: "json",
            success: function (data) {
                $('#active_part').html(data.vista);
                initializeDatatable();
            }
        });

}

function move(event, ui) {
    $.post($("#moveCM").data('request-url'),
        { fileID: ui.target.closest("tr").find("input").val() }, function (data) {
            var result = $('<div />').append(data).find('#moveDialog').html();
            if (result == null) {
                $('#active_part').html(data);
                initializeDatatable();
            } else {
                createMoveDialog();
                $('#moveDialog').html(result);
                $("#moveDialog").dialog("open");
            }
        });
}

function createMoveDialog() {
    $("#moveDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Subir fichero",
        width: 500,
        height : 250
    });
}

function properties(event, ui) {
    $.post($("#propertiesCM").data('request-url'),
        { fileID: ui.target.closest("tr").find("input").val() },
        function (data) {
            var result = $('<div />').append(data).find('#propertiesDialog').html();
            createPropertiesDialog();
            $('#propertiesDialog').html(result);
            $("#propertiesDialog").dialog("open");
        });
}

function createPropertiesDialog() {
    $("#propertiesDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Propiedades del fichero",
        width: 500,
        buttons: [
    {
        text: "OK",
        click: function () {
            $(this).dialog("close");
        }
    }
        ]
    });
}

function share(event, ui) {
    $("#confirmDialog").html("¿Está seguro que quiere compartir el archivo " + ui.target.closest("tr td:nth-child(2)").text() + " el archivo?");


    $("#confirmDialog").dialog({
        resizable: false,
        modal: true,
        width: "25%",
        title: "Confirmar compartir archivo",
        buttons: {
            "Si": function () {
                $(this).dialog('close');
                shareID = ui.target.closest("tr").find("input").val();
                $("#shareResults").empty();
                $("#shareDialog").dialog("open");
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
}

function createShareDialog() {
    $("#shareDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Compartir",
        width: 525,
        open: function (event, ui) {
            $("#shareDialog #fileID").val(shareID);
            shareID = "";
        }
    });
}

function afterCreateFolder(data) {
    $("#createDialog").dialog("close");
    initializeDatatable();
    $("#newFolder").val("");
}

function afterChangeName(data) {
    initializeDatatable();
}

function movefolderlist(data) {
    var result = $('<div />').append(data).find('#moveDialog').html();
    $('#moveDialog').html(result);
}

function validateSelectedFolder() {
    if (!$("input[name='selectedFolder']:checked").val())
        return false;
}

function moveSuccess(data) {
    $("#moveDialog").dialog("close");
    initializeDatatable();
}