﻿$(document).ready(function () {
    
    $("#searchShareUser").click(function () {
        if ($('.shareUser').length <= 5) {
            getUser($("#shareUser").val());
            $("#shareUser").val("");
        }
    });

    $("#shareSubmit").click(function () {
        if ($("#shareResults").children().length <= 0) {
            return false;
        }

        $('<input>').attr({
            type: 'hidden',
            id: 'shareIDs',
            name: 'shareIDs'
        }).appendTo('#shareform');

        var c = "";
        $("#shareResults").children().each(function () {
            var data = $(".email", this).text();
            c += data + " ";
        });

        $("#shareIDs").val(c);
        return true;
    });

});

function getUser(email) {
    $.post($("#searchShareUser").data('request-url'),
        { userEmail: email },
        function (data) {
            if (data.Email != null)
                $("#shareResults").append(
                    $("<div />").addClass("shareUser")
                                .append($("<p/>").text(data.Name).addClass("userNameShare")
                                .append($("<span/>").text(" (" + data.Email + ")").addClass("email"))
                                .append($("<img />").addClass("aspa").attr("alt", "Eliminar").attr("title", "Eliminar usuario"))));


            $("#shareResults img").click(function () {
                $(this).parent().remove();
            });
        });
}

function finishShare() {
    $("#shareDialog").dialog("close");
}