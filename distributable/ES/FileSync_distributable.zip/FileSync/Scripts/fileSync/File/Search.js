﻿$(document).ready(function () {
    initializeDatatable();   
});

function initializeDatatable() {

    table = $('#searchTable').DataTable({

        "oLanguage": {
            "sEmptyTable": "No existen resultados para esa búsqueda."
        },
        "order": [[0, "desc"]],
        aoColumnDefs: [
          { aTargets: [0], bSortable: false }],
        "paging": false,
        "info": false,
        "aoColumns": [
            { "sClass": "dt-center" },
            { "sClass": "dt-center" },
        ],
        "bRetrieve": true,
        "bDestroy": true
    });

}