﻿$(document).ready(function () {
    initializeDatatable();
    createContextMenu();
    openContextMenu();
});

function initializeDatatable() {

    table = $('#sharefilesTable').DataTable({

        "oLanguage": {
            "sEmptyTable": "No hay ficheros subidos"
        },
        "order": [[1, "desc"]],
        aoColumnDefs: [
          { aTargets: [0], bSortable: false }],
        "paging": false,
        "info": false,
        "aoColumns": [
            { "sClass": "dt-center" },
            { "sClass": "dt-center" },
            { "sClass": "dt-center" },
            { "sClass": "dt-center" }
        ],
        "bRetrieve": true,
        "bDestroy": true
    });

}

function createContextMenu() {
    $(document).contextmenu({
        delegate: ".hassharedmenu",
        menu: "#shareoptions",
        beforeOpen: function (event, ui) {
            ids = new Array();
            if ($('.fileSelect:checked').length > 1) {
                $('.fileSelect').each(function () {
                    if ($(this).prop('checked')) {
                        var selectedID = $(this).closest("tr td:first-child").attr('id');
                        ids.push(selectedID);
                    }
                });

                $(document).contextmenu("enableEntry", "shareProperties", false);
            } else {
                $(document).contextmenu("enableEntry", "shareProperties", true);
            }

        },
        select: function (event, ui) {

            if (ui.cmd == "sharedownload"){
                download(event, ui);
            } else if (ui.cmd == "sharedelete"){
                deleteShared(event, ui);
            } else if (ui.cmd == "shareProperties")
                properties(event, ui);   
        }
    });
}

function openContextMenu(){
    $("#triggerPopup").click(function () {

        $(document).contextmenu("open", $(".menu"));
        setTimeout(function () { $(document).contextmenu("close"); }, 2000);
    });
}

function download(event, ui) {
    $.post($("#sharedownloadCM").data('request-url'),
    { id: ui.target.closest("tr td:first-child").attr('id') },
    function (data) {
        window.location = $("#sharedownloadCM").data('request-url') + "?id=" + ui.target.closest("tr td:first-child").attr('id');
    });
}

function deleteShared(event, ui) {
    $("#confirmDialog").html("¿Está seguro que quiere eliminar la compartición del archivo " + ui.target.closest("tr td:first-child").text() + " el archivo?");

    $("#confirmDialog").dialog({
        resizable: false,
        modal: true,
        width: "30%",
        title: "Confirmar compartir archivo",
        buttons: {
            "Si": function () {
                $(this).dialog('close');
                $.post($("#sharedeleteCM").data('request-url'),
               { id: ui.target.closest("tr td:first-child").attr('id') },
               function (data) {
                   $('#active_part').html(data.vista);
                   initializeDatatable();
               });
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
}

function properties(event, ui) {
    $.post($("#sharePropertiesCM").data('request-url'),
    { id: ui.target.closest("tr td:first-child").attr('id') },
    function (data) {
        var result = $('<div />').append(data).find('#propertiesDialog').html();
        $('#propertiesDialog').html(result);
        createDialog();
        $("#propertiesDialog").dialog("open");
    });
}

function createDialog() {
    $("#propertiesDialog").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        title: "Properties",
        width: 500,
        buttons: [
    {
        text: "OK",
        click: function () {
            $(this).dialog("close");
        }
    }
        ]
    });
}