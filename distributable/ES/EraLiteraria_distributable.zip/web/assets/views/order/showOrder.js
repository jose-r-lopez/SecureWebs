$(document).ready(function(){

$('#items').dataTable({ 
    	"iDisplayLength" : 50,
        "paging": false,
        "info": false,
    	"bStateSave": true,
    	"fnCookieCallback": function (sName, oData, sExpires, sPath) {
			delete oData["oSearch"];
		    return sName + "="+JSON.stringify(oData)+"; expires=" + sExpires +"; path=" + sPath;
		},
        "sServerMethod": "POST",
        "aoColumns": [
            { "sClass": "center"}, 
            { "sClass": "center"}, 
            { "sClass": "center"}, 
            { "sClass": "center"}, 
            { "sClass": "center"}, 
            { "sClass": "center"}, 
        ]

	});
});