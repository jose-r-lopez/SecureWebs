$(document).ready(function(){

$('#products').dataTable({ 
    	"iDisplayLength" : 50,
    	"sDom": '<"top"pfl>rt<"bottom"ip><"clear">',
        "oLanguage": {
           "sUrl": "../assets/languajes/Spanish.json"
        },
    	"bStateSave": true,
    	"fnCookieCallback": function (sName, oData, sExpires, sPath) {
			delete oData["oSearch"];
		    return sName + "="+JSON.stringify(oData)+"; expires=" + sExpires +"; path=" + sPath;
		},
        "sServerMethod": "POST",
        "aoColumns": [
            { "sClass": "center"}, 
            null, 
            { "sClass": "center"},  
            { "sClass": "center"}, 
            { "sClass": "center"}, 
            { "sClass": "center"}, 
        ]

	}).columnFilter(
        {
            bUseColVis: true,
            sPlaceHolder: "head:after" ,
            aoColumns: [
                { type: "text" }, 
                { type: "text" },
                { type: "number-range-symbols"},
                { type: "number-range-symbols"},
                { type: "number-range-symbols" },
                null,
            ]
        }
    );
});