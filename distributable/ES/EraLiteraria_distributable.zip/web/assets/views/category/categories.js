$(document).ready(function(){

$('#categories').dataTable({ 
    	"iDisplayLength" : 50,
    	"sDom": '<"top"pfl>rt<"bottom"ip><"clear">',
    	"bStateSave": true,
        "oLanguage": {
            "sUrl": "../assets/languajes/Spanish.json"
        },
    	"fnCookieCallback": function (sName, oData, sExpires, sPath) {
			delete oData["oSearch"];
		    return sName + "="+JSON.stringify(oData)+"; expires=" + sExpires +"; path=" + sPath;
		},
        "sServerMethod": "POST",
        "aoColumns": [
                { "sClass": "center"}, 
                { "sClass": "center"}, 
                { "sClass": "center"}, 
                { "sClass": "center"}, 
        ]

	}).columnFilter(
        {
            bUseColVis: true,
            sPlaceHolder: "head:after" ,
            aoColumns: [
                { type: "number-range-symbols"}, 
                { type: "text" },
                { type: "text" },
                null,
            ]
        }
    );
});