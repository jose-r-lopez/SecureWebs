<?php
/**
* Este código sólo debe ejecutarse una vez en toda la vida de la aplicación. Por ello se crea un comando de consola.
*
* Para usar este comando hay que:
*  - Movernos hasta la carpeta protected
*  - Una vez alli entramos en el shell de yii. Para ello tecleamos en cmd: ./yiic 
*  - Dentro del shell, tecleamos createadminrol (usando help aparecen todos los comandos).
*/

class CreateAdminRolCommand extends CConsoleCommand{

	public function getHelp() {}

	public function run($args) {
        
		if(Yii::app()->authManager == null) {
			echo "Error al crear el rol";
            return;
		}

		echo "Este comando creará el rol de admin\n";

		$auth = Yii::app()->authManager;
		$auth->createRole('admin');

		$auth->save();
        
	}

}
