<?php

/**
 * Clase de persistencia PersistenceFactory
 * Factoría que crea los objetos que permiten la persistencia de información.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class PersistenceFactory {
    
    /**
     * Crea un objeto BookPersistence
     * 
     * @return BookPersistence
     */
    public static function createBookPersistence()
    {
        return new BookPersistence();
    }
    
     /**
     * Crea un objeto CategoryPersistence
     * 
     * @return CategoryPersistence
     */
    public static function createCategoryPersistence()
    {
        return new CategoryPersistence();
    }
    
     /**
     * Crea un objeto OrderPersistence
     * 
     * @return OrderPersistence
     */
    public static function createOrderPersistence()
    {
        return new OrderPersistence();
    }
    
     /**
     * Crea un objeto ReviewPersistence
     * 
     * @return ReviewPersistence
     */
    public static function createReviewPersistence()
    {
        return new ReviewPersistence();
    }
    
     /**
     * Crea un objeto UserPersistence
     * 
     * @return UserPersistence
     */
    public static function createUserPersistence()
    {
        return new UserPersistence();
    }
    
}

?>