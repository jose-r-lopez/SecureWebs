<?php

/**
 * Clase de persistencia OrderPersistence
 * Encargado de la persistencia de los pedidos.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class OrderPersistence {

    /**
     * Permite obtener el id del siguiente pedido a añadir.
     * 
     * @return Id de un pedido.
     */
    public function getNextOrderId(){
    
        $consulta = "SELECT AUTO_INCREMENT
                     FROM information_schema.tables
                     WHERE table_name = 'orders'";
        
        $command = Yii::app()->db->createCommand($consulta); 
        return  $command->queryScalar();
    
    }
    
     /**
     * Obtiene la lista de pedidos de un usuario
     * @param string $userID Correo del usuario
     * @return List<Order> Lista de pedidos de un usuario.
     */
    public function getOrdersByUser($userID){
        $criteria = new CDbCriteria;
        $criteria->condition = 't.email = "' . $userID . '"';
        $criteria->with = array('items');
        $criteria->together = true;
		return Order::model()->findAll($criteria);
    }
    
     /**
     * Obtiene la lista de pedidos que tienen un producto en común.
     * @param string $productID Identificador de un producto.
     * @return List<Order> lista de pedidos.
     */
     public function getOrdersByProduct($productID){
        $criteria = new CDbCriteria;
        $criteria->condition = 'items.isbn = "' . $productID . '"';
		return Order::model()->with('items')->findAll($criteria);
    }
    
     /**
     * Inserta un pedido en la base de datos.
     * @param string $model Modelo que se debe guardar.
     */
    public function saveOrder($model){
        $model->save();
    }
    
    /**
     * Guarda una dirección de envío en la base de datos.
     * @param string $email Correo del usuario
     * @param string $address Dirección
     * @param string $postCode Código postal
     * @param string $city Ciudad
     * @param string $province Provincia
     */
    public function insertAddress($email,$address,$postCode,$city,$province){
        $consulta="INSERT INTO addresses (email, address, postCode, city, province) 
                    VALUES (:email, :address, :postCode, :city,:province)";

        $command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":email", $email, PDO::PARAM_STR); 
        $command->bindParam(":address", $address, PDO::PARAM_STR);
        $command->bindParam(":postCode", $postCode, PDO::PARAM_STR);
        $command->bindParam(":city", $city, PDO::PARAM_STR);
        $command->bindParam(":province", $province, PDO::PARAM_STR);

        $command->execute();
    }
    
    /**
     * Actualiza una dirección de envío.
     * @param string $email Correo del usuario
     * @param string $address Dirección
     * @param string $postCode Código postal
     * @param string $city Ciudad
     * @param string $province Provincia
     */
     public function updateAddress($email,$address,$postCode,$city,$province){
         
        $consulta="UPDATE addresses 
                   SET address=:address, postCode=:postCode ,city=:city,province=:province 
                   WHERE email=:email";
		
		$command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":email", $email, PDO::PARAM_STR); 
        $command->bindParam(":address", $address, PDO::PARAM_STR);
        $command->bindParam(":postCode", $postCode, PDO::PARAM_STR);
        $command->bindParam(":city", $city, PDO::PARAM_STR);
        $command->bindParam(":province", $province, PDO::PARAM_STR);

        $command->execute();
    }

    /**
     * Obtiene la dirección de un usuario
     * @param string $email Correo de un usuario
     * @return Array con los datos de la dirección de envío.
     */
    public function getAddress($email){
        $consulta = "SELECT * 
                     FROM addresses
                     WHERE email = :email";
        
        $command = Yii::app()->db->createCommand($consulta); 
        $command->bindParam(":email", $email, PDO::PARAM_STR); 
        return  $command->queryRow();
    }
    
    /**
     * Obtiene todos los pedidos
     * @return List<Order> lista de pedidos
     */
    public function getOrders(){
        return Order::model()->findAll();
    }

    /**
     * Obtiene un pedido.
     * @param string $id Identificador del pedido
     * @return Order 
     */
    public function getOrder($id){
        return Order::model()->findByPK($id);
    }
    
    /**
     * Borra un pedido
     * @param string $id Identificador del pedido
     */
    public function deleteOrder($id){
        $model = Order::model()->with('items')->findByPk($id);
        foreach( $model->items as $item ) {
                $item->delete();
        }
        $model->delete();
    }
    
    /**
     * Actualiza el estado del pedido a pagado
     * @param string $id Identificador del pedido
     */
    public function updateToPaid($orderID){
        $this->updateOrder($orderID,"PAID");
    }
    
    /**
     * Actualiza el estado del pedido a error
     * @param string $id Identificador del pedido
     */
    public function updateToError($orderID){
        $this->updateOrder($orderID,"ERROR");
    }
    
    /**
     * Actualiza el estado del pedido a creado
     * @param string $id Identificador del pedido
     */
    public function updateToCreated($orderID){
        $this->updateOrder($orderID,"CREATED");
    }
    
    /**
     * Actualiza el estado del pedido a enviado
     * @param string $id Identificador del pedido
     */
    public function updateToSent($orderID){
        $this->updateOrder($orderID,"SENT");
    }
    
    /**
     * Actualiza el estado de un pedido
     * @param string $orderID Identificador del pedido
     * @param string $status Estado
     */
    public function updateOrder($orderID,$status){
        $consulta="UPDATE orders 
                   SET status= :status
                   WHERE order_id=:order_id";
		
		$command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":order_id", $orderID, PDO::PARAM_STR); 
        $command->bindParam(":status", $status, PDO::PARAM_STR); 

        $command->execute();
    }
    
}

?>