<?php

/**
 * Clase de persistencia PersistenceFacade
 * Fachada que permite el acceso a la capa de persistencia.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class PersistenceFacade {
    
    /**
     * @var UserPersistence $userPersistence Clase encargada de la persistencia de usuarios
     */
    private $userPersistence;
    
    /**
     * @var BookPersistence $bookPersistence Clase encargada de la persistencia de libros
     */
    private $bookPersistence;
    
    /**
     * @var CategoryPersistence $categoryPersistence Clase encargada de la persistencia de categorías
     */
    private $categoryPersistence;
    
    /**
     * @var OrderPersistence $orderPersistence Clase encargada de la persistencia de pedidos
     */
    private $orderPersistence;
    
    /**
     * @var ReviewsPersistence $reviewsPersistence Clase encargada de la persistencia de críticas
     */
    private $reviewsPersistence;
    
    function __construct() {
        $this->userPersistence = PersistenceFactory::createUserPersistence();
        $this->bookPersistence = PersistenceFactory::createBookPersistence();
        $this->categoryPersistence = PersistenceFactory::createCategoryPersistence();
        $this->orderPersistence = PersistenceFactory::createOrderPersistence();
        $this->reviewsPersistence = PersistenceFactory::createReviewPersistence(); 
   }
 
    /* Users */    
    
    /**
     * Obtiene el nombre de un usuario.
     * 
     * @return string Nombre de un usuario.
     */
    public function getUserName(){
        return $this->userPersistence->getName(Yii::app()->user->id);
    }
    
    /**
     * Actualiza el nombre de un usuario
     * @param string $id Correo del usuario
     * @param string $name Nombre del usuario
     */
    public function updateUserName($id,$name){
        $this->userPersistence->updateName($id,$name);
    }
    
    /**
     * Obtiene todos los usuarios.
     * 
     * @return List<User> Lista de usuarios.
     */
    public function getUsers(){
        return $this->userPersistence->getUsers();
    }
    
    /**
     * Obtiene un usuario
     * @param string $id Correo del usuario
     * @return User usuario
     */
    public function getUser($id){
        return $this->userPersistence->getUser($id);
    }
    
     /**
     * Añade un usuario normal
     * @param string $name Nombre del usuario
     * @param string $email Correo del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function insertUser($name,$email,$hashedPW,$salt){
        $this->userPersistence->insertUser($name,$email,$hashedPW,$salt);
    }
    
     /**
     * Añade un usuario administrador
     * @param string $name Nombre del usuario
     * @param string $email Correo del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function insertAdmin($name,$email,$hashedPW,$salt){
        $this->userPersistence->insertAdmin($name,$email,$hashedPW,$salt);
    }
    
     /**
     * Borra un usuario
     * @param string $id Correo del usuario
     */
    public function deleteUser($id){
        $this->userPersistence->deleteUser($id);
    }
    
     /**
     * Actualiza un usuario
     * @param string $name Nombre del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function updateUser($name,$hashedPW,$salt){
        $this->userPersistence->updateUser($name,$hashedPW,$salt);
    }
    
     /* Books */ 
    
    /**
     * Obtiene todos los libros.
     * 
     * @return List<Book> Lista de libros.
     */
    public function getBooks(){
        return $this->bookPersistence->getBooks();
    }
    
     /**
     * Obtiene todos los libros pertenecientes a una categoría.
     * @param string $id Identificador de la categoría
     * @return List<Book> Lista de libros.
     */
    public function getBooksByCategory($id){
        return $this->bookPersistence->getBooksByCategory($id);
    }
    
     /**
     * Obtiene un libro
     * @param string $id Identificador del libro
     * @return Book libro
     */
    public function getBook($id){
        return $this->bookPersistence->getBook($id);
    }
    
     /**
     * Borra un libro
     * @param string $id Identificador del libro
     */
    public function deleteBook($id){
        $this->bookPersistence->deleteBook($id);
    }
    
    /**
     * Actualiza un libro
     * @param string $isbn Identificador del libro
     * @param string $name Nombre
     * @param string $author Autor
     * @param string $publisher Editorial
     * @param double $price Precio
     * @param string $cover Url de la portada
     * @param int $stock Stock
     * @param int $pages Páginas
     * @param int $year Año de publicación
     * @param string $description Descripción
     * @param string $format Formato
     * @param string $language Lenguaje
     * @param string $category_id Identificador de la categoría
     */
    public function updateBook($isbn,$name,$author,$publisher,$price, $cover, $stock, $pages, $year, $description, $format, $language, $category_id){
        $this->bookPersistence->updateBook($isbn,$name,$author,$publisher,$price, $cover, $stock, $pages, $year, $description, $format, $language, $category_id);
    }
    
    /**
     * Obtiene todas las novedades
     * @return List<Book> Lista de libros.
     */
    public function getNewBooks(){
        return  $this->bookPersistence->getNewBooks();
    }
    
    /**
     * Obtiene los próximos lanzamientos.
     * @return List<Book> Lista de libros.
     */
    public function getComingSoon(){
        return  $this->bookPersistence->getComingSoon();
    }
    
    /**
     * Obtiene todas las editoriales
     * @return List<string> Lista de editoriales
     */
    public function getPublishers(){
       return $this->bookPersistence->getPublishers();
    }
    
    /**
     * Busca un libro
     * @param string $param Texto a buscar
     * @return List<Book> Lista de libros.
     */
    public function searchBook($param){
        return $this->bookPersistence->searchBook($param);
    }
    
     /**
     * Busca un libro
     * @param string $isbn Identificador del libro
     * @param string $title Nombre
     * @param string $author Autor
     * @param string $publisher Editorial
     * @param string $format Formato
     * @param string $language Lenguaje
     * @param string $sort Ordenación de la lista
     * @return List<Book> Lista de libros.
     */
    public function advancedSearchBook($isbn, $author, $title, $publisher, $format , $languaje, $sort){
        return $this->bookPersistence->advancedSearchBook($isbn, $author, $title, $publisher, $format , $languaje, $sort);
    }
    
     /**
     * Busca los libros de una editorial por nombre
     * @param string $id Nombre de la editorial
     * @return List<Book> Lista de libros.
     */
    public function searchPublisher($id){
        return $this->bookPersistence->searchPublisher($id);
    }
    
     /**
     * Obtiene todos los formatos existentes.
     * @return List<string> Lista de formatos
     */
    public function getFormats(){
        return $this->bookPersistence->getFormats();
    }
    
     /**
     * Obtiene todos los lenguajes existentes.
     * @return List<string> Lista de lenguajes
     */
    public function getLanguages(){
        return $this->bookPersistence->getLanguages();
    }
    
    
     /**
     * Obtiene las 8 últimas novedades para mostrar en el carousel.
     * @return List<Book> Lista de libros
     */
    public function getNewBooksCarousel(){
         return $this->bookPersistence->getNewBooksCarousel();
    }
    
    /**
     * Obtiene los 8 últimos próximos lanzamientos para mostrar en el carousel.
     * @return List<Book> Lista de libros
     */
    public function getComingSoonCarousel(){
         return $this->bookPersistence->getComingSoonCarousel();
    }
    
    /**
     * Guarda un libro
     * @param Book $book Libro a guardar
     */
    public function saveBook($book){
        $this->bookPersistence->saveBook($book);
    }
    
     /**
     * Actualiza la valoración de un libro
     * @param string $isbn Id de un libro
     * @param double $rating Valoración de un libro
     */
    public function updateRating($isbn, $rating){
         $this->bookPersistence->updateRating($isbn, $rating);
    }
    
    /* Categories */ 
    
     /**
     * Obtiene todas las categorías.
     * @return List<Category> Lista de categorías.
     */
    public function getCategories(){
        return $this->categoryPersistence->getCategories();
    }
    
     /**
     * Obtiene todas las categorías sin padre.
     * @return List<Category> Lista de categorías.
     */
    public function getAllCategories(){
        return $this->categoryPersistence->getAllCategories();
    }
    
     /**
     * Borra una categoría
     * @param string $id Id de la categoría
     */
     public function deleteCategory($id){
        $this->categoryPersistence->deleteCategory($id);
    }
    
     /**
     * Obtiene una categoría
     * @param string $id Id de la categoría
     * @return Category Categoría
     */
    public function getCategory($id){
        return $this->categoryPersistence->getCategory($id);
    }
    
     /**
     * Obtiene categorías a través de su padre. 
     * @param string $id Id de la categoría padre
     * @return List<Category> Lista de categorías.
     */
    public function getCategoryByParent($id){
        return $this->categoryPersistence->getCategoryByParent($id);
    }
    
     /**
     * Obtiene la etiqueta de la categoría padre de la categoría introducida de parámetro.
     * @param string $id Id de la categoría padre
     * @return string Etiqueta
     */
    public function getParentLabel($id){
        return $this->categoryPersistence->getParentLabel($id);
    }
    
     /**
     * Guarda una categoría
     * @param Category $category Categoría
     */
    public function saveCategory($category){
         $this->categoryPersistence->saveCategory($category);
    }
    
     /**
     * Actualiza una categoría
     * @param string $label Etiqueta
     * @param string $parentCategory Identificador del padre
     * @param string $categoryID Identificador de la categoría
     */
     public function updateCategory($label, $parentCategory, $categoryID){
        $this->categoryPersistence->updateCategory($label, $parentCategory, $categoryID);
     }
    
    /* Orders */ 
    
     /**
     * Obtiene todos los pedidos
     * @return List<Order> Lista de pedidos.
     */
    public function getOrders(){
        return $this->orderPersistence->getOrders();
    }
    
     /**
     * Obtiene un pedido
     * @param string $id Identificador del pedido
     * @return Order Pedido
     */
    public function getOrder($id){
       return$this->orderPersistence->getOrder($id);
    }
    
     /**
     * Obtiene una dirección de envío
     * @param string $id Correo del usuario
     * @return Array Datos de la dirección
     */
    public function getAddress($id){
        return $this->orderPersistence->getAddress($id);
    }
    
      /**
     * Obtiene todos los pedidos que tengan el producto especificado en común
     * @param string $id Identificador de un libro
     * @return List<Order> Lista de pedidos.
     */
    public function getOrdersByProduct($id){
        return $this->orderPersistence->getOrdersByProduct($id);
    }
    
      /**
     * Obtiene todos los pedidos que pertenezcan a un mismo usuario.
     * @param string $id Correo del usuario
     * @return List<Order> Lista de pedidos.
     */
    public function getOrdersByUser($id){
         return $this->orderPersistence->getOrdersByUser($id);
    }
    
    /**
     * Borra un pedido
     * @param string $id IDentificador del pedido
     */
    public function deleteOrder($id){
        $this->orderPersistence->deleteOrder($id);
    }
    
     /**
     * Actualiza el pedido a creado
     * @param string $id IDentificador del pedido
     */
    public function updateToCreated($id){
        $this->orderPersistence->updateToCreated($id);
    }
    
     /**
     * Actualiza el pedido a pagado
     * @param string $id IDentificador del pedido
     */
    public function updateToPaid($id){
        $this->orderPersistence->updateToPaid($id);
    }
    
     /**
     * Actualiza el pedido a error
     * @param string $id IDentificador del pedido
     */
    public function updateToError($id){
        $this->orderPersistence->updateToError($id);
    }
    
     /**
     * Actualiza el pedido a enviado
     * @param string $id IDentificador del pedido
     */
    public function updateToSent($id){
        $this->orderPersistence->updateToSent($id);
    }
    
    /**
     * Obtiene el id del siguiente pedido a introducir
     * @return string Siguiente ids
     */
    public function getNextOrderId(){
        return $this->orderPersistence->getNextOrderId();
    }
    
    /**
     * Guarda un pedido
     * @param Order $order Pedido
     */
    public function saveOrder($order){
        $this->orderPersistence->saveOrder($order);
    }
    
    /**
     * Añade una dirección de envío
     * @param string $id Correo del usuario
     * @param string $address Dirección
     * @param string $postCode Código postal
     * @param string $city Ciudad
     * @param string $province Provincia
     */
    public function insertAddress($d,$address,$postCode,$city,$province){
         $this->orderPersistence->insertAddress($d,$address,$postCode,$city,$province);
    }
    
     /**
     * Actualiza la dirección de envío
     * @param string $id Correo del usuario
     * @param string $address Dirección
     * @param string $postCode Código postal
     * @param string $city Ciudad
     * @param string $province Provincia
     */
    public function updateAddress($id,$address,$postCode,$city,$province){
         $this->orderPersistence->updateAddress($id,$address,$postCode,$city,$province);
    }
    
    /*Reviews */
    
     /**
     * Obtiene las críticas de un producto
     * @param string $id Id del libro
     * @return List<Review> Lista de críticas
     */
    public function getReviewsByIsbn($id){
        return $this->reviewsPersistence->getReviewsByIsbn($id);
    }
    
    
     /**
     * Obtiene las críticas de un usuario
     * @param string $id Correo del usuario
     * @return List<Review> Lista de críticas
     */
    public function getReviewByEmail($id){
        return $this->reviewsPersistence->getReviewByEmail($id);
    }
    
     /**
     * Obtiene una crítica por producto y usuario.
     * @param string $id Correo del usuario
     * @param string $isbn Isbn del libro
     * @return Review crítica
     */
    public function getReviewByParams($id, $isbn){
         return $this->reviewsPersistence->getReviewByParams($id, $isbn);
    }
    
    /**
     * Añade una crítica
     * @param string $text Texto
     * @param double $rating Valoración
     * @param string $id Correo del usuario
     * @param string $title Título de la crítica
     * @param string $isbn Isbn del libro
     */
    public function insertReview($text,$rating,$id, $title ,$isbn){
        $this->reviewsPersistence->insertReview($text,$rating,$id, $title ,$isbn);
    }

}

?>