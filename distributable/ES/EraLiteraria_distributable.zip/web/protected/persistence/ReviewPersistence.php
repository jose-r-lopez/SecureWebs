<?php

/**
 * Clase de persistencia ReviewPersistence
 * Encargado de la persistencia de las críticas
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class ReviewPersistence {
    
    /**
     * Inserta una crítica
     * @param string $text Texto de la crítica
     * @param double $rating Valoración
     * @param string $email Correo del usuario
     * @param string $title Título de la crítica
     * @param string $isbn Identificador del libro
     */
    public function insertReview($text,$rating,$email, $title ,$isbn){
        $consulta="INSERT INTO reviews (text, rating, email, title,isbn) 
                    VALUES (:text, :rating, :email, :title, :isbn)";

        $command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":text", $text, PDO::PARAM_STR); 
        $command->bindParam(":rating", $rating, PDO::PARAM_STR);
        $command->bindParam(":email", $email, PDO::PARAM_STR);
        $command->bindParam(":title", $title, PDO::PARAM_STR);
        $command->bindParam(":isbn", $isbn, PDO::PARAM_STR);

        $command->execute();
    }

    /**
     * Obtiene todas las críticas
     * 
     * @return List<Reviews> lista de críticas
     */
    public function getReviews(){
        return Review::model()->with('user')->findAll();
    }

    /**
     * Obtiene una crítica por su identificador
     * @param string $id Identificador de la crítica
     * @return Review Crítica
     */
    public function getReview($id){
        return Review::model()->findByPK($id);
    }
    
     /**
     * Obtiene una crítica por usuario y producto
     * @param string $email Correo del usuario
     * @param string $isbn Identificador del libro
     * @return Review Crítica
     */
    public function getReviewByParams($email, $isbn){
        return Review::model()->findByAttributes(array("email" => $email , "isbn" => $isbn));
    }
    
     /**
     * Obtiene todas las críticas de un usuario.
     * @param string $email Correo del usuario
     * @return List<Review> Lista de críticas
     */
     public function getReviewByEmail($email){
        return Review::model()->findByAttributes(array("email" => $email));
    }
    
     /**
     * Obtiene todas las críticas de un producto.
     * @param string $isbn Identificador del libro
     * @return List<Review> Lista de críticas
     */
     public function getReviewsByIsbn($isbn){
        $criteria = new CDbCriteria;
        $criteria->condition = 't.isbn = ' . $isbn;
        return Review::model()->findAll($criteria);
    }
}

?>