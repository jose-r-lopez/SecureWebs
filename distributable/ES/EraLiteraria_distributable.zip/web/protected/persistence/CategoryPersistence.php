<?php

/**
 * Clase de persistencia CategoryPersistence
 * Encargado de la persistencia de las categorías
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class CategoryPersistence {
    
    /**
     * Obtiene todas las categorías que no tienen padre (categorías principales)
     * 
     * @return List<Categories> lista categorias
     */
    public function getAllCategories(){
        $criteria = new CDbCriteria;
        $criteria->addCondition('parent_id IS NULL');
		return Category::model()->findAll($criteria);
	}
    
    /**
     * Obtiene todas las categorías.
     * 
     * @return List<Categories> lista categorias
     */
    public function getCategories(){
        return Category::model()->findAll();
    }
    
    /**
     * Obtiene una categoria
     * @param string $id Identificador de la categoría
     * @return Category Categoría
     */
    public function getCategory($id){
        return Category::model()->findByPk($id);
    }
    
    /**
     * Obtiene una categoria por su etiqueta o nombre.
     * @param string $label Etiqueta de la categoría
     * @return Category Categoría
     */
    public function getCategoryByLabel($label){
        $criteria = new CDbCriteria;
        $criteria->addCondition('label = "' .$label .'"');
        return Category::model()->find($criteria);
    }
    
    /**
     * Obtiene todas las categorías que sean hija de la categoría especificada en el parámetro.
     * @param string $parentId Identificador de la categoría padre.
     * @return List<Category> Lista de categorías
     */
    public function getCategoryByParent($parentId){
        $criteria = new CDbCriteria;
        $criteria->addCondition('parent_id = "'. $parentId .'"');
		return Category::model()->findAll($criteria);
    }
    
    /**
     * Obtiene la etiqueta de la categoría padre de la categoría especificada en el parámetro.
     * @param string $parentId Identificador de la categoría padre.
     * @return string Etiqueta de una categoría
     */
    public function getParentLabel($id){
        $consulta = "SELECT c1.label
                    FROM categories c1, categories c2
                    WHERE c1.category_id = c2.parent_id
                    AND c2.category_id =  :category_id";
        
        $command = Yii::app()->db->createCommand($consulta); 
        $command->bindParam(":category_id", $id, PDO::PARAM_STR); 
        return  $command->queryScalar();
    }
    
    /**
     * Guarda una categoría.
     * @param Category $model Categoría a guardar
     */
    public function saveCategory($model){
        $model->save();
    }
    
    /**
     * Elimina una categoría.
     * @param string $id Identificador de una categoría
     */
    public function deleteCategory($id){
        return Category::model()->deleteByPk($id);
    }
    
    /**
     * Actualiza una categoría
     * @param string $label Etiqueta de la categoría
     * @param string $parentID Identificador de la categoría padre
     * @param string $id Identificador de la categoría
     */
    public function updateCategory($label, $parentID , $id){
         $consulta="UPDATE categories 
                   SET label = :label , parent_id = :parentID
                   WHERE category_id=:category_id";
		
		$command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":label", $label, PDO::PARAM_STR);
        $command->bindParam(":parentID", $parentID, PDO::PARAM_STR);
        $command->bindParam(":category_id", $id, PDO::PARAM_STR);
        $command->execute();
    }
}

?>