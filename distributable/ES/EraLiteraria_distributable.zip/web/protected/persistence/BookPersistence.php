<?php

/**
 * Clase de persistencia BookPersistence
 * Encargado de la persistencia de los libros.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class BookPersistence {
    
    /**
     * Obtiene todos los libros de una categoría
     * @param string $category_id Identificador de la categoría
     * @return List<Book> lista de libros
     */
    public function getBooksByCategory($category_id){
        $query = "SELECT *  FROM books WHERE category_id =" .  $category_id;
        return Yii::app()->db->createCommand($query)->queryAll();
	}
    
     /**
     * Obtiene todos los libros
     * @return List<Book> lista de libros
     */
    public function getBooks(){
        return Book::model()->findAll();
    }
    
     /**
     * Obtiene los 20 últimos libros subidos
     * @return List<Book> lista de libros
     */
    public function getNewBooks(){
        $criteria = new CDbCriteria;
        $criteria->order = 'upload_Date desc';
        $criteria->limit = 20;
        $now = new CDbExpression("NOW()");
        $criteria->condition = 't.upload_Date < ' . $now;
		return Book::model()->findAll($criteria);
    }
    
    /**
     * Obtiene los 8 últimos libros subidos
     * @return List<Book> lista de libros
     */
     public function getNewBooksCarousel(){
        $criteria = new CDbCriteria;
        $criteria->order = 'upload_Date desc';
        $criteria->limit = 8;
        $now = new CDbExpression("NOW()");
        $criteria->condition = 't.upload_Date < ' . $now;
		return Book::model()->findAll($criteria);
    }
    
    /**
     * Obtiene los libros cuya fecha de subida es posterior a la actual.
     * @return List<Book> lista de libros
     */
    public function getComingSoon(){
        $criteria = new CDbCriteria;
        $now = new CDbExpression("NOW()");
        $criteria->condition = 't.upload_Date > ' . $now;
        $criteria->order = 'upload_Date desc';
		return Book::model()->findAll($criteria);
    }
    
     /**
     * Obtiene los libros cuya fecha de subida es posterior a la actual. Sólo 8 libros.
     * @return List<Book> lista de libros
     */
    public function getComingSoonCarousel(){
        $criteria = new CDbCriteria;
        $now = new CDbExpression("NOW()");
        $criteria->condition = 't.upload_Date > ' . $now;
        $criteria->order = 'upload_Date desc';
        $criteria->limit = 8;
		return Book::model()->findAll($criteria);
    }
    
     /**
     * Obtiene una lista con todos los nombres de las editoriales.
     * @return List<string> lista de editoriales
     */
     public function getPublishers(){
         $consulta = "SELECT DISTINCT publisher FROM books order by publisher asc";
         return Yii::app()->db->createCommand($consulta)->queryAll();
    }
    
    /**
     * Obtiene todos los libros de una editorial.
     * @param string $publisher Nombre de la editorial
     * @return List<Book> lista de libros
     */
    public function getBookByPublisher($publisher){
        $criteria = new CDbCriteria;
        $criteria->addSearchCondition('publisher', $publisher, true);
        return  Book::model()->findAll($criteria);
    }
    
    /**
     * Obtiene un libro
     * @param string $id Identificador de un libro
     * @return Book libro
     */
    public function getBook($id){
        return Book::model()->findByPK($id);
    }
    
     /**
     * Busca un libro. Busca todos los libros cuyo isbn, author o name contenga el texto introducido de parámetro.
     * @param string $text Texto a buscar
     * @return List<Book> lista de libros
     */
    public function searchBook($text){
        $criteria = new CDbCriteria;
        $criteria->addSearchCondition('isbn', $text, true);
        $criteria->addSearchCondition('author', $text, true, 'OR');
        $criteria->addSearchCondition('name', $text, true, 'OR');
        return Book::model()->findAll($criteria);
    }
    
     /**
     * Busca un libro. Busca todos los libros según varios campos indicados de parámetros.
     * @param string $isbn Isbn a buscar
     * @param string $author Autor a buscar
     * @param string $name Título a buscar
     * @param string $publisher Editorial a buscar
     * @param string $format Formato a buscar
     * @param string $language Lenguaje a buscar
     * @param string $orderBy Ordenación de la lista
     * @return List<Book> lista de libros
     */
     public function advancedSearchBook($isbn, $author, $name, $publisher, $format, $language, $orderBy){
        $criteria = new CDbCriteria;
         
        if(!empty($isbn))
        $criteria->addSearchCondition('isbn', $isbn, true);
        if(!empty($author))
        $criteria->addSearchCondition('author', $author, true, 'OR');
        if(!empty($name))
        $criteria->addSearchCondition('name', $name, true, 'OR');
        if(!empty($publisher))
        $criteria->addSearchCondition('publisher', $publisher, true, 'OR');
        if(!empty($format))
        $criteria->addSearchCondition('format', $format, true, 'AND');    
        if(!empty($language))
        $criteria->addSearchCondition('language', $language, true, 'AND');    
         
        if($orderBy == 0)
            $criteria->order = 'price DESC';
        else if($orderBy == 1)
            $criteria->order = 'price ASC';
        else if($orderBy == 2)
            $criteria->order = 'year ASC';
        else
            $criteria->order = 'year DESC';
            
        return Book::model()->findAll($criteria);
    }
    
    /**
     * Busca todos los libros de una editorial por nombre
     * @param string $publisher Nombre de la editorial
     * @return List<Book> lista de libros
     */
     public function searchPublisher($publisher){
        $criteria = new CDbCriteria;
        $criteria->condition = 't.publisher = "' . $publisher . '"';
        $criteria->order = 'name DESC';
        return Book::model()->findAll($criteria);
    }
    
     /**
     * Obtiene todos los formatos disponibles.
     * @return List<string> lista de formatos
     */
    public function getFormats(){
         $data = array();
         $consulta = "SELECT DISTINCT format
                      FROM books";
         $query = Yii::app()->db->createCommand($consulta)->queryAll();
        
        $data[] = "Todos";
         foreach($query as $row) {
            $data[] = $row['format'];
        }
    
        return $data;
    }
    
     /**
     * Obtiene todos los lenguajes disponibles.
     * @return List<string> lista de lenguajes
     */
    public function getLanguages(){
         $data = array();
         $consulta = "SELECT DISTINCT language as lang
                      FROM books";
         $query = Yii::app()->db->createCommand($consulta)->queryAll();
        
        $data[] = "Todos";
         foreach($query as $row) {
            $data[] = $row['lang'];
        }
    
        return $data;
    }
    
    /**
     * Guarda un libro
     * @param Book $model Libro a guardar
     */
    public function saveBook($model){
        $model->save();
    }
    
     /**
     * Borra un libro
     * @param string $id Identificador de un libro
     */
    public function deleteBook($id){
        return Book::model()->deleteByPk($id);
    }
    
     /**
     * Actualiza la valoración de un libro
     * @param string $isbn Identificador de un libro
     * @param double $rating Nueva valoración
     */
    public function updateRating($isbn,$rating){
         $consulta="UPDATE books 
                    SET  rating = :rating
                    WHERE isbn = :isbn";
         
		$command=Yii::app()->db->createCommand($consulta);
         
        $command->bindParam(":isbn", $isbn, PDO::PARAM_STR);
        $command->bindParam(":rating", $rating, PDO::PARAM_STR);
        $command->execute();
    }
    
    
     /**
     * Actualiza un libro
     * @param string $isbn Identificador de un libro
     * @param string $name Título del libro
     * @param string $author Autor del libro
     * @param string $publisher Editorial
     * @param double $price Precio
     * @param string $cover URL a la portada
     * @param int $stock Stock
     * @param int $pages Número de páginas
     * @param int $year Año de publicación
     * @param string $description Descripción
     * @param string $format Formato
     * @param string $language Lenguaje
     * @param string $category_id Identificador de la categoría a la que pertenece
     */
     public function updateBook($isbn,$name,$author,$publisher,$price, $cover, $stock, $pages, $year, $description, $format, $language, $category_id){
         $consulta="UPDATE books 
                    SET  name = :name, author = :author,publisher = :publisher,price = :price,stock = :stock,
                    cover = :cover,pages = :pages, year = :year, description = :description, format = :format, language = :language, category_id = :category_id
                    WHERE isbn = :isbn";
         
		
		$command=Yii::app()->db->createCommand($consulta);
         
        $command->bindParam(":name", $name, PDO::PARAM_STR);
        $command->bindParam(":author", $author, PDO::PARAM_STR);
        $command->bindParam(":publisher", $publisher, PDO::PARAM_STR);
        $command->bindParam(":price", $price, PDO::PARAM_STR);
        $command->bindParam(":cover", $cover, PDO::PARAM_STR);
        $command->bindParam(":stock", $stock, PDO::PARAM_STR);
        $command->bindParam(":pages", $pages, PDO::PARAM_STR);
        $command->bindParam(":year", $year, PDO::PARAM_STR);
        $command->bindParam(":description", $description, PDO::PARAM_STR);
        $command->bindParam(":format", $format, PDO::PARAM_STR);
        $command->bindParam(":language", $language, PDO::PARAM_STR);
        $command->bindParam(":category_id", $category_id, PDO::PARAM_STR);
        $command->bindParam(":isbn", $isbn, PDO::PARAM_STR);
        $command->execute();
    }
}

?>