<?php

/**
 * Clase de persistencia UserPersistence
 * Encargado de la persistencia de los usuarios.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.persistence
 */
class UserPersistence {
    
    /**
     * Inserta un usuario normal
     * @param string $name Nombre del usuario
     * @param string $email Correo del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function insertUser($name,$email,$hashedPW,$salt){
        $consulta="INSERT INTO users (name, email, pass, salt) 
                    VALUES (:name, :email, :pass, :salt)";

        $command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":name", $name, PDO::PARAM_STR); 
        $command->bindParam(":email", $email, PDO::PARAM_STR);
        $command->bindParam(":pass", $hashedPW, PDO::PARAM_STR);
        $command->bindParam(":salt", $salt, PDO::PARAM_STR);

        $command->execute();
    }
    
     /**
     * Inserta un usuario administrador
     * @param string $name Nombre del usuario
     * @param string $email Correo del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function insertAdmin($name,$email,$hashedPW,$salt){
        $consulta="INSERT INTO users (name, email, pass, salt, role) 
                    VALUES (:name, :email, :pass, :salt, :role)";

        $command=Yii::app()->db->createCommand($consulta);

        $role = "admin";
        $command->bindParam(":name", $name, PDO::PARAM_STR); 
        $command->bindParam(":email", $email, PDO::PARAM_STR);
        $command->bindParam(":pass", $hashedPW, PDO::PARAM_STR);
        $command->bindParam(":salt", $salt, PDO::PARAM_STR);
        $command->bindParam(":role", $role, PDO::PARAM_STR);

        $command->execute();
    }

    /**
     * Obtiene todos los usuarios
     * 
     * @return List<User> lista de usuarios
     */
    public function getUsers(){
        return User::model()->findAll();
    }

     /**
     * Obtiene los datos de un usuario
     * @param string $id Correo del usuario
     * @return User usuario
     */
    public function getUser($id){
        return User::model()->findByPK($id);
    }
    
     /**
     * Obtiene el nombre de un usuario
     * @param string $email Correo del usuario
     * @return string Nombre de un usuario
     */
    public function getName($email){        
        $consulta = "SELECT name
                     FROM users
                     WHERE email = :email";
        $command = Yii::app()->db->createCommand($consulta);
        $command->bindParam(":email", $email, PDO::PARAM_STR);
        return $command->queryScalar();
    }
    
    /**
     * Actualiza el nombre de un usuario
     * @param string $email Correo del usuario
     * @param string $name Nombre del usuario
     */
    public function updateName($email, $name){
        $consulta="UPDATE users 
                   SET name=:name
                   WHERE email=:email";
		
		$command=Yii::app()->db->createCommand($consulta);
        $command->bindParam(":email", $email, PDO::PARAM_STR); 
        $command->bindParam(":name", $name, PDO::PARAM_STR);
        $command->execute();
        
    }
    
     /**
     * Actualiza un usuario
     * @param string $email Correo del usuario
     * @param string $hashedPW Contraseña encriptada
     * @param string $salt Hash usado para encriptar la contraseña
     */
    public function updateUser($email,$hashedPW,$salt){
        $consulta="UPDATE users 
                   SET pass=:pass, salt=:salt
                   WHERE email=:email";
		
		$command=Yii::app()->db->createCommand($consulta);

        $command->bindParam(":email", $email, PDO::PARAM_STR); 
        $command->bindParam(":pass", $hashedPW, PDO::PARAM_STR);
        $command->bindParam(":salt", $salt, PDO::PARAM_STR);
        $command->execute();
        
    }
    
    /**
     * Borra un usuario
     * @param string $id Correo del usuario
     */
    public function deleteUser($id){
        User::model()->deleteByPk($id);
    }
}

?>