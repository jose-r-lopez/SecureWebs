<?php

$this->pageTitle=Yii::app()->name . ' - Opinar';
$this->breadcrumbs=array(
    $categorylabel =>   Yii::app()->createUrl('book/categories',array('id'=>$book->category_id, 'name'=>$categorylabel)),
    $book->name => Yii::app()->createUrl('book/view',array('id'=>$book->isbn)),
    'Opinar'
);

?>

<h2 class="fill">Opina sobre el producto</h2>

<section id="review">
    
    <div>
    <div id="reviewItem">
        <div id="imgitem">
                <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                 echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>
        </div>
        <div id="item">
            <p><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p>
            <p><?php echo $book->author ?></p>
            <p><?php echo $book->publisher ?></p>
        </div>
    </div>

    <?php if($error != null){ ?>
                <div class="formerror"><p><?php echo $error ?></p></div>
    <?php } ?>
    
    
    <section class="form">
        <h3  class="underline">Añade tu opinión</h3>
    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'create-review-form',
        'enableClientValidation'=>true,
        'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
    )); ?>

        <div id="rating">
            <label for="ReviewForm_rating-raty">Valoración:</label>
            <?php  $this->widget('ext.dzRaty.DzRaty', array(
                'model' => $model,
                'attribute' => 'rating',
                'options' => array(
                  'half' => TRUE),
            ));   ?>
            <?php echo $form->error($model,'rating',array('class'=>'formerror')); ?>
        </div>

        <div>
            <?php echo $form->labelEx($model,'title'); ?>
            <?php echo $form->textField($model,'title'); ?>
            <?php echo $form->error($model,'title',array('class'=>'formerror')); ?>
        </div>

        <div>
            <?php echo $form->labelEx($model,'text'); ?>
            <?php echo $form->textArea($model,'text'); ?>
            <?php echo $form->error($model,'text',array('class'=>'formerror')); ?>
        </div>


        <div>
            <?php echo CHtml::submitButton('Crear crítica'); ?>
        </div>
        </section>
    <?php $this->endWidget(); ?>
    </div>    
</section>