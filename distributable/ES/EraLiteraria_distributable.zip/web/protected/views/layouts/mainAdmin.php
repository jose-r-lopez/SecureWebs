<?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/era/siteAdmin.css" >
    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
    
<?php
    Yii::app()->clientScript->registerCoreScript('jquery'); 
    $esAdmin = Yii::app()->user->checkAccess('admin')? true : false;
?>
    
</head>

<body>

    <header>
        <div id="accountMenu">
            <?php if(Yii::app()->user->isGuest) {?>
            <ul>
                <li><?php echo CHtml::link('Iniciar Sesión', Yii::app()->createUrl("/account/login")); ?> </li>
                <li><?php echo CHtml::link('Registrarte',Yii::app()->createUrl("/account/register")); ?></li>
            </ul>
            <?php }else{ ?>
             Hola, <?php echo Yii::app()->user->name ?>
             <ul>
                <li><?php echo CHtml::link('Cerrar sesión',Yii::app()->createUrl("/account/logout")); ?></li>
            <?php if($esAdmin) {?>
                    <li><?php echo CHtml::link('Volver a a tienda', Yii::app()->createUrl("/")); ?> </li>
            <?php } ?>
                 
              </ul>
            <?php } ?>
        </div>
         
        <h1>Era literaria - Panel de Administración</h1>
    </header>

    <nav>
        <?php 
        $this->widget('zii.widgets.CMenu',array(
                        'items'=>array(
                                    array('label'=>'Productos', 'url'=> array('admin/products')),
                                    array('label'=>'Categorías', 'url'=> array('admin/categories')),
                                    array('label'=>'Usuarios', 'url'=> array('admin/users')),
                                    array('label'=>'Pedidos', 'url'=> array('admin/orders'))
                                ))); 

    ?>
    </nav>
    <?php echo $content; ?>
    
    <footer>
        <p>Copyright &copy; Leticia del Valle Varela </p>
    </footer>
    
</body>
</html>
