<?php /* @var $this Controller */ ?>

<?php $this->beginContent('//layouts/main'); ?>

<section id="content">
    <?php if(isset($this->breadcrumbs)):
    	$this->widget('zii.widgets.CBreadcrumbs', array(
			'homeLink' => CHtml::link('Inicio', Yii::app()->homeUrl),
            'links'=>$this->breadcrumbs,
        )); ?><!-- breadcrumbs -->
    <?php endif ?>
    
	<?php echo $content; ?>
</section><!-- content -->

<?php $this->endContent(); ?>