<?php /* @var $this Controller */ ?>

<?php $this->beginContent('//layouts/mainAdmin'); ?>

<section id="content">
    <?php if(isset($this->breadcrumbs)):
    	$this->widget('zii.widgets.CBreadcrumbs', array(
			'homeLink' => CHtml::link('Inicio', array("/admin")),
            'links'=>$this->breadcrumbs,
        )); ?><!-- breadcrumbs -->
    <?php endif ?>
    
	<?php echo $content; ?>
</section><!-- content -->

<?php $this->endContent(); ?>