<?php /* @var $this Controller */ ?>

<?php $this->beginContent('//layouts/main'); ?>

<section id="content">
    <section id="categoryMenu">
        <h2 class="categories">Categorías</h2>
        <nav>
            <?php  
                if(!isset($this->categoryMenu)){
                    $menu = $this->widget('zii.widgets.CMenu',array(
                    'items'=>Yii::app()->getMenu())); 
                }else{
                    $menu = $this->widget('zii.widgets.CMenu',array(
                    'items'=>$this->categoryMenu)); 
                }    
            ?>
        </nav>
     </section>

    <section id="contentCol">
        <?php if(isset($this->breadcrumbs)):
            $this->widget('zii.widgets.CBreadcrumbs', array(
                'homeLink' => CHtml::link('Inicio', Yii::app()->homeUrl),
                'links'=>$this->breadcrumbs,
            )); ?><!-- breadcrumbs -->
        <?php endif ?>
        <?php echo $content; ?><!-- content -->
    </section>
</section>

<?php $this->endContent(); ?>