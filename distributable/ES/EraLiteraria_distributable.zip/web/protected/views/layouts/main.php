<?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/era/site.css" >
    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
    
    
    <?php
    Yii::app()->clientScript->registerScript('main', 
	'$(document).ready(function(){
        $("#search-form").submit(function(event) {
            var searchText = $("#textSearch").val();
            var action = $("#search-form").attr("action");
            $("#search-form").attr("action", action + "/normal/" + searchText);
        });
        
	});');

    $esAdmin = Yii::app()->user->checkAccess('admin')? true : false;
    
?>
    
</head>

<body>

    <header>
        <div id="accountMenu">
            <?php if(Yii::app()->user->isGuest) {?>
            <ul>
                <li><?php echo CHtml::link('Iniciar Sesión', Yii::app()->createUrl("/account/login")); ?> </li>
                <li><?php echo CHtml::link('Registrarte',Yii::app()->createUrl("/account/register")); ?></li>
            </ul>
            <?php }else{ ?>
             Hola, <?php echo Yii::app()->user->name ?>
             <ul>
                <li><?php echo CHtml::link('Mi cuenta', Yii::app()->createUrl("/account/")); ?> </li>
                <li><?php echo CHtml::link('Cerrar sesión',Yii::app()->createUrl("/account/logout")); ?></li>
            <?php if($esAdmin) {?>
                    <li><?php echo CHtml::link('Administración', Yii::app()->createUrl("/admin/")); ?> </li>
            <?php } ?>
                 
              </ul>
            <?php } ?>
        </div>
        
        <div id="titleAndSearch">
            
            <?php $img = CHtml::image( Yii::app()->request->baseUrl . "/images/icon.png", Yii::app()->name );  ?>
                 <h1> <?php echo CHtml::link($img,Yii::app()->createUrl("/site/")) ?></h1>
         <section>
        <?php 
            echo CHtml::beginForm(Yii::app()->createUrl("/search"), "post", array("id"=>"search-form")); ?>

            <?php echo CHtml::textField("textSearch", "", array("id" => "textSearch", "placeholder" => "Busca libros por título, autor o ISBN")) ?>
            <?php echo CHtml::submitButton('Buscar', array("id" => "buscar")); ?>
            <p><?php echo CHtml::link("Búsqueda avanzada", Yii::app()->createUrl("/search/advanced")) ?></p> 
        <?php echo CHtml::endForm(); ?>
        
        </section>
 
        </div>
        
        <div id="cartAndMenu">
            <div>
                <div id="cartInfo">
                    <p><?php echo CHtml::link("Tu cesta", Yii::app()->createUrl("/shoppingCart")) ?></p> 

                    <?php if(isset(Yii::app()->session["cart"])){
                        $cart = Yii::app()->session["cart"]; ?>
                    <p><span class="totalunits"><?php echo $cart->getNumberOfItems() ?></span> libros por <span class="total"><?php echo $cart->getTotalPrice() ?></span></n> €</p>
                    <?php }else{ ?>
                        <p> 0 libros por 0 €</p>
                    <?php } ?>
                </div>
                <div id="cartImage">
                    <img alt="cesta de la compra" src="<?php echo Yii::app()->request->baseUrl; ?>/images/cesta.png">
                </div>
            </div>
            <nav>
                <?php $this->widget('zii.widgets.CMenu',array(
                        'items'=>array(
                                    array('label'=>'Novedades', 'url'=> array('book/news'),'itemOptions'=>array('class' => 'itemNov')),
                                    array('label'=>'Próximamente', 'url'=> array('/book/comingsoon'),'itemOptions'=>array('class' => 'itemPro')),
                                    array('label'=>'Editoriales', 'url'=> array('/book/publishers'),'itemOptions'=>array('class' => 'itemEdi')),
                                    array('label'=>'Sobre nosotros', 'url'=> array('/site/page/', 'view'=>'about'),'itemOptions'=>array('class' => 'itemSN')),
                                ))); ?>
            </nav>
    
        </div>
     </header>

    <?php echo $content; ?>
    
    <footer>
        
        <section id="links">
            <ul>
                <li>Atención al cliente:
                     <ul>
                        <?php echo CHtml::link('Gastos de envío', Yii::app()->createUrl('/site/page', array('view'=>'shipping'))); ?>
                        <?php echo CHtml::link('Contacta con nosotros', Yii::app()->createUrl("/site/contact")); ?>
                     </ul>
                </li>
                <li>Más información: <?php echo CHtml::link('Mapa del sitio', Yii::app()->createUrl("/site/sitemap")); ?>
                </li>
                <li class="last">Información legal:
                     <ul>
                        <?php echo CHtml::link('Condiciones de uso', Yii::app()->createUrl('/site/page', array('view'=>'termsconditions'))); ?>
                        <?php echo CHtml::link('Política de protección de datos', Yii::app()->createUrl('/site/page', array('view'=>'privacy'))); ?>
                     </ul>
                </li>
            </ul>
        </section>
        
        <section id="copy">
            <p>Copyright &copy; Leticia del Valle Varela -  El icono de la cesta está hecho por <a title="Freepik" href="http://www.freepik.com">Freepik</a> sacado de <a title="Flaticon"  href="http://www.flaticon.com">www.flaticon.com</a> licencia  <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0">CC BY 3.0</a>.</p>
            <p>El icono de la lupa está hecho por <a href="http://www.antonps.com" title="Anton Saputro">Anton Saputro</a> sacado de <a title="Flaticon"  href="http://www.flaticon.com">www.flaticon.com</a> licencia  <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0">CC BY 3.0</a></p>
            
            <div>
                <img alt="MasterCard" src="<?php echo Yii::app()->request->baseUrl; ?>/images/ico-mastercard.gif" title="Paga con Mastercard">
                <img alt="Visa" src="<?php echo Yii::app()->request->baseUrl; ?>/images/ico-visa.gif" title="Paga con VISA">
            </div>
        </section>
    </footer>
    
</body>
</html>
