<?php
$this->pageTitle=Yii::app()->name . ' - Cuenta de usuario';
$this->breadcrumbs=array(
	'Cuenta de usuario',
);

?>

<h2 class="fill">Mi cuenta</h2>

<section id="account">
    
    <?php if($success != null) {?>
        <div class="successmsg"><p><?php echo $success ?></p></div>
    <?php }?>
    
    
    <section>
        <h3>Mis pedidos</h3>
        <?php echo CHtml::link('Ver todos los pedidos',Yii::app()->createUrl("/order/userorders")); ?>
    </section>

    <section id="config">
        <h3>Configuración de mi cuenta</h3>
        <?php echo CHtml::link('Cambiar contraseña',Yii::app()->createUrl("/account/modifypassword")); ?>
        <?php echo CHtml::link('Cambiar nombre',Yii::app()->createUrl("/account/modifyname")); ?>
        <?php echo CHtml::link('Modificar dirección de envío',Yii::app()->createUrl("/account/modifyaddress")); ?>
    </section>
</section>