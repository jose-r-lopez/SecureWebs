<?php
$this->pageTitle=Yii::app()->name . ' - Modificar nombre de usuario';
$this->breadcrumbs=array(
    'Cuenta de usuario' =>   Yii::app()->createUrl('account/'),
	'Modificar nombre',
);
?>

<h2 class="fill">Modificar nombre de usuario</h2>

<section class="form">
    <h3>Nuevo nombre</h3>
    
    <?php if($error != null){ ?>
        <div class="formerror"><p><?php echo $error ?></p></div>
    <?php } ?>
    
    <?php echo CHtml::beginForm(); ?>

        <div>
            <?php echo CHtml::label('Nombre del usuario','name'); ?>
            <?php echo CHtml::textField('name', $name) ?>
        </div>

        <div>
            <?php echo CHtml::submitButton('Cambiar nombre'); ?>
        </div>

    <?php echo CHtml::endForm(); ?>
</section>