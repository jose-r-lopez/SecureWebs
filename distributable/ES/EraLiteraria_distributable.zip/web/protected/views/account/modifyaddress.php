<?php
$this->pageTitle=Yii::app()->name . ' - Modificar dirección';
$this->breadcrumbs=array(
    'Cuenta de usuario' =>   Yii::app()->createUrl('account/'),
	'Modificar dirección de envío',
);
?>

<h2 class="fill">Modificar dirección de envío</h2>

<section class="form">
    <h3>Nueva dirección</h3>
    
    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'address-form',
        'enableClientValidation'=>true,
        'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
    )); ?>

        <div class="row">
            <?php echo $form->labelEx($model,'address'); ?>
            <?php echo $form->textField($model,'address'); ?>
            <?php echo $form->error($model,'address',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'postCode'); ?>
            <?php echo $form->textField($model,'postCode'); ?>
            <?php echo $form->error($model,'postCode',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'city'); ?>
            <?php echo $form->textField($model,'city'); ?>
            <?php echo $form->error($model,'city',array('class'=>'formerror')); ?>
        </div>


        <div class="row">
            <?php echo $form->labelEx($model,'province'); ?>
            <?php echo $form->dropDownList($model,'province', $provinces); ?>
            <?php echo $form->error($model,'province',array('class'=>'formerror')); ?>
        </div>


        <div class="row buttons">
            <?php echo CHtml::submitButton('Enviar a esta dirección'); ?>
        </div>

    <?php $this->endWidget(); ?>
</section>