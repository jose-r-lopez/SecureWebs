<?php

$this->pageTitle=Yii::app()->name . ' - Inicio de sesión';
$this->breadcrumbs=array(
	'Inicio de sesión',
);
?>

<h2 class="fill">Iniciar Sesión</h2>

<section class="form">
    <h3>Accede a tu cuenta</h3>
    
     <?php if($registerResult != null) {?>
            <div class="succesregister"><p><?php echo $registerResult ?></p></div>
        <?php }?>
    
    <p>Los campos marcados con * son obligatorios.</p>

    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'login-form',
        'enableClientValidation'=>true,
        'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
    )); ?>
    
         <?php if($error != null) {?>
            <div class="formerror"><p><?php echo $error ?></p></div>
        <?php }?>

        <div class="row">
            <?php echo $form->labelEx($model,'username'); ?>
            <?php echo $form->textField($model,'username'); ?>
            <?php echo $form->error($model,'username',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'password'); ?>
            <?php echo $form->passwordField($model,'password'); ?>
            <?php echo $form->error($model,'password',array('class'=>'formerror')); ?>
        </div>

        <div class="row buttons">
            <?php echo CHtml::submitButton('Login'); ?>
        </div>

    <?php $this->endWidget(); ?>
    
    <p>Si no tienes cuenta <?php echo CHtml::link('Registrate aquí',Yii::app()->createUrl("/account/register")); ?></p>
</section>