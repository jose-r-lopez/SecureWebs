<?php
$this->pageTitle=Yii::app()->name . ' - Modificar contraseña';
$this->breadcrumbs=array(
    'Cuenta de usuario' =>   Yii::app()->createUrl('account/'),
	'Modificar contraseña',
);
?>

<h2 class="fill">Modificar Contraseña</h2>

<section class="form">
    <h3>Nueva contraseña</h3>
    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'change-form',
        'enableClientValidation'=>true,
        'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
    )); ?>

        <div class="row">
            <?php echo $form->labelEx($model,'oldPassword'); ?>
            <?php echo $form->passwordField($model,'oldPassword'); ?>
            <?php echo $form->error($model,'oldPassword',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'newPassword'); ?>
            <?php echo $form->passwordField($model,'newPassword'); ?>
            <?php echo $form->error($model,'newPassword',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'repeatNewPass'); ?>
            <?php echo $form->passwordField($model,'repeatNewPass'); ?>
            <?php echo $form->error($model,'repeatNewPass',array('class'=>'formerror')); ?>
        </div>

        <div class="row buttons">
            <?php echo CHtml::submitButton('Cambiar contraseña'); ?>
        </div>

    <?php $this->endWidget(); ?>
</section>