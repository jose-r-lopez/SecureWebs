<?php

$this->pageTitle=Yii::app()->name . ' - Registro';
$this->breadcrumbs=array(
	'Registro',
);
?>

<h2 class="fill">Registro</h2>

<section class="form">
    <h3>Crear cuenta</h3>
    <p>Los campos marcados con * son obligatorios.</p>

    <?php if($error != null){ ?>
        <div class="errormform">
            <p><?php echo $error ?></p>
        </div>
    <?php } ?>
    
    <?php $form=$this->beginWidget('CActiveForm', array(
        'id'=>'register-form',
        'enableClientValidation'=>true,
        'clientOptions'=>array(
            'validateOnSubmit'=>true,
        ),
    )); ?>
    
    
        <div class="row">
            <?php echo $form->labelEx($model,'email'); ?>
            <?php echo $form->textField($model,'email'); ?>
            <?php echo $form->error($model,'email',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'username'); ?>
            <?php echo $form->textField($model,'username'); ?>
            <?php echo $form->error($model,'username',array('class'=>'formerror')); ?>
        </div> 

        <div class="row">
            <?php echo $form->labelEx($model,'password'); ?>
            <?php echo $form->passwordField($model,'password'); ?>
            <?php echo $form->error($model,'password',array('class'=>'formerror')); ?>
        </div>

        <div class="row">
            <?php echo $form->labelEx($model,'repeatPass'); ?>
            <?php echo $form->passwordField($model,'repeatPass'); ?>
            <?php echo $form->error($model,'repeatPass',array('class'=>'formerror')); ?>
        </div>

        <div class="row buttons">
            <?php echo CHtml::submitButton('Registrarse'); ?>
        </div>

    <?php $this->endWidget(); ?>
   <p>Si ya tienes una cuenta <?php echo CHtml::link('Inicia sesión aquí',Yii::app()->createUrl("/account/login")); ?></p>
</section>