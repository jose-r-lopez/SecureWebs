<?php
   $this->pageTitle=Yii::app()->name . ' - Pedidos';
    $this->breadcrumbs=array(
        'Pedidos',
    );


    $cs=Yii::app()->clientScript;
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.min.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.columnFilter.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/views/order/orders.js', CClientScript::POS_HEAD);
    $cs->registerCssFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/css/jquery.dataTables.css');
?>

<h2>Administrar pedidos</h2>

<section>
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
    
<table id="orders">
    <thead>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Estado</th>
            <th>Precio total</th>
            <th>Fecha</th>
            <th></th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Estado</th>
            <th>Precio total</th>
            <th>Fecha</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($orders as $order) {?>
            <tr>
                <td><?php echo $order->order_id ?></td>
                <td><?php echo $order->email ?></td>
                <td><?php echo $order->status ?></td>
                <td><?php echo $order->totalPrice ?></td>
                <td><?php echo $order->creationTime ?></td>
                <td>
                    <?php echo CHtml::link('Ver pedido', Yii::app()->createUrl("/admin/showOrder", array("id" => $order->order_id))); ?>
                    <?php echo CHtml::link('Eliminar pedido', Yii::app()->createUrl("/admin/deleteOrder", array("id" => $order->order_id))); ?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</section>    