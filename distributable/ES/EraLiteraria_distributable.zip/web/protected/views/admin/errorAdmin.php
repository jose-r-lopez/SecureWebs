<?php
$this->pageTitle=Yii::app()->name . ' - Error';
$this->breadcrumbs=array(
	'Error',
);
?>

<h2>Error <?php echo $code ?></h2>

<section class="error">
    <p> Ha ocurrido un error en la web.</p>
</section>