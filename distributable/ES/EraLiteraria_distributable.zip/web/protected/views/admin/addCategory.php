<?php
    $this->pageTitle=Yii::app()->name . ' - Nueva Categoría';

    $this->breadcrumbs=array(
        'Categorías' => Yii::app()->createUrl('admin/categories'),
        'Nueva Categoría',
    );
?>

<h2>Añadir categoría</h2>

<section>
    
    <?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
    
<?php $form=$this->beginWidget('CActiveForm', array(
    'id'=>'add-category-form',
    'enableClientValidation'=>true,
    'clientOptions'=>array(
        'validateOnSubmit'=>true,
    ),
)); ?>

	<div>
		<?php echo $form->labelEx($model,'parentCategory'); ?>
         <?php $list = CHtml::listData($categories, 
                'category_id', 'label');
        echo CHtml::activeDropDownList($model,'parentCategory',$list);  ?>
        
		<?php echo $form->error($model,'parentCategory',array('class'=>'formerror')); ?>
	</div>



	<div>
		<?php echo $form->labelEx($model,'label'); ?>
		<?php echo $form->textField($model,'label'); ?>
		<?php echo $form->error($model,'label',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo CHtml::submitButton('Crear categoría'); ?>
	</div>

<?php $this->endWidget(); ?>
</section>