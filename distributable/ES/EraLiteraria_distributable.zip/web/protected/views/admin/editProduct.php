<?php
    $this->pageTitle=Yii::app()->name . ' - Editar Producto';

    $this->breadcrumbs=array(
        'Productos' => Yii::app()->createUrl('admin/products'),
        'Editar Producto',
    );
?>

<h2>Editar producto</h2>

<section>

 <?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
    
<?php $form=$this->beginWidget('CActiveForm', array(
    'id'=>'edit-book-form',
    'enableClientValidation'=>true,
    'clientOptions'=>array(
        'validateOnSubmit'=>true,
    ),
)); ?>


	<div>
		<?php echo $form->labelEx($model,'isbn'); ?>
		<?php echo $form->textField($model,'isbn'); ?>
		<?php echo $form->error($model,'isbn',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name'); ?>
		<?php echo $form->error($model,'name',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'author'); ?>
		<?php echo $form->textField($model,'author'); ?>
		<?php echo $form->error($model,'isbn',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'publisher'); ?>
		<?php echo $form->textField($model,'publisher'); ?>
		<?php echo $form->error($model,'publisher',array('class'=>'formerror')); ?>
	</div>


    <div>
		<?php echo $form->labelEx($model,'price'); ?>
		<?php echo $form->textField($model,'price'); ?>
		<?php echo $form->error($model,'price',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'stock'); ?>
		<?php echo $form->textField($model,'stock'); ?>
		<?php echo $form->error($model,'stock',array('class'=>'formerror')); ?>
	</div>


    <div>
		<?php echo $form->labelEx($model,'cover'); ?>
		<?php echo $form->textField($model,'cover'); ?>
		<?php echo $form->error($model,'cover',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'pages'); ?>
		<?php echo $form->textField($model,'pages'); ?>
		<?php echo $form->error($model,'pages',array('class'=>'formerror')); ?>
	</div>


    <div>
		<?php echo $form->labelEx($model,'year'); ?>
		<?php echo $form->textField($model,'year'); ?>
		<?php echo $form->error($model,'year',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'description'); ?>
		<?php echo $form->textField($model,'description'); ?>
		<?php echo $form->error($model,'description',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'format'); ?>
		<?php echo $form->textField($model,'format'); ?>
		<?php echo $form->error($model,'format',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'language'); ?>
		<?php echo $form->textField($model,'language'); ?>
		<?php echo $form->error($model,'language',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'upload_Date'); ?>
		<?php echo $form->textField($model,'upload_Date'); ?>
		<?php echo $form->error($model,'upload_Date',array('class'=>'formerror')); ?>
	</div> 

	<div>
		<?php echo $form->labelEx($model,'category_id'); ?>
        <?php $list = CHtml::listData($categories, 'category_id', 'label'); echo CHtml::activeDropDownList($model,'category_id',$list);  ?>
		<?php echo $form->error($model,'category_id',array('class'=>'formerror')); ?>
	</div>


	<div>
		<?php echo CHtml::submitButton('Editar producto'); ?>
	</div>

<?php $this->endWidget(); ?>
</section>