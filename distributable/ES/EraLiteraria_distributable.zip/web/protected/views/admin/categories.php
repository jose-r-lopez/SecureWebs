<?php

 $this->pageTitle=Yii::app()->name . ' - Categorías';
    $this->breadcrumbs=array(
        'Categorías',
    );

$cs=Yii::app()->clientScript;
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.min.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.columnFilter.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/views/category/categories.js', CClientScript::POS_HEAD);
 $cs->registerCssFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/css/jquery.dataTables.css');
?>

<h2>Administrar categorías</h2>

<section>

<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
<?php echo CHtml::link('Añadir categoría', Yii::app()->createUrl("/admin/addCategory"), array('class' => 'darkButton')); ?>

<table id="categories">
    <thead>
        <tr>
            <th>ID</th>
            <th>Etiqueta</th>
            <th>Padre</th>
            <th></th>
        </tr>
        
        <tr>
            <th>ID</th>
            <th>Etiqueta</th>
            <th>Padre</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($categories as $category) {?>
            <tr>
                <td><?php echo $category->category_id ?></td>
                <td><?php echo $category->label ?></td>
                <td><?php echo ($category->parent_id != null )? $category->getParentLabel() . " (" . ($category->parent_id) . ") ": 'No tiene padre' ?></td>
                <td>
                    <?php echo CHtml::link('Editar categoria', Yii::app()->createUrl("/admin/editCategory", array("id" => $category->category_id))); ?>
                    <?php echo CHtml::link('Eliminar categoría', Yii::app()->createUrl("/admin/deleteCategory" , array("id" => $category->category_id))); ?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</section>