<?php
    $this->pageTitle=Yii::app()->name . ' - Nuevo Usuario';

    $this->breadcrumbs=array(
        'Usuarios' => Yii::app()->createUrl('admin/users'),
        'Nuevo Usuario',
    );
?>


<h2>Añadir usuario</h2>

<section>
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
    
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'add-user-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->textField($model,'email'); ?>
		<?php echo $form->error($model,'email',array('class'=>'formerror')); ?>
	</div>

    <div class="row">
		<?php echo $form->labelEx($model,'username'); ?>
		<?php echo $form->textField($model,'username'); ?>
		<?php echo $form->error($model,'username',array('class'=>'formerror')); ?>
	</div> 

	<div class="row">
		<?php echo $form->labelEx($model,'password'); ?>
		<?php echo $form->passwordField($model,'password'); ?>
		<?php echo $form->error($model,'password',array('class'=>'formerror')); ?>
	</div>

    <div class="row">
		<?php echo $form->labelEx($model,'repeatPass'); ?>
		<?php echo $form->passwordField($model,'repeatPass'); ?>
		<?php echo $form->error($model,'repeatPass',array('class'=>'formerror')); ?>
	</div>

    <div class="row">
		<?php echo $form->labelEx($model,'isAdmin'); ?>
		<?php echo $form->checkBox($model,'isAdmin',  array('value'=>1, 'uncheckValue'=>0)); ?>
		<?php echo $form->error($model,'isAdmin',array('class'=>'formerror')); ?>
	</div>


	<div class="row buttons">
		<?php echo CHtml::submitButton('Añadir usuario'); ?>
	</div>

<?php $this->endWidget(); ?>
</section>