<?php
    $this->pageTitle=Yii::app()->name . ' - Detalles pedido';

    $this->breadcrumbs=array(
        'Pedidos' => Yii::app()->createUrl('admin/orders'),
        'Detalles pedido',
    );

$cs=Yii::app()->clientScript;
$cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.min.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.columnFilter.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/views/order/showOrder.js', CClientScript::POS_HEAD);
 $cs->registerCssFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/css/jquery.dataTables.css');
?>

<h2>Pedido <?php echo $order->order_id?></h2>

<section id="order">
    
    <section>
        <h3>Datos del pedido</h3>

        <p>Número de pedido: <?php echo $order->order_id ?></p>
        <p>Usuario: <?php echo $order->email ?></p>
        <p>Precio total (con gastos de envío): <?php echo $order->totalPrice ?></p>
        <p>Estado del pedido: <?php echo Order::getStatusLabel($order->status)?>
        <?php echo CHtml::link('Cambiar a creado', Yii::app()->createUrl("/admin/changeorder", array("param" => "created", "id" => $order->order_id))); ?>
        <?php echo CHtml::link('Cambiar a pagado', Yii::app()->createUrl("/admin/changeorder", array("param" => "paid","id" => $order->order_id))); ?>
        <?php echo CHtml::link('Cambiar a error', Yii::app()->createUrl("/admin/changeorder", array("param" => "error","id" => $order->order_id))); ?>
        <?php echo CHtml::link('Cambiar a enviado', Yii::app()->createUrl("/admin/changeorder" , array("param" => "sent","id" => $order->order_id))); ?></p>
        <p>Fecha de creación: <?php echo $order->creationTime ?></p>
    </section>
    <section>
        <h3>Items en el pedido</h3>
        <table id="items">
            <thead>
            <tr>
                <th>ISBN</th>
                <th>Título</th>
                <th>Autor</th>
                <th>Precio</th>
                <th>Unidades</th>
                <th>Total</th>
            </tr>
            </thead>
            <tbody>
        <?php foreach($order->items as $item){ ?>
            <?php $book = $item->getBookData()?>
            <tr>
                <td><?php echo $item->isbn ?></td>
                <td><?php echo $book->name ?></td>
                <td><?php echo $book->author ?></td>
                <td><?php echo $book->price ?></td>
                <td><?php echo $item->units ?></td>
                <td><?php echo $item->totalPrice ?></td>
            </tr>
        <?php } ?>
                </tbody>
        </table>    
    </section>    
</section>