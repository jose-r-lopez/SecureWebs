<?php
    $this->pageTitle=Yii::app()->name . ' - Productos';
    $this->breadcrumbs=array(
        'Productos',
    );

    $cs=Yii::app()->clientScript;
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.min.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.columnFilter.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/views/book/products.js', CClientScript::POS_HEAD);
    $cs->registerCssFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/css/jquery.dataTables.css');
?>


<h2>Administrar productos</h2>

<section>

<?php echo CHtml::link('Añadir libro', Yii::app()->createUrl("/admin/addProduct"), array('class' => 'darkButton')); ?>
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>

<table id="products">
    <thead>
        <tr>
            <th>ISBN</th>
            <th>Nombre</th>
            <th>Stock</th>
            <th>Precio</th>
            <th>Fecha Subida</th>
            <th></th>
        </tr>
        
        <tr>
            <th>ISBN</th>
            <th>Nombre</th>
            <th>Stock</th>
            <th>Precio</th>
            <th>Fecha Subida</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($books as $book) {?>
            <tr>
                <td><?php echo $book->isbn ?></td>
                <td><?php echo $book->name ?></td>
                <td><?php echo $book->stock ?></td>
                <td><?php echo $book->price ?></td>
                <td><?php echo $book->upload_Date ?></td>
                <td>
                    <?php echo CHtml::link('Editar libro', Yii::app()->createUrl("/admin/editProduct", array("id" => $book->isbn))); ?>
                    <?php echo CHtml::link('Eliminar libro', Yii::app()->createUrl("/admin/deleteProduct", array("id" => $book->isbn))); ?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</section>