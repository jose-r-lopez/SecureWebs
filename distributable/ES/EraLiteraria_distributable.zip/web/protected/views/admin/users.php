<?php
    $this->pageTitle=Yii::app()->name . ' - Usuarios';
    $this->breadcrumbs=array(
        'Usuarios',
    );

    $cs=Yii::app()->clientScript;
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.min.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/js/jquery.dataTables.columnFilter.js', CClientScript::POS_HEAD);
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/views/user/users.js', CClientScript::POS_HEAD);
 $cs->registerCssFile(Yii::app()->baseUrl . '/assets/DataTables-1.10.6/media/css/jquery.dataTables.css');
?>


<h2>Administrar usuarios</h2>

<section>
<?php echo CHtml::link('Añadir usuario', Yii::app()->createUrl("/admin/addUser"), array('class' => 'darkButton')); ?>

<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>

<table id="users">
    <thead>
        <tr>
            <th>Email</th>
            <th>Name</th>
            <th></th>
        </tr>
        <tr>
            <th>Email</th>
            <th>Name</th>
            <th>Acciones</th>
        </tr>
    <thead>
    <tbody>
        <?php foreach($users as $user) {?>
            <tr>
                <td><?php echo $user->email ?></td>
                <td><?php echo $user->name ?></td>
                <td>
                    <?php $url = Yii::app()->createUrl("/admin/deleteUser");
                    echo CHtml::link(
                            'Eliminar usuario',
                            $url,
                            array(
                                    'submit' => $url,
                                    'params' => array('id' => $user->email),
                            )
                            );?>

                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</section>  