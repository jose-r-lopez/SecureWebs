<?php
    $this->pageTitle=Yii::app()->name . ' - Editar Categoría';

    $this->breadcrumbs=array(
        'Categorías' => Yii::app()->createUrl('admin/categories'),
        'Editar Categoría',
    );
?>

<h2>Editar categoría</h2>

<section>
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
<?php $form=$this->beginWidget('CActiveForm', array(
    'id'=>'edit-category-form',
    'enableClientValidation'=>true,
    'clientOptions'=>array(
        'validateOnSubmit'=>true,
    ),
)); ?>


    <div>
		<?php echo $form->labelEx($model,'categoryID'); ?>
        <?php echo $form->textField($model,'categoryID'); ?>
		<?php echo $form->error($model,'categoryID',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'parentCategory'); ?>
         <?php $list = CHtml::listData($categories, 
                'category_id', 'label');
        echo CHtml::activeDropDownList($model,'parentCategory',$list);  ?>
        
		<?php echo $form->error($model,'parentCategory',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'label'); ?>
		<?php echo $form->textField($model,'label'); ?>
		<?php echo $form->error($model,'label',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo CHtml::submitButton('Editar categoría'); ?>
	</div>

<?php $this->endWidget(); ?>
</section>