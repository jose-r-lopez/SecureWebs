<?php

    $this->pageTitle=Yii::app()->name . ' - Próximamente';

    $this->breadcrumbs=array(
        'Próximamente'
    );
?>

<h2 class="fill">Próximamente</h2>

<section>
    <ul id="listbooks">
    <?php 
        if(count($books) != 0){
            foreach($books as $book){
                ?>
            <li>
                <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                 echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>
                
                <div>
                    <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                    <p class="author"><?php echo $book->author ?></p>
                    <p class="publisher"><?php echo $book->publisher ?></p>
                        
                    <p class="noAva">No está disponible actualmente.</p>
                    <p class="price"><?php echo $book->price ?> €</p>
                </div>
            </li>
    <?php
            } 
    } ?>
        
    </ul>    
    
    <?php if(count($books) == 0){ ?>
        <p class="noResult">No hay ningún libro que vaya a publicarse próximamente.</p>
    <?php } ?>
</section>
