<?php
/* @var $this CategoryController */
    $this->pageTitle=Yii::app()->name;

    $this->breadcrumbs=array(
        $categoryName =>   Yii::app()->createUrl('book/categories',array('id'=>$categoryID, 'name'=>$urlName)),
        $book->name
    );
?>

<h2 class="fill"><?php echo $book->name ?></h2>

<section id="infoBook">
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>

<?php if($book != null) {?>
    <section id="firstInfo">
        <img src="<?php echo $book->cover ?>" alt="Portada del libro . <?php echo $book->name ?> ">
        <div>
            <p class="titlefi"><?php echo $book->name ?></p>
            <p><?php echo $book->author ?></p>
            <p class="isbn">ISBN: <?php echo $book->isbn ?></p>
            <p><?php $this->widget('ext.dzRaty.DzRaty', array(
                        'name' => 'rating_book',
                        'value' => $book->rating,
                        'options' => array(
                            'readOnly' => TRUE,
                        ),
                    )); ?></p>
            
            <p><?php echo $book->format ?> - <?php echo $book->publisher ?></p>

            <div id="cartInfo">
                
                <?php 
                    $date= $book->upload_Date;
                    $seconds=strtotime($date) - strtotime('now');
                    $diff=intval($seconds/60/60/24);
        
                    if($book->stock > 0 && $diff <= 0){ ?>
                   <?php $form = $this->beginWidget('CActiveForm', array(
                        'id'=>'cart-form',
                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                    )); ?>
                        <p class="price"><?php echo $book->price ?> €</p>
                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                        <?php echo CHtml::submitButton('Añadir a la Cesta'); ?>
                    <?php $this->endWidget(); ?>
                <?php } else {?>
                    <p class="price">No está disponible actualmente.</p>
                 <?php }?>
            </div>
        </div>
    </section>
    
    <section id="largeInfo">
         <h3>Información en detalle</h3>
        <div>
             <p><?php echo $book->description ?></p>
        </div>
        
        <dl>
            <dt>ISBN</dt>
            <dd><?php echo $book->isbn ?></dd>
            <dt>Editorial</dt>
            <dd><?php echo $book->publisher ?></dd>
            <dt>Categoría</dt>
            <dd><?php echo $categoryName ?></dd>
            <dt>Formato</dt>
            <dd><?php echo $book->format ?></dd>
            <dt>Año</dt>
            <dd><?php echo $book->year ?></dd>
            <dt>Páginas</dt>
            <dd><?php echo $book->pages ?></dd>
            <dt>Leguaje</dt>
            <dd><?php echo $book->language ?></dd>
        </dl>
    </section>
    
    <section id="reviews">
        <h3 class="darkBack">Opiniones de clientes</h3>
        <p><?php echo CHtml::link('Escribe tu opinión',Yii::app()->createUrl("/review/create",array("id"=>$book->isbn))) ?></p>
        
        <?php if(count($reviews) == 0) { ?>
            <p class="noResult">No hay opiniones acerca de este producto.</p>
        <?php }else{?>
            <ul>
            <?php foreach($reviews as $review){?>
                <li>
                    <p class="title"> <?php echo $review->title ?> <?php $this->widget('ext.dzRaty.DzRaty', array(
                        'name' => 'ratingUser',
                        'value' => $review->rating,
                        'options' => array(
                            'readOnly' => TRUE,
                        ),
                    )); ?></p>
                    
                    <p class="user"> Por <?php echo $review->user->name?></p>
                    
                    <p><?php echo $review->text?></p>
                   
                </li>
            <?php }?>
            </ul>
        <?php }?>
        
      
    </section>
    
    <?php }else{?>
    
        <div class="errormsg"><p>Ha ocurrido un error con su petición.</p></div>
    
    <?php }?>
</section>

