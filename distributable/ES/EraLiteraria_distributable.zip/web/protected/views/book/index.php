<?php

    $this->pageTitle=Yii::app()->name . ' - Lista de libros';

    $this->breadcrumbs=array(
        'Categorías',
        $category
    );
?>

<h2 class="fill"><?php echo $category ?></h2>

<section>
    <ul id="listbooks">
    <?php 
        if(count($books) != 0){
            foreach($books as $book){
                ?>
            <li>
                <?php $img = CHtml::image($book['cover'], "Portada del libro " . $book['name'] );
                 echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book['isbn']))) ?>
                
                <div>
                    <p class="title"><?php echo CHtml::link($book['name'],Yii::app()->createUrl("/book/view",array("id"=>$book['isbn']))) ?></p> 
                    <p class="author"><?php echo $book['author'] ?></p>
                    <p class="publisher"><?php echo $book['publisher'] ?></p>
                        
                    <?php 
                        $date= $book['upload_Date'];
                        $seconds=strtotime($date) - strtotime('now');
                        $diff=intval($seconds/60/60/24);
                       if($book['stock'] > 0 && $diff <= 0){ ?>
                        <?php $form = $this->beginWidget('CActiveForm', array(
                            'id'=>'cart-form',
                            'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book['isbn'])),
                        )); ?>
                            <?php echo CHtml::hiddenField('isbn' , $book['isbn']); ?>
                            <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                        <?php $this->endWidget(); ?>
                    <?php } else { ?>
                        <p class="noAva">No está disponible actualmente.</p>
                    <?php }  ?>
                    <p class="price"><?php echo $book['price'] ?> €</p>
                </div>
            </li>
    <?php
            } 
    } ?>
        
    </ul>    
    
    <?php if(count($books) == 0){ ?>
        <p class="noResult">No existe ningún libro en esta categoría.</p>
    <?php } ?>
</section>
