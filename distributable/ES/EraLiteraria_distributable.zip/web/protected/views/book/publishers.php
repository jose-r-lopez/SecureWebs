<?php

    $this->pageTitle=Yii::app()->name . ' - Editoriales';

    $this->breadcrumbs=array(
        'Editoriales'
    );
?>

<h2 class="fill">Editoriales</h2>

<section>
    <ul id="listPublishers">
    <?php 
        if(count($publishers) != 0){
            for($i = 0 ; $i<count($publishers) ; $i++){
                
                if(($i + 1)%4 == 0){ 
                ?>
                    <li class="four">
                <?php }else{?>
            <li>
                <?php } ?>
                
               <?php 
                
                $urlName = str_replace(' ', '_', $publishers[$i]['publisher']);
                $urlName = str_replace(chr(46), '', $urlName); 
                $urlName = str_replace('-', '', $urlName);
                
                 echo CHtml::link($publishers[$i]['publisher'],Yii::app()->createUrl("/search/publisher", array("id" => $urlName))) ?>
            </li>
    <?php
            } 
    } ?>
        
    </ul>    
    
    <?php if(count($publishers) == 0){ ?>
        <p class="noResult">No hay editoriales disponibles.</p>
    <?php } ?>
</section>
