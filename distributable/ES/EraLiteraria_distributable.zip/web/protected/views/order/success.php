<?php

$this->pageTitle=Yii::app()->name . ' - Tramitar pedido - Éxito';
$this->breadcrumbs=array(
	'Tramitar pedido',
    'Pedido Completado'
);
?>

<h2 class="fill">Pedido finalizado con éxito</h2>

<section id="success">
    <h3>Pedido Tramitado</h3>
    <p>La tramitación de su pedido ha finalizado, para ver los datos y estado de éste puede ir a 
    <?php echo CHtml::link("su cuenta",Yii::app()->createUrl("/order/userorders"))?>.</p>
</section>
