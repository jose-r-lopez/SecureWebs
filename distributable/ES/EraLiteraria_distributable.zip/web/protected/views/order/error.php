<?php

$this->pageTitle=Yii::app()->name . ' - Tramitar pedido - Error';
$this->breadcrumbs=array(
    'Tramitar pedido',
	'Error',
);
?>

<h2 class="fill">Error al realizar el pedido</h2>

<section id="error">
    <h3>Error en el pedido</h3>
    <p>Ha ocurrido un error con su pedido, pruebe a volver a realizarlo.</p>
</section>