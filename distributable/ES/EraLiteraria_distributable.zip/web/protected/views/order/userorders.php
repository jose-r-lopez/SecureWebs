<?php

$this->pageTitle=Yii::app()->name . ' - Pedidos del usuario';
$this->breadcrumbs=array(
	'Cuenta de usuario' =>   Yii::app()->createUrl('account/'),
    'Pedidos'
);
?>

<h2 class="fill">Pedidos del usuario</h2>

<section id="userorders">
<?php if(count($orders) == 0) { ?>
        <p class="empty">El usuario no ha realizado ningún pedido.</p>
<?php }else{ ?>  
<?php foreach($orders as $order){ ?>

        <section>
        <h3>Pedido: <?php echo $order->order_id ?></h3>
           
            <p>Contenido del pedido:</p>
            
            <table>
                <tr>
                    <th>Datos</th>
                    <th>Precio</th>
                    <th>Unidades</th>
                    <th>Total</th>
                </tr>
       <?php foreach($order->items as $item){ ?>
            <?php $book = $item->getBookData()?>
                <tr>
            <td class="first">
                <p><span>ISBN: </span><?php echo $item->isbn ?></p>
                <p><span>Título: </span><?php echo $book->name ?></p>
                <p><span>Autor: </span><?php echo $book->author ?></p>
            </td>
            <td class="second"><span>Precio: </span><?php echo $book->price ?> EUR</td>
            <td class="third"><span>Unidades: </span><?php echo $item->units ?></td>
            <td class="fourth"><span>Total:</span> <?php echo $item->totalPrice ?> EUR</td>
            </tr>
    
            
            
        <?php } ?>
                
                </table>
            
            <div>
               <p><span>Precio total (con gastos de envío): </span><?php echo $order->totalPrice ?> EUR</p>
               <p><span>Estado del pedido: </span><?php echo Order::getStatusLabel($order->status) ?></p>
            </div>
        </section>

    <?php } ?>
<?php }?>
</section>    