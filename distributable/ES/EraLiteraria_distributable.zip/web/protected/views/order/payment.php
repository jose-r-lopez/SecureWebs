<?php

$this->pageTitle=Yii::app()->name . ' - Tramitar pedido - Datos del pedido';
$this->breadcrumbs=array(
	'Tramitar pedido',
    'Datos del pedido',
);
?>

<h2 class="fill">Datos del pedido</h2>

<section id="payment">
    
    <?php if($error != null) {?>
        <p class="errormsg"><?php echo $error ?></p>
    <?php }?>
    
    <section>
        <h3 class="center">Dirección</h3>
        <p><span>Dirección: </span><?php echo $address['address'] ?></p>
        <p><span>Código postal:</span> <?php echo $address['postCode'] ?></p>
        <p><span>Ciudad: </span><?php echo $address['city'] ?></p>
        <p><span>Provincia: </span><?php echo AddressForm::$provinces[$address['province']] ?></p>
    </section>

     <section>
    <h3 class="center">Productos</h3>
    <?php $cart = Yii::app()->session["cart"]; ?>


     <table>
                <tr>
                    <th>Artículo</th>
                    <th>Unidades</th>
                    <th>Precio</th>
                </tr>
            <?php 
                $cartItems = $cart->getItems();                       
                foreach($cartItems as $item){ 
                    $product = $item->getProduct(); ?>
                    <tr>
                        <td class="first">    
                             <?php $img = CHtml::image($product->cover, "Portada del libro " . $product->name );
                                echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$product->isbn))) ?>
                            
                                <div id="itemData">
                                    <p><?php echo CHtml::link($product->name,Yii::app()->createUrl("/book/view",array("id"=>$product->isbn))) ?> </p>
                                    <p><?php echo $product->author ?> </p>
                                </div>
                        </td>
                        
                        <td class="second"><?php echo $item->getUnits() ?></td>
                        <td class="third"><?php echo $product->price ?> €</td>
                    </tr>
                <?php } ?>

            </table>
    </section>
    
    
    <section>
        <h3 class="center">Resumen del pedido</h3>

        <p><span>Total de productos: </span><?php echo $cart->getNumberOfItems()?></p>
        <p><span>Precio Total: </span><?php echo $cart->getTotalPrice() ?> </p>
        <p><span>Gastos de envío: </span><?php echo ShoppingCart::getShipping() ?> </p>
        <p><span>Total: </span><?php echo $cart->getTotalPriceWithShipping() ?> </p>
     </section>
    
    
    <?php echo $form ?>

</section>
