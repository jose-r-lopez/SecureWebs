<?php

$this->pageTitle=Yii::app()->name . ' - Tramitar pedido - Dirección de envío';
$this->breadcrumbs=array(
	'Tramitar pedido',
    'Indicar dirección de envío',
);
?>

<h2 class="fill">Dirección de envío</h2>

<section id="mainAddress">
    
<?php if($error != null) {?>
        <div class="errormsg"><p><?php echo $error ?></p></div>
 <?php }?>
<section id="address">
    <h3 class="darkBack center underline">Última dirección usada</h3>
    
    <?php if($address != null){?> 
    <ul>
        <li>Dirección: <?php echo $address['address'] ?></li>
        <li>Código Postal: <?php echo $address['postCode'] ?></li>
        <li>Ciudad: <?php echo $address['city'] ?></li>
        <li>Provincia: <?php echo $provinces[$address['province']] ?></li>
    </ul>
      <?php echo CHtml::link("Usar esta dirección", Yii::app()->createUrl("/order/payment")) ?>
    <?php }else{ ?>
            <p>No hay ninguna dirección anterior.</p>
    <?php } ?>
  
</section>

 <section class="form">   
     <h3>Nueva dirección</h3>
<p>Los campos marcados con * son obligatorios.</p>

<?php $form=$this->beginWidget('CActiveForm', array(
    'id'=>'address-form',
    'enableClientValidation'=>true,
    'clientOptions'=>array(
        'validateOnSubmit'=>true,
    ),
)); ?>

	<div>
		<?php echo $form->labelEx($model,'address'); ?>
		<?php echo $form->textField($model,'address'); ?>
		<?php echo $form->error($model,'address',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'postCode'); ?>
		<?php echo $form->textField($model,'postCode'); ?>
		<?php echo $form->error($model,'postCode',array('class'=>'formerror')); ?>
	</div>

    <div>
		<?php echo $form->labelEx($model,'city'); ?>
		<?php echo $form->textField($model,'city'); ?>
		<?php echo $form->error($model,'city',array('class'=>'formerror')); ?>
	</div>


    <div>
		<?php echo $form->labelEx($model,'province'); ?>
        <?php echo $form->dropDownList($model,'province', $provinces); ?>
		<?php echo $form->error($model,'province',array('class'=>'formerror')); ?>
	</div>


	<div>
		<?php echo CHtml::submitButton('Enviar a esta dirección'); ?>
	</div>

<?php $this->endWidget(); ?>
    </section>
</section>
