<?php
    $this->pageTitle=Yii::app()->name . ' - Se ha añadido un elemento al carrito';
    $this->breadcrumbs=array(
         $categorylabel =>   Yii::app()->createUrl('book/categories',array('id'=>$item->category_id, 'name'=>$categorylabel)),
         $item->name => Yii::app()->createUrl('book/view',array('id'=>$item->isbn)),
        'Añadido al carrito'
    );
?>


<h2 class="fill">Has añadido un libro al carrito</h2>

<section id="addCart">
    
    <h3>Se ha añadido al carrito el libro:</h3>
    <div>
        <div id="imgitem">
            <img src="<?php echo $item->cover ?>">
        </div>

        <div id="item">
            <p><?php echo $item->name ?></p>
            <p>Autor: <?php echo $item->author ?></p>
            <p>Precio: <?php echo $item->price ?> €</p>


            <div id="statusCart">
            <?php if(isset(Yii::app()->session["cart"])){
                    $cart = Yii::app()->session["cart"]; ?>

                <p>Subtotal del pedido: <?php echo $cart->getTotalPrice() ?> €</p>
                <p> <?php echo $cart->getNumberOfItems() ?> libros en el carrito</p>
                <div>
                    <?php echo CHtml::link("Ver Carrito", Yii::app()->createUrl("/shoppingCart")) ?>
                    <?php echo CHtml::link("Tramitar pedido", Yii::app()->createUrl("/order/address")) ?>
                </div>
            </div>
         </div>    
    </div>
    <?php } ?>
</section>