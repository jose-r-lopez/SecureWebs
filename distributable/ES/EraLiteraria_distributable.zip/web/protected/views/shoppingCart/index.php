<?php
    $this->pageTitle=Yii::app()->name . ' - Carrito';
    $this->breadcrumbs=array(
        'Carrito'
    );
?>


<h2 class="fill">Cesta de la compra</h2>

<section id="cart">
    <h3 class="cart">Tu Cesta</h3>
    
     <?php if(Yii::app()->session["errorConfirm"]){ ?>
                <div class="errormsg"><p><?php echo Yii::app()->session["errorConfirm"];Yii::app()->session["errorConfirm"] = null; ?></p></div>
    <?php } ?>
    
<?php 
    if(isset(Yii::app()->session["cart"])){
        $cart = Yii::app()->session["cart"];
        if($cart->getItemsCount() > 0){ ?>

            <table>
                <tr>
                    <th>Artículo</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                </tr>
            <?php 
                $cartItems = $cart->getItems();                       
                foreach($cartItems as $item){ 
                    $product = $item->getProduct(); ?>
                    <tr id="<?php echo $product->isbn ?>">
                        <td class="first">    
                             <?php $img = CHtml::image($product->cover, "Portada del libro " . $product->name );
                                echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$product->isbn))) ?>
                            
                                <div id="itemData">
                                    <p><?php echo CHtml::link($product->name,Yii::app()->createUrl("/book/view",array("id"=>$product->isbn))) ?> </p>
                                    <p><?php echo $product->author ?> </p>
                                
 <?php 
    $url = Yii::app()->createUrl("/shoppingCart/delete", array("id" => $product->isbn));
    echo CHtml::ajaxLink('Eliminar', $url,
           array( // ajaxOptions
                'type'=> 'POST',
                'dataType'=>'json',
                'success' => "js:function(data) {
                                $('.total').text(data.total);
                                $('.totalunits').text(data.units);
                                $('.totalShipping').text(data.totalShipping);
                                var numberOfTd = $('#' + data.isbn).parent().children('tr').length - 1;
                                if(numberOfTd == 1){
                                    $('#' + data.isbn).closest('table').remove();
                                    $('#cartTotal').empty();
                                    $('#cartInfo').text('El carrito está vacío');
                                }else{
                                     $('#' + data.isbn).remove();
                                }
                                
                            }"));
?>
                          </div>
                        </td>
                        <td class="second"><?php echo $product->price ?> €</td>
                        <td class="third"><input type="number" id="units" value="<?php echo $item->getUnits() ?>">



<?php 
    $url = Yii::app()->createUrl("/shoppingCart/update", array("id" => $product->isbn));
    echo CHtml::ajaxLink('Actualizar', $url,
           array( // ajaxOptions
                'type'=> 'POST',
                'dataType'=>'json',
                'data'=>array('units'=>'js:$("#units").val()'),
                'success' => "js:function(data) {
                                $('.total').text(data.total);
                                $('.totalunits').text(data.units);
                                $('.totalShipping').text(data.totalShipping);
                            }"));
?>
</td>
                    </tr>
                <?php } ?>

            </table>

<p id="cartInfo"></p>

<section id="cartTotal">
     <p>Total: <span class="total"><?php echo $cart->getTotalPrice() ?> </span> EUR</p>    
    
    <?php echo CHtml::link("Seguir comprando", Yii::app()->createUrl("/")) ?>
    <?php echo CHtml::link("Tramitar pedido", Yii::app()->createUrl("/order/address"), array("id" => "finishOrder")) ?>
</section>  
 


        <?php }else{ ?>
            <p class="empty">El carrito está vacío</p>
        <?php } ?>   
<?php }else{ ?>
          <p class="empty">El carrito está vacío</p>   
<?php } ?>
</section>