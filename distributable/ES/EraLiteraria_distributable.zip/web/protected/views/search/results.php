<?php
$this->pageTitle=Yii::app()->name . ' - Resultados de búsqueda';
    $this->breadcrumbs=array(
        'Búsqueda',
        'Resultados de búsqueda'
    );
?>

<h2 class="fill">Resultados de la búsqueda</h2>

<section>
    <h3 class="underline">Se muestran los resultados de la búsqueda: <?php echo $text ?></h3>
<?php 
    if(isset($books) && count($books) != 0){ ?>
        <ul id="listResults">
       <?php  foreach($books as $book){ ?>
        <li>
            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                 echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>
            
            <div>
                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                <p class="author">Autor: <?php echo $book->author ?></p>
                <p class="publisher">Editorial: <?php echo $book->publisher ?></p>
                
                <?php if($book->stock > 0){ ?>
                    <?php $form = $this->beginWidget('CActiveForm', array(
                        'id'=>'cart-form',
                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                    )); ?>
                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                    <?php $this->endWidget(); ?>
                <?php } else { ?>
                    <p class="noAva">No está disponible actualmente.</p>
                <?php }  ?>
                <p class="price"><?php echo $book->price ?> €</p>
            </div>
        </li>
     
<?php
        } ?>
        </ul>  
<?php }else{ ?>
    <p class="noResult"> No hay resultados para esa búsqueda</p>
<?php    }

?>
</section>    