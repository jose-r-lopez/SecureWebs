<?php
$this->pageTitle=Yii::app()->name . ' - Editorial ' . $id;
    $this->breadcrumbs=array(
        'Editoriales' =>   Yii::app()->createUrl('book/publishers'),
        'Libro de la Editorial ' .  $id
    );
?>

<h2 class="fill">Libros de la editorial <?php echo $id?></h2>

<section>
<?php 
    if(count($books) != 0){ ?>
        <ul id="listResults">
       <?php  foreach($books as $book){ ?>
        <li>
            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                 echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>
            
            <div>
                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                <p class="author">Autor: <?php echo $book->author ?></p>
                <p class="publisher">Editorial: <?php echo $book->publisher ?></p>
                
                <?php if($book->stock > 0){ ?>
                    <?php $form = $this->beginWidget('CActiveForm', array(
                        'id'=>'cart-form',
                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                    )); ?>
                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                    <?php $this->endWidget(); ?>
                <?php } else { ?>
                    <p class="noAva">No está disponible actualmente.</p>
                <?php }  ?>
                <p class="price"><?php echo $book->price ?> €</p>
            </div>
        </li>
     
<?php
        } ?>
        </ul>  
<?php }else{ ?>
    <p class="noResult"> No hay libros disponibles para esa editorial.</p>
<?php    }

?>
</section>    