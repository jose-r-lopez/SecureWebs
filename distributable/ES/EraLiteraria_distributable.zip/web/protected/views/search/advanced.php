<?php
    $this->pageTitle=Yii::app()->name . ' - Búsqueda avanzada';
    $this->breadcrumbs=array(
        'Búsqueda avanzada'
    );
?>

<h2 class="fill">Búsqueda avanzada</h2>

<section class="form">
    <h3>Rellena los campos que necesites para realizar la búsqueda.</h3>
     <?php echo CHtml::beginForm(Yii::app()->createUrl("/search/advancedResults"), "post", array("id"=>"search-advance-form")); ?>

    <div>
        <?php echo CHtml::label("ISBN","isbnSearch") ?>
        <?php echo CHtml::textField("isbnSearch", "") ?>
    </div>
    <div>
        <?php echo CHtml::label("Autor","authorSearch") ?>
        <?php echo CHtml::textField("authorSearch", "") ?>
    </div>
    <div>
        <?php echo CHtml::label("Titulo","titleSearch") ?>
        <?php echo CHtml::textField("titleSearch", "") ?>
    </div>
    <div>
        <?php echo CHtml::label("Editorial","publisherSearch") ?>
        <?php echo CHtml::textField("publisherSearch", "") ?>
    </div>
    <div>
        <?php echo CHtml::label("Formato","formatSearch") ?>
          <?php echo CHtml::dropDownList('formatSearch', $formats[0], $formats) ?>
    </div>
    <div>
        <?php echo CHtml::label("Lenguaje","languageSearch") ?>
          <?php echo CHtml::dropDownList('languageSearch', $languages[0],  $languages) ?>
    </div>
    <div>
        <?php echo CHtml::label("Ordenar por","sort") ?>
         <?php echo CHtml::dropDownList('sort', $sort[0], $sort) ?>
    </div>

        <?php echo CHtml::submitButton('Buscar', array("id" => "searchAdvance")); ?>

    <?php echo CHtml::endForm(); ?>
</section>