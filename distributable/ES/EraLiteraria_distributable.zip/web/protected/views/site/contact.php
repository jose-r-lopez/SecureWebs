<?php
$this->pageTitle=Yii::app()->name . ' - Contacta con nosotros';
$this->breadcrumbs=array(
	'Contacta',
);
?>

<h2 class="fill">Contacta con nosotros</h2>

<section class="form">
    
<?php if(Yii::app()->user->hasFlash('contact')){ ?>

<div class="flash-success">
	<?php echo Yii::app()->user->getFlash('contact'); ?>
</div>

<?php }else{ ?>
    
<h3>Haznos llegar tus sugerencias y preguntas</h3>
    
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'contact-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<p>Los campos con <span>*</span> son obligatorios.</p>

	<?php echo $form->errorSummary($model); ?>

	<div>
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name'); ?>
		<?php echo $form->error($model,'name',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->textField($model,'email'); ?>
		<?php echo $form->error($model,'email',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'subject'); ?>
		<?php echo $form->textField($model,'subject',array('size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'subject',array('class'=>'formerror')); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'body'); ?>
		<?php echo $form->textArea($model,'body',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'body',array('class'=>'formerror')); ?>
	</div>
    
	<div>
		<?php echo CHtml::submitButton('Enviar'); ?>
	</div>

<?php $this->endWidget(); ?>

</div>

<?php }?>
</section>