<?php
$this->pageTitle=Yii::app()->name . ' - Sobre nosotros';
$this->breadcrumbs=array(
	'Sobre nosotros',
);
?>

<h2 class="fill">Sobre nosotros</h2>

<section class="static">
    
    <section>
        <h3>Era literaria</h3>
        <p>Bienvenido a Era Literaria, la librería en la que siempre encontrarás lo que buscas. Disponemos de una gran cantidad de títulos siempre al mejor precio.
        De momento, solo ofrecemos envíos dentro de España pero ya estamos planeando envíos a todo el mundo.</p>
    </section>
    
    <section>
        <h3>Sede de la empresa y disponibilidad</h3>
        <p>Nuestras oficinas centrales se encuentran en Oviedo, Asturias y desde allí trabajamos con lo distribuidores y editoriales para ofrecer, en la medida                 posible, disponibilidad de todos nuestros títulos.</p>
     </section>
    
    <section>
        <h3>Distribuidores y editoriales</h3>
        <p>Queremos ofrecer el mejor servicio al cliente y por ello siempre estamos dispouestos a contactar con todos los distribuidores y editoriales.</p>
    </section>
</section>
