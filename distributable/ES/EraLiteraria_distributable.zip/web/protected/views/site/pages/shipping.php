<?php

$this->pageTitle=Yii::app()->name . ' - Gastos de envío';
$this->breadcrumbs=array(
	'Gastos de envío',
);
?>
<h2 class="fill">Gastos de envío</h2>

<section class="static">
    <p>Sólo se realizan envíos a España con una tarifa por paquete de 2.99€.</p>
</section>