<?php
$this->pageTitle=Yii::app()->name . ' - Protección de datos';
$this->breadcrumbs=array(
	'Protección de datos',
);
?>
<h2 class="fill">Política de protección de datos</h2>

<section class="static">
    <p>Sus datos se incluirán en un fichero de Era literaria S.A para gestionar la relación con Ud. </p>
    <p>Ud. podrá ejercer los derechos de acceso, cancelación, rectificación, oposición, y la revocación en cualquier momento de los consentimientos prestados, mediante    carta dirigida a Era literaria S.A., Apartado de Correos XXX de Asturias o remitiendo un e-mail a XXXXX@eraliteraria.com.</p>
</section>