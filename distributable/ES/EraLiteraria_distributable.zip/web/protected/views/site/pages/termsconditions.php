<?php

$this->pageTitle=Yii::app()->name . ' - Condiciones de uso';
$this->breadcrumbs=array(
	'Condiciones de uso',
);
?>
<h2 class="fill">Condiciones de uso</h2>

<section class="static">
    <p>Estas son las condiciones de uso que regulan la utilización y el acceso a la página web que muestra el catálogo de Era literaria. La compañia pone esta web a disposción de los usuarios que aceptan sin reservas estas condiciones de uso cuando acceden a la página. Las condiciones que se exponen a contiuacuón están destinadas a mayores de edad y menores debidamente autorizados.<p>
            
    <section>
        <h3>Datos de identificación</h3>
        <p>Esta visitando la página web Era literaria (hecha para un TFM)</p>
        <p>Calle no real, 33</p>
        <p>33011 Oviedo, Asturias</p>
        <p>Telf: 985 XX XX XX</p>
        <p>CIF A-XXXXXXXX</p>
        <p>Datos mercantiles: Registro Mercantil, Tomo XX, Folio XX, Hoja XXXX, Libro X, Sección X.</p>
    </section>
    
    <section>
        <h3>Aceptación del usuario</h3>
        <p>Todos los servicios que ofrece la comparñia pueden someterse a condiciones particulares sobre las cuales se informará a los usuarios en cada caso. El usuario acepta las condiciones automáticamente en cuanto acceda a ellos.</p>
    </section>
    
    <section>
        <h3>Acceso a la web</h3>
        <p>Sólo usuarios registrados y autenticados podrán realizar compras en la web. Todos los usuarios registrados en la presente página están protegidos mediante las contraseñas elegidas por ellos mismos. El usuario se compromete a manterner en secreto su contraseña, notificando siempre a la compañia si existe un uso no consetido de la cuenta.</p>
        <p>La compañia se compromente a garantizar los datos personales de los usuario evitando su alteración, pérdida o uso no autorizado todo ello conforme con la legislación española de Protección de datos de carácter personal.</p>
        <p>El usuario se compromete a utilizar la web y sus servicios conforme con la Ley, las condiciones de uso descritas y las buenas costumbres y el order público. El usuario no debe obstaculizar el acceso a otros usuaiors mediante el consumo masivo de los servicios o debido a acciones que dañen o alteren los datos que se encuentren en la web.</p>
    </section>
    
    <section>
        <h3>Modificación de las condiciones de uso</h3>
        <p>La compañia se reserva el derecho de actualizar las presentes condiciones de uso.</p>
    </section>
    
    <section>
        <h3>Proteccion de datos</h3>
        <p>El Usuario podrá remitir a LA COMPAñíA sus datos de carácter personal a través de los distintos formularios que a tal efecto aparecen incorporados en la página web. Dichos formularios incorporan un texto legal en materia de protección de datos personales que da cumplimiento a las exigencias establecidas en la Ley Orgánica 15/1999, de 13 de diciembre, de Protección de Datos de Carácter Personal, y en su Reglamento de Desarrollo, aprobado por el Real Decreto 1720/2007, de 21 de diciembre.
Rogamos lea atentamente los textos legales antes de facilitar sus datos de carácter personal.</p>
    </section>

</section>
