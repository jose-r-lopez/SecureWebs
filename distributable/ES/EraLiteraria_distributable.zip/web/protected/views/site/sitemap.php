<?php

    $this->pageTitle=Yii::app()->name . ' - Mapa del sitio';

    $this->breadcrumbs=array(
        'Mapa del sitio',
    );
?>

<h2 class="fill">Mapa del sitio</h2>
<section id="sitemap">
<section>
    <h3>Enlaces secciones principales</h3>
    <ul>
        <li><?php echo CHtml::link('Home', Yii::app()->createUrl('/'))?></li>
        <li><?php echo CHtml::link('Novedades', Yii::app()->createUrl('book/news'))?></li>
        <li><?php echo CHtml::link('Próximamente', Yii::app()->createUrl('/book/comingsoon'))?></li>
        <li><?php echo CHtml::link('Editoriales', Yii::app()->createUrl('/book/publishers'))?></li>
        <li><?php echo CHtml::link('Sobre nosotros', Yii::app()->createUrl('/site/page/'))?></li>
        <li><?php echo CHtml::link('Búsqueda avanzada', Yii::app()->createUrl("/search/advanced"))?></li>
        <li><?php echo CHtml::link('Cesta de la compra',  Yii::app()->createUrl("/shoppingCart"))?></li>
        <li><?php echo CHtml::link('Contacta con nosotros', Yii::app()->createUrl("/site/contact"))?></li>
        <li><?php echo CHtml::link('Gastos de envío', Yii::app()->createUrl('/site/page', array('view'=>'shipping')))?></li>
        <li><?php echo CHtml::link('Condiciones de uso',Yii::app()->createUrl('/site/page', array('view'=>'termsconditions')))?></li>
        <li><?php echo CHtml::link('Política de protección de datos', Yii::app()->createUrl('/site/page', array('view'=>'privacy')))?></li>
        <li><?php echo CHtml::link('Mi cuenta (sólo usuarios registrados)', Yii::app()->createUrl("/account/"))?></li>
    </ul>
  
</section>

<section>
    <h3>Enlaces categorías principales</h3>
    <ul>
       <?php foreach($categories as $category){?>
            <li>
                <?php $urlLabel = trim($category->label);
                  $urlLabel = trim($category->label);
               
                $urlLabel = str_replace(' ', '_', $urlLabel);
                $urlLabel = str_replace(chr(46), '', $urlLabel);
                $urlLabel = str_replace(',', '', $urlLabel);
                 $url = Yii::app()->createUrl('book/categories',array('id'=>$category->category_id, 'name'=>$urlLabel));
                ?>
                <?php echo CHtml::link($category->label, $url); ?>
            </li>
       <?php }?>
    
    </ul>
</section>
</section>