<?php
/* @var $this SiteController */
/* @var $error array */

$this->pageTitle=Yii::app()->name . ' - Error';
$this->breadcrumbs=array(
	'Error',
);
?>

<?php if($code != null){ ?>
    <h2 class="fill">Error <?php echo $code; ?></h2>
<?php }else{ ?>
    <h2 class="fill">Error</h2>
<?php } ?>
<section class="error">
    <p> Ha ocurrido un error en la web.</p>
</section>