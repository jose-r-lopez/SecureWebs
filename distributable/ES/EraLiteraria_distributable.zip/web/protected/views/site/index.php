<?php
/* @var $this SiteController */
    $this->pageTitle=Yii::app()->name;

    $cs = Yii::app()->clientScript;
    $cs->registerScriptFile(Yii::app()->baseUrl . '/assets/bootstrap/bootstrap.js', CClientScript::POS_HEAD);
    $cs->registerCssFile(Yii::app()->baseUrl . '/css/bootstrap/bootstrap-carousel.css');
    Yii::app()->clientScript->registerScript('index', 
	'$(document).ready(function(){
        $("#banner").carousel( );
        
         $(".products").carousel(
           { interval: false}
        );
	});');
?>

<section>
<div id="banner" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#banner" data-slide-to="0" class="active"></li>
    <li data-target="#banner" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo Yii::app()->request->baseUrl; ?>/images/banners/banner1.png" alt="...">
    </div>
    <div class="item">
      <img src="<?php echo Yii::app()->request->baseUrl; ?>/images/banners/banner2.png" alt="...">
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#banner" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Anterior</span>
  </a>
  <a class="right carousel-control" href="#banner" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Siguiente</span>
  </a>
    
</div>

<section id="newsCaro">
    <h3>Últimas novedades</h3>
<div id="news" class="products carousel slide">
     <div class="control-box">                            
                <a data-slide="prev" href="#news" class="carousel-control left">‹</a>
                <a data-slide="next" href="#news" class="carousel-control right">›</a>
            </div> 
    
        <div class="carousel-inner">
           
            
            <div class="item active">
                    <ul class="list">
                        
                        <?php for($i = 0 ; $i < 4 ; $i++){
                            $book = $news[$i];
                        ?>
                        
                        <li>
                            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                             echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>

                            <div>
                                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                                <p class="author"><?php echo $book->author ?></p>
                                <p class="publisher"><?php echo $book->publisher ?></p>

                                <?php if($book->stock > 0){ ?>
                                    <?php $form = $this->beginWidget('CActiveForm', array(
                                        'id'=>'cart-form',
                                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                                    )); ?>
                                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                                    <?php $this->endWidget(); ?>
                                <?php } else { ?>
                                    <p class="noAva">No está disponible actualmente.</p>
                                <?php }  ?>
                                <p class="price"><?php echo $book->price ?> €</p>
                            </div>
                        </li>
                       <?php } ?>
                    </ul>
              </div> 
            <div class="item">
                    <ul class="list">
                        <?php for($i = 4 ; $i < 8 ; $i++){
                            $book = $news[$i];
                        ?>
                        
                        <li>
                            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                             echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>

                            <div>
                                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                                <p class="author"><?php echo $book->author ?></p>
                                <p class="publisher"><?php echo $book->publisher ?></p>

                                <?php if($book->stock > 0){ ?>
                                    <?php $form = $this->beginWidget('CActiveForm', array(
                                        'id'=>'cart-form',
                                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                                    )); ?>
                                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                                    <?php $this->endWidget(); ?>
                                <?php } else { ?>
                                    <p class="noAva">No está disponible actualmente.</p>
                                <?php }  ?>
                                <p class="price"><?php echo $book->price ?> €</p>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>
              </div> 
        </div>                        
    </div>
 </section> 
    
    
    <section>
    <h3>Próximamente</h3>
<div id="comingsoon" class="products carousel slide">
    
    <div class="control-box">                            
            <a data-slide="prev" href="#comingsoon" class="carousel-control left">‹</a>
            <a data-slide="next" href="#comingsoon" class="carousel-control right">›</a>
        </div> 
    
        <div class="carousel-inner">

            <div class="item active">
                    <ul class="list">
                        
                        <?php 
                            if(count($comingSoon) > 4){
                                $count = count($comingSoon)-4;
                    
                            }else{
                                $count = count($comingSoon);
                            }

                            for($i = 0 ; $i < $count ; $i++){
                            $book = $comingSoon[$i];
                        ?>
                        
                        <li>
                            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                             echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>

                            <div>
                                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                                <p class="author"><?php echo $book->author ?></p>
                                <p class="publisher"><?php echo $book->publisher ?></p>

                                <?php if($book->stock > 0){ ?>
                                    <?php $form = $this->beginWidget('CActiveForm', array(
                                        'id'=>'cart-form',
                                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                                    )); ?>
                                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                                    <?php $this->endWidget(); ?>
                                <?php } else { ?>
                                    <p class="noAva">No está disponible actualmente.</p>
                                <?php }  ?>
                                <p class="price"><?php echo $book->price ?> €</p>
                            </div>
                        </li>
                       <?php } ?>
                    </ul>
              </div> 
              <?php if(count($comingSoon) > 4){?>
            <div class="item">
                  
                    <ul class="list">
                        <?php for($i = 4 ; $i < count($comingSoon) ; $i++){
                            $book = $comingSoon[$i];
                        ?>
                        
                        <li>
                            <?php $img = CHtml::image($book->cover, "Portada del libro " . $book->name );
                             echo CHtml::link($img,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?>

                            <div>
                                <p class="title"><?php echo CHtml::link($book->name,Yii::app()->createUrl("/book/view",array("id"=>$book->isbn))) ?></p> 
                                <p class="author"><?php echo $book->author ?></p>
                                <p class="publisher"><?php echo $book->publisher ?></p>

                                <?php if($book->stock > 0){ ?>
                                    <?php $form = $this->beginWidget('CActiveForm', array(
                                        'id'=>'cart-form',
                                        'action' => Yii::app()->createUrl('/shoppingCart/add', array("id"=>$book->isbn)),
                                    )); ?>
                                        <?php echo CHtml::hiddenField('isbn' , $book->isbn); ?>
                                        <?php echo CHtml::submitButton('Añadir al Carrito'); ?>
                                    <?php $this->endWidget(); ?>
                                <?php } else { ?>
                                    <p class="noAva">No está disponible actualmente.</p>
                                <?php }  ?>
                                <p class="price"><?php echo $book->price ?> €</p>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>
              </div>
             <?php } ?>
        </div>
        
       
                              
    </div>
 </section> 
  
</section>