<?php

/**
 * Modelo Order
 * Entidad que representa un pedido.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class Order extends CActiveRecord
{
    
     /**
     * @var string $created Posible estado de un pedido
     */
    static $created = "Creado";
    
    /**
     * @var string $paid Posible estado de un pedido
     */
    static $paid = "Pagado";
    
    /**
     * @var string $error Posible estado de un pedido
     */
    static $error = "Error";
    
     /**
     * @var string $sent Posible estado de un pedido
     */
    static $sent = "Enviado";
    

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'orders';
	}
	
	
	public function primaryKey()
	{
		return 'order_id';
	}

	public function rules()
	{
		return array(
            array('order_id, email, status, totalPrice, creationTime', 'required'),
		);
	}
    
	public function relations()
	{
		return array(
            'items' => array(self::HAS_MANY, 'OrderItem', 'order_id')
		);
	}

	public function attributeLabels()
	{
		return array(
            'order_id'=>'ID',
            'email'=>'Usuario',
            'status'=>'Estado',
            'totalPrice'=>'Precio Total',
            'creationTime'=>'Fecha',
		);
	}
    
    /**
     * Obtiene la etiqueta de un estado para ser mostrado por pantalla.
     * @param string $status Estado de un pedido
     * @return string Nombre del estado.
     */
    public static function getStatusLabel($status){
        if(strcmp($status, "CREATED") === 0){
            return self::$created;
        }else if(strcmp($status, "SENT") === 0){
             return self::$sent;
        }else if(strcmp($status, "PAID") === 0){
             return self::$paid;
        }else{
             return self::$error;
        }
    }
}