<?php

/**
 * Modelo Review
 * Entidad que representa una crítica.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class Review extends CActiveRecord
{

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'reviews';
	}
	
	
	public function primaryKey()
	{
		return 'review_id';
	}

	public function rules()
	{
		return array(
            array('review_id, text, rating, email,title,isbn', 'required'),
		);
	}
    
	public function relations()
	{
		return array(
            'user' => array(self::BELONGS_TO, 'User', 'email'),
            'book' => array(self::BELONGS_TO, 'Book', 'isbn')
		);
	}

	public function attributeLabels()
	{
		return array(
            'review_id'=>'ID',
            'text'=>'Opinión del cliente',
            'rating'=>'Valoración',
            'email'=>'Escrito por',
            'title'=>'Título',
            'isbn'=>'Libro',
		);
	}
}