<?php

/**
 * Modelo UserForm
 * Encargado de gestionar el formulario que permite añadir usuarios.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class UserForm extends CFormModel
{
    /**
     * @var string $email Correo
     */
    public $email;
    
    /**
     * @var string $username Nombre de usuario
     */
    public $username;
    
    /**
     * @var string $password Contraseña
     */
    public $password;
    
    /**
     * @var string $repeatPass Repetición de la contraseña
     */
	public $repeatPass;
    
    /**
     * @var bool $isAdmin Indicador de si el usuario es administrador
     */
    public $isAdmin;

    /**
     * @var UserIdentity $_identity Objeto que controla si un usuario puede autenticarse en el sistema.
     */
	private $_identity;
    
    /**
     * @var PersistenceFacade facade Fachada para acceder a la capa de persistencia
     */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}

    
	public function rules()
	{
		return array(
			array('username, password,email,repeatPass', 'required','message'=>'El campo no puede estar vacío.'),
            array('email','email','message'=>'No se ha introducido un email correcto.'),
            array('repeatPass', 'compare', 'compareAttribute'=>'password','message'=>'Contraseña y Repetir contraseña deben coincidir'),
            array('password','ext.validators.EPasswordStrength', 'min'=>7,'message' =>'La contraseña debe de tener al menos una mayúscula, una minúscula y un número. Debe tener como mínimo 7 caracteres.'),
            array('username', 'checkNameLength','message'=>'El campo no tiene una longitud correcta.'),
            array('email', 'checkEmailLength','message'=>'El campo no tiene una longitud correcta.'),
            array('isAdmin', 'numerical', 'integerOnly'=>true),
		);
	}

	public function attributeLabels()
	{
		return array(
			'email'=>'Correo electrónico',
            'password'=>'Contraseña',
            'repeatPass'=>'Repetir Contraseña',
            'username'=>'Nombre de usuario',
            'isAdmin'=>'Rol de administrador',
		);
	}
    
    
    /**
     * Comprueba la longitud del nombre. Si no es correcto añade un error al formulario.
     */
    public function checkNameLength(){
        if( strlen($this->username) > 99){
             $this->addError('username','El nombre completo es demasiado largo');
        }  
    }
    
    
     /**
     * Comprueba la longitud del correo.Si no es correcto añade un error al formulario.
     */
     public function checkEmailLength(){
        if( strlen($this->email) > 99){
             $this->addError('email','El correo introducido es demasiado largo');
        }  
    }

    
    /**
     * Añade un usuario
     * 
     * @return True si se ha añadido, false en caso contrario.
     */
	public function addUser()
	{
        try{

            $user = $this->facade->getUser($this->email);
                
            if($user){
                return false;
            }
        
            $newUser = new User();
            if($this->isAdmin == 1){
                $newUser->addAdmin($this->username, $this->email, $this->password);
            }else
                $newUser->addUser($this->username, $this->email, $this->password);
        }catch(Exception $e){
            return false;
        }
        
        return true;
	}
}
