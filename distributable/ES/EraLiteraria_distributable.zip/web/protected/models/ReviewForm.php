<?php

/**
 * Modelo ReviewForm
 * Encargado de gestionar el formulario que permite añadir críticas.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class ReviewForm extends CFormModel
{
    /**
     * @var string $text Texto
     */
    public $text;
    
    /**
     * @var double $rating Valoración
     */
    public $rating;
    
    /**
     * @var string $title Título
     */
    public $title;
    
    /**
    * @var PersistenceFacade $facade Fachada para acceder a la capa de persistencia
    */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}
    
	public function rules()
	{
		return array(
			 array('text, rating, title', 'required','message'=>'El campo es obligatorio.'),
		);
	}

	public function attributeLabels()
	{
		return array(
            'text'=>'Texto',
            'rating'=>'Valoración',
            'title'=>'Título',
		);
	}

     /**
     * Crea una crítica.
     * @param string $isbn ISBN del libro
     * @return True si se ha creado correctamente,false en caso contrario.
     */
	public function createReview($isbn)
	{
        
        if($this->facade->getReviewByParams(Yii::app()->user->id, $isbn) == null){
            $reviews = $this->facade->getReviewsByIsbn($isbn);
           
            $this->facade->insertReview($this->text,$this->rating,Yii::app()->user->id, $this->title ,$isbn);
            $newRating = 0;
            $numberOfRatings =0;
            
            if(count($reviews) != 0){
                $numberOfRatings = count($reviews);
                foreach($reviews as $review){
                    $newRating += $review->rating;
                }
            }
            $numberOfRatings +=  1;    
            $newRating += $this->rating;
            $this->facade->updateRating($isbn, $newRating/$numberOfRatings);
            

            return true;
        }
        
        Yii::app()->session["error"] = "Ya ha realizado su opinión sobre este artículo";
        return false;
	}
    
}