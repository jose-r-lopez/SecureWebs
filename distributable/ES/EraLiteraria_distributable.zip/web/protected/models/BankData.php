<?php

/**
 * Modelo BankData
 * Contiene los datos necesarios para conectarse a la pasarela de pago.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class BankData 
{
     /**
     * @var string $MERCHANT_ID Id del comerciante
     */
    public static $MERCHANT_ID = "0";
    
    /**
     * @var string $ACQUIRER_BIN Id 
     */
    public static $ACQUIRER_BIN = "0";
    
     /**
     * @var string $ACQUIRER_BIN Id del terminal
     */
    public static $TERMINAL_ID = "00000003";
    
     /**
     * @var string $ENCRIPTATION_KEY Clave para encriptar 
     */
    public static $ENCRIPTATION_KEY = "0";
    
     /**
     * @var string $MONEY_TYPE Tipo de moneda
     */
    public static $MONEY_TYPE = "978";
    
    /**
     * @var string $EXPONENT Exponente que se usara en el precio
     */
    public static $EXPONENT = "2";
    
      /**
     * @var string $URL_OK Url a la que se redirigirá si no hay errores
     */
    public static $URL_OK;
    
      /**
     * @var string $URL_ERROR Url a la que se redirigirá si ocurre un error
     */
    public static $URL_ERROR;
    
     /**
     * Cambia la url que se usará si no hay errores.
     * @param string $urlOK URL
     */
    public static function setURLOK($urlOK){
        self::$URL_OK = $urlOK;
    }
    
     /**
     * Cambia la url que se usará si hay errores.
     * @param string $urlError URL
     */
    public static function setURLError($urlError){
        self::$URL_ERROR = $urlError;
    }
}