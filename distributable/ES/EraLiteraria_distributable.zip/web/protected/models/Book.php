<?php

/**
 * Modelo Book
 * Entidad que representa un libro
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class Book extends CActiveRecord
{
    
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'books';
	}
	
	
	public function primaryKey()
	{
		return 'isbn';
	}

	public function rules()
	{
		return array(
            array('isbn, name, author, publisher, price, stock, cover, pages, year, description, format, language', 'required'),
		);
	}


	public function relations()
	{
		return array(
            'category' => array(self::BELONGS_TO, 'Category', 'category_id'),
		);
	}

	public function attributeLabels()
	{
		return array(
            'isbn'=>'ISBN',
            'name'=>'Nombre',
            'author'=>'Autor',
            'publisher'=>'Editorial',
            'price'=>'Precio',
            'stock'=>'Stock',
            'cover'=>'Portada',
            'year'=>'Año',
            'format'=>'Formato',
            'language'=>'Lenguaje',
            'category_id'=>'Categoría',
		);
	}
}