<?php

/**
 * Modelo ShoppingCartItem
 * Entidad que representa un item en la cesta de la compra.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class ShoppingCartItem 
{
    /**
     * @var int $units Unidades del producto
     */
	private $units;
    
      /**
     * @var Book $product Producto dentro de la cesta
     */
    private $product;
    
    /**
     * Constructor
     * @param int $units Unidades
     * @param Book $item Libro
     */
    public function ShoppingCartItem($units,$item){
        $this->units = $units;
        $this->product = $item;
    }
    
    /**
     * Cambia las unidades del producto
     * @param int $units Unidades
     */
    public function setUnits($units){
        $this->units = $units;
    }
    
    /**
     * Obtiene las unidades del producto
     * @return int Unidades
     */
    public function getUnits(){
        return $this->units;
    }
    
    /**
     * Obtiene el producto
     * @return Book Libro
     */
    public function getProduct(){
        return $this->product;
    }
}