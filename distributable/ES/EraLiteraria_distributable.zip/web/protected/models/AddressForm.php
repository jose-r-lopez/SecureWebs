<?php

/**
 * Modelo AddressForm
 * Encargado de gestionar el formulario que permite añadir direcciones de envío.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class AddressForm extends CFormModel
{
    /**
     * @var string $address Dirección
     */
	public $address;
    
    /**
     * @var string $postCode Código postal
     */
	public $postCode;
    
    /**
     * @var string $city Ciudad
     */
    public $city;
    
    /**
     * @var string $province Provincia
     */
    public $province;
    
    /**
     * @var list<string> $provinces Lista de provincias disponibles
     */
    public static $provinces = array('Álava','Albacete','Alicante','Almería','Asturias','Ávila','Badajoz','Barcelona','Burgos','Cáceres','Cádiz',
'Cantabria','Castellón','Ceuta','Ciudad Real','Córdoba','Cuenca','Gipuzkoa','Girona','Granada','Guadalajara','Huelva','Huesca','Islas Baleares','Jaén',
'La Coruña','La Rioja','Las Palmas','León','Lleida','Lugo','Madrid','Málaga','Melilla','Murcia','Navarra','Ourense','Palencia','Pontevedra','Salamanca',
'Santa Cruz de Tenerife','Segovia','Sevilla','Soria','Tarragona','Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza');

     /**
     * @var PersistenceFacade facade Fachada para acceder a la capa de persistencia
     */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}
    
	public function rules()
	{
		return array(
			array('address, postCode,city,province', 'required','message'=>'El campo no puede estar vacío.'),
            array('postCode', 'checkPostCodeLength'),
		);
	}


	public function attributeLabels()
	{
		return array(
			'address'=>'Dirección de envío',
            'postCode'=>'Código postal',
            'city'=>'Ciudad',
            'province'=>'Provincia',
		);
	}
    
    
     /**
     * Comprueba que el código postal tenga la longitud apropiada.
     */
    public function checkPostCodeLength(){
        if( strlen($this->postCode) != 5){
             $this->addError('postCode','El código postal es incorrecto.');
        }  
    }

     /**
     * Guarda la dirección
     * 
     * @return True si la dirección se guarda correctamente.
     */
	public function saveAddress()
	{
        
        if(!$this->facade->getAddress(Yii::app()->user->id)){
            $this->facade->insertAddress(Yii::app()->user->id,$this->address,$this->postCode,$this->city,$this->province);
        }else{
             $this->facade->updateAddress(Yii::app()->user->id,$this->address,$this->postCode,$this->city,$this->province);
        }
        
        return true;
	}
    
    /**
     * Obtiene todas las provincias
     * 
     * @return List<string> lista de provincias
     */
    public static function getProvinces() {
        return self::$provinces;
    }
}
