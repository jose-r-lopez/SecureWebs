<?php

/**
 * Modelo User
 * Entidad que representa un usuario.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class User extends CActiveRecord
{
     /**
     * @var PersistenceFacade $facade Fachada para acceder a la capa de persistencia
     */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}


	public function tableName()
	{
		return 'users';
	}

	public function rules()
	{
		return array(
			array('email, name, pass, salt', 'required'),
			array('email, name', 'length', 'max'=>99),
		);
	}

	public function relations()
	{
		return array(
		);
	}

	/**
     * Añade un usuario normal
     * @param string $name Nombre
     * @param string $email Correo
     * @param string $pass Contraseña
     */
	public function addUser($name, $email, $pass){
		//Generamos un salt aleatorio para el usuario
		$salt = bin2hex(mcrypt_create_iv(32, MCRYPT_RAND));
		$saltedPW =  $pass . $salt;
		$hashedPW = hash('sha256', $saltedPW);
       
        $this->facade->insertUser($name,$email,$hashedPW,$salt);
	}
    
    /**
     * Añade un usuario administrador
     * @param string $name Nombre
     * @param string $email Correo
     * @param string $pass Contraseña
     */
    public function addAdmin($name, $email, $pass){
		//Generamos un salt aleatorio para el usuario
		$salt = bin2hex(mcrypt_create_iv(32, MCRYPT_RAND));
		$saltedPW =  $pass . $salt;
		$hashedPW = hash('sha256', $saltedPW);
         
        $this->facade->insertAdmin($name,$email,$hashedPW,$salt);
	}
    
    /**
     * Actualiza un usuario.
     * @param string $name Nombre del usuario
     * @param string $pass Contraseña
     */
    public function updateUser($name, $pass){
        $salt = bin2hex(mcrypt_create_iv(32, MCRYPT_RAND));
		$saltedPW =  $pass . $salt;
		$hashedPW = hash('sha256', $saltedPW);
             
        $this->facade->updateUser($name,$hashedPW,$salt);
    }
    
    /**
     * Comprueba si la contaseña corresponde a un usuario
     * @param string $password Contraseña
     * @return True si corresponde, false en caso contrario o en caso de error.
     */
    public static function checkPassword($password){
        $authorizer=Yii::app()->authManager;
        $facade = new PersistenceFacade();
        $user =  $facade->getUser(Yii::app()->user->id);
        
        if($user == null){
            return false;
        }else{
            //se comprueba la contraseña
            $saltedPW =  $password . $user->salt;
            $hashedPW = hash('sha256', $saltedPW);
            if(strcmp($user->pass, $hashedPW) === 0) {
                return true;
            }else{				
                return false;
            }
        }   
    }

}