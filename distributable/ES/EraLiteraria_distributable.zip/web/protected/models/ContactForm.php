<?php

/**
 * Modelo ContactForm
 * Encargado de gestionar el formulario de contacto.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class ContactForm extends CFormModel
{
      /**
     * @var string $name Nombre del usuario
     */
	public $name;
    
      /**
     * @var string $email Correo del usuario
     */
	public $email;
    
      /**
     * @var string $subject Asunto
     */
	public $subject;
    
      /**
     * @var string $body Cuerpo
     */
	public $body;
	//public $verifyCode;

	public function rules()
	{
		return array(
			array('name, email, subject, body', 'required','message' => 'El campo es obligatorio'),
			array('email', 'email','message' => 'No se ha introducido un email correcto.'),
			// verifyCode needs to be entered correctly
			//array('verifyCode', 'captcha', 'allowEmpty'=>!CCaptcha::checkRequirements()),
		);
	}

	public function attributeLabels()
	{
		return array(
            'name'=>'Nombre del usuario',
            'email'=>'Correo del usuario',
            'subject'=>'Asunto',
            'body'=>'Cuerpo',
			//'verifyCode'=>'Verification Code',
		);
	}
}