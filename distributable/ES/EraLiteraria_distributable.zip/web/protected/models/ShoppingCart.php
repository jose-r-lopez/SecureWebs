<?php

/**
 * Modelo ShoppingCart
 * Entidad que representa la cesta de la compra
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class ShoppingCart 
{
    /**
     * @var double $totalPrice Precio total
     */
	private $totalPrice = 0;
    
    /**
     * @var int $numberOfItems Número de productos en la cesta
     */
    private $numberOfItems= 0;
    
    /**
     * @var list<ShoppingCartItem> $items Lista de productos
     */
    private $items = array();
    
    /**
     * @var double $shipping Precio gastos de envío
     */
    public static $shipping = 2.99;
    
    
    /**
     * @var string $orderID Id del pedido asociado
     */
    private $orderID = null;
    
    /**
     * Obtiene el id del pedido asociado. 
     * 
     * @return string Id del pedido
     */
    public function getOrderID(){
        return $this->orderID;
    }
    
    /**
     * Cambia el id del pedido asociado.
     * @param string $id Id del pedido
     */
    public function setOrderID($id){
       $this->orderID = $id;
    }
    
    /**
     * Añade un producto a la cesta
     * @param Book $product Libro
     * @param int $units Unidades
     */
    public function addToShoppingCart($product, $units=1){
        $this->numberOfItems += $units;
        $this->totalPrice += ($product->price * $units);
        
        $cartItem = new ShoppingCartItem($units,$product);
        $this->items[$product->isbn] = $cartItem;
    }
    
    /**
     * Actualiza un item de la cesta de la compra.
     * @param Book $product Libro
     * @param int $units Unidades 
     */
    public function updateShoppingCart($product, $units){
        
        $cartItem = $this->items[$product->isbn];
        $this->numberOfItems -= $cartItem->getUnits();
        $this->totalPrice -= ($product->price * $cartItem->getUnits());
        
        $this->numberOfItems += $units;
        $this->totalPrice += ($product->price * $units);
        
        $cartItem->setUnits($units);
    }
    
      /**
     * Añade una unidad a un producto ya existente.
     * @param Book $product Libro
     */
    public function addOneMore($product){
        $cartItem = $this->items[$product->isbn];
        $this->numberOfItems++;
        $this->totalPrice += $product->price;
        
        $units = $cartItem->getUnits() + 1;            
        $cartItem->setUnits($units);
    }
    
    /**
     * Borra un elemento del carrito
     * @param string $id IDentificador del libro
     */
    public function removeItemShoppingCart($id){
        $cartItem = $this->items[$id];
        $product = $cartItem->getProduct();
        $units = $cartItem->getUnits(); 
        
        $this->totalPrice -= ($product->price * $units);
        $this->numberOfItems -= $units;
        
        unset($this->items[$id]);
    }
   
      /**
     * Obtiene el precio total de la cesta (sin gastos de envío).
     * 
     * @return double Precio total
     */
    public function getTotalPrice(){
        return $this->totalPrice;
    }
    
      /**
     * Obtiene los gastos de envío.
     * 
     * @return double Gastos de envío.
     */
    public static function getShipping(){
        return self::$shipping;
    }
    
   /**
    * Obtiene el precio total incluyendo los gastos de envío.
    * 
    * @return double Precio total
    */
    public function getTotalPriceWithShipping(){
        return $this->totalPrice + self::$shipping;
    }
    
      /**
     * Obtiene el número total de items.
     * 
     * @return int Número de items
     */
    public function getNumberOfItems(){
        return $this->numberOfItems;
    }
    
      /**
     * Obtiene el número total de items.
     * 
     *  @return int Número de items
     */
    public function getItemsCount(){
        return count($this->items);
    }
    
      /**
     * Indica si existe un producto en la cesta.
     * @param string $id Identificador del libro
     * @return True si existe, false en caso contrario
     */
    public function existsItem($id){
      return array_key_exists ($id ,$this->items);
    }
    
      /**
     * Obtiene un elemento de la cesta.
     * @param string $id Identificador del libro 
     * @return ShoppingCartItem Elemento de la cesta.
     */
    public function getItem($id){
       if(array_key_exists ($id ,$this->items))
            return $this->items[$id];
        else
            return null;
    }
    
      /**
     * Obtiene un libro de la cesta
     * @param string $id Identificador del libro  
     * @return Book libro
     */
    public function getProduct($id){
     if(array_key_exists ($id ,$this->items)){
            $item = $this->items[$id];
            return $item->getProduct();
     }else
            return null;
    }
    
      /**
     * Obtiene todos los items
     * 
     * @return List<ShoppingCartItem> Lista de todos los elementos.
     */
    public function getItems(){
        return $this->items;
    }
}