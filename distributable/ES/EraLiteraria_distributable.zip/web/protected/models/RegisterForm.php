<?php

/**
 * Modelo RegisterForm
 * Encargado de gestionar el formulario que permite el registro de usuarios.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class RegisterForm extends CFormModel
{
    /**
     * @var string $email Correo
     */
	public $email;
    
    /**
     * @var string $username Nombre de usuario
     */
    public $username;
    
    /**
     * @var string $password Contraseña
     */
    public $password;
    
    /**
     * @var string $repeatPass Repetición de la contraseña
     */
	public $repeatPass;

    /**
     * @var UserIdentity $_identity Objeto que controla si un usuario puede autenticarse en el sistema.
     */
	private $_identity;
    
    /**
     * @var PersistenceFacade $facade Fachada para acceder a la capa de persistencia
     */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}
    
	public function rules()
	{
		return array(
			array('username, password,email,repeatPass', 'required','message'=>'El campo es obligatorio.'),
            array('email','email','message'=>'No se ha introducido un email correcto.'),
            array('repeatPass', 'compare', 'compareAttribute'=>'password','message'=>'Contraseña y Repetir contraseña deben coincidir'),
            array('username', 'checkNameLength','message'=>'El nombre de usuario es muy largo.'),
            array('email', 'checkEmailLength','message'=>'El correo es muy largo.'),
		);
	}

	public function attributeLabels()
	{
		return array(
			'email'=>'Correo electrónico',
            'password'=>'Contraseña',
            'repeatPass'=>'Repetir Contraseña',
            'username'=>'Nombre de usuario',
		);
	}
    
    /**
     * Comprueba que el nombre de usuario tenga una longitud correcta. Si no lo es se añade un error al formulario.
     */
    public function checkNameLength(){
        if( strlen($this->username) > 99){
             $this->addError('username','El nombre completo es demasiado largo');
        }  
    }
    
    /**
     * Comprueba que el correo tenga una longitud correcta. Si no lo es se añade un error al formulario.
     */
     public function checkEmailLength(){
        if( strlen($this->email) > 99){
             $this->addError('email','El correo introducido es demasiado largo');
        }  
    }

    /**
     * Registra un usuario.
     * 
     * @return True si se ha registrador correctamente, false en caso contrario.
     */
	public function register()
	{
        try{
            $user = $this->facade->getUser($this->email);
                
            if($user){
                Yii::app()->session["registerError"] = "Ese usuario ya está registrado";
                return false;
            }
        
            $newUser = new User();
            $newUser->addUser($this->username, $this->email, $this->password);
        }catch(Exception $e){
            Yii::app()->session["registerError"] = $e->getMessage();
            return false;
        }
        
        return true;
	}
}
