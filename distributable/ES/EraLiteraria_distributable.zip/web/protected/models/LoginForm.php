<?php

/**
 * Modelo LoginForm
 * Encargado de gestionar el formulario que permite el inicio de sesión.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class LoginForm extends CFormModel
{
    /**
     * @var string $username Correo
     */
	public $username;
    
    /**
     * @var string $password Contraseña
     */
	public $password;

    /**
     * @var UserIdentity $_identity Objeto que controla si un usuario puede autenticarse en el sistema.
     */
	private $_identity;


	public function rules()
	{
		return array(
			array('username, password', 'required','message'=>'El campo es obligatorio.'),
		);
	}


	public function attributeLabels()
	{
		return array(
			'username'=>'Correo electrónico',
            'password'=>'Contraseña',
		);
	}

    /**
     * Inicia sesión.
     * 
     * @return True si se inicia sesión correctamente, false en caso contrario.
     */
	public function login()
	{
		if($this->_identity === null)
		{
            $this->_identity = new UserIdentity($this->username,$this->password);
            
            if(!$this->_identity->checkUser()){
                Yii::app()->session["loginError"] = "Usuario incorrecto";
                return false;
            }else{
               
                if(!$this->_identity->authenticate()){
                    Yii::app()->session["loginError"] = "Contraseña incorrecta";
                    return false;
                }
            }
		}
        
       
        
		if($this->_identity->errorCode === UserIdentity::ERROR_NONE)
		{
            $duration = 0;
			//Yii::app()->user->userLogin($this->_identity,$duration); //session fixation
            Yii::app()->user->login($this->_identity,$duration);
			return true;
		}
		else
			return false;
	}
    
   
}
