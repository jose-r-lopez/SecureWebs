<?php

/**
 * Modelo CategoryForm
 * Encargado de gestionar el formulario que permite añadir o editar categorías.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class CategoryForm extends CFormModel
{
    
    /**
     * @var string $label Etiqueta
     */
	public $label;
    
    /**
     * @var string $parentCategory Id de la categoría padre
     */
    public $parentCategory;
    
    /**
     * @var string $categoryID Id de la categoría
     */
    public $categoryID;
    
    /**
    * @var PersistenceFacade facade Fachada para acceder a la capa de persistencia
    */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}
    
	public function rules()
	{
		return array(
			array('label, parentCategory', 'required','message' => 'El campo es obligatorio.'),
		);
	}
    
	public function attributeLabels()
	{
		return array(
			'label'=>'Etiqueta',
            'parentCategory'=>'Categoría padre',
            'categoryID'=>'ID',
		);
	}

    /**
     * Crea una categoría
     * 
     * @return True si se a creado la categoría,false en caso de error.
     */
	public function createCategory()
	{
        //que exista el id de la categoria
        if($this->existsParentCategory($this->parentCategory)){
           $category = new Category();
           $category->label = $this->label;
           $category->parent_id = $this->parentCategory;

           $this->facade->saveCategory($category);
           return true;
        }
        
        return false;
	}
    
    /**
     * Edita una categoría
     * 
     * @return True si se ha editado la categoría, false en caso de error.
     */
    public function editCategory(){
        //que exista el id de la categoria
       if($this->existsParentCategory($this->parentCategory) && $this->existsCategory($this->categoryID)){
            $this->facade->updateCategory($this->label, $this->parentCategory, $this->categoryID);
           return true;
        }
        
        return false;
    }
    
    /**
     * Comprueba si una categoría tiene padre.
     * @param string $id Identificador de la categoría  
     * @return True si tiene, false en caso contrario.
     */
    public function existsParentCategory($id){
        $category = $this->facade->getCategory($id);
        if($category != null && $category->parent_id == null){
            return true;
        }else 
            return false;
    }
    
    /**
     * Comprueba que existe una categoría.
     * @param string $id Identificador de la categoría 
     * @return True si existe, false en caso contrario.
     */
     public function existsCategory($id){
        $category = $this->facade->getCategory($id);
        if($category == null){
            return false;
        }else
            return true;
    }
}
