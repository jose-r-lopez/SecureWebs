<?php

/**
 * Modelo OrderItem
 * Entidad que representa un item en un pedido.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class OrderItem extends CActiveRecord
{

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'orderItems';
	}
	
	
	public function primaryKey()
	{
		return array('order_id','isbn');
	}

	public function rules()
	{
		return array(
            array('order_id,isbn,units,totalPrice', 'required'),
		);
	}

	public function relations()
	{
		return array(
            'order' => array(self::BELONGS_TO, 'Order', 'order_id'),
            'book' => array(self::BELONGS_TO, 'Book', 'isbn'),
		);
	}

	public function attributeLabels()
	{
		return array(
            
		);
	}
    
     /**
     * Obtiene los datos de un libro
     * @return Book Libro.
     */
    public function getBookData(){
        $facade = new PersistenceFacade();
        return $facade->getBook($this->isbn);
    }
}