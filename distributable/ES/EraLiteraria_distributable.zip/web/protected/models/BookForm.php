<?php

/**
 * Modelo BookForm
 * Encargado de gestionar el formulario que permite añadir libros.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class BookForm extends CFormModel
{
    /**
     * @var string $isbn ISBN del libro
     */
	public $isbn;
    
    /**
     * @var string $name Nombre
     */
    public $name;
    
    /**
     * @var string $author Autor
     */
    public $author;
    
    /**
     * @var string $publisher Editorial
     */
    public $publisher;
    
    /**
     * @var double $price Precio
     */
    public $price;
    
    /**
     * @var int $stock Stock
     */
    public $stock;
    
    /**
     * @var string $cover URL de la portada
     */
    public $cover;
    
    /**
     * @var int $pages Número de páginas
     */
    public $pages;
    
    /**
     * @var int $year Año
     */
    public $year;
    
    /**
     * @var string $description Descripción
     */
    public $description;
    
    /**
     * @var string $format Formato
     */
    public $format;
    
    /**
     * @var string $language Lenguaje
     */
    public $language;
    
    /**
     * @var string $category_id Identificador de la categoría
     */
    public $category_id;
    
    /**
     * @var date $upload_Date Fecha de subida
     */
    public $upload_Date;
    
    /**
    * @var PersistenceFacade facade Fachada para acceder a la capa de persistencia
    */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}
    
	public function rules()
	{
		return array(
			 array('isbn, name, author, publisher, price, stock, cover, pages, year, description, format, language,category_id', 'required','message' => 'El campo es obligatorio'),
            array('isbn', 'length', 'min'=>12, 'max'=>12, 'message'=>'El isbn debe tener 13 caracteres.'),
            array('stock, pages, year', 'numerical', 'integerOnly'=>true, 'message'=>'Debe ser un número.'),
            array('price', 'numerical', 'message'=>'Debe ser un número.'),
		);
	}
    
	public function attributeLabels()
	{
		return array(
			'isbn'=>'ISBN',
            'name'=>'Nombre',
            'author'=>'Autor',
            'publisher'=>'Editorial',
            'price'=>'Precio',
            'stock'=>'Stock',
            'cover'=>'Portada',
            'year'=>'Año',
            'format'=>'Formato',
            'language'=>'Lenguaje',
            'description'=>'Descripción',
            'pages'=>'Páginas',
            'category_id'=>'Categoría',
		);
	}

    /**
     * Crea un libro
     * 
     * @return True si el libro se ha creado correctamente, false en caso contrario.
     */
	public function createBook()
	{
       
        if(!$this->existsBook($this->isbn) && $this->existsCategory($this->category_id)){
            $book = new Book();
            $book->isbn = $this->isbn;
            $book->name = $this->name;
            $book->author = $this->author;
            $book->publisher = $this->publisher;
            $book->price = $this->price;
            $book->stock = $this->stock;
            $book->cover = $this->cover;
            $book->pages = $this->pages;
            $book->year = $this->year;
            $book->description = $this->description;
            $book->format = $this->format;
            $book->language = $this->language;
            $book->category_id = $this->category_id;
            $book->upload_Date = date("Y-m-d H:i:s");
            $this->facade->saveBook($book);
            return true;
        }else
            return false;

	}
    
    /**
     * Edita un libro
     * 
     * @return True si el libro se ha editado correctamente,false en caso contrario.
     */
    public function editBook(){
        if($this->existsBook($this->isbn) && $this->existsCategory($this->category_id)){
            $this->facade->updateBook($this->isbn,$this->name,$this->author,$this->publisher,$this->price, $this->cover, $this->stock, $this->pages, $this->year, $this->description, $this->format, $this->language, $this->category_id);
            return true;
        }else
            return false;

    }
    
    /**
     * Comprueba si existe una categoría
     * @param string $id Identificador de la categoría
     * @return True si existe, false en caso contrario.
     */
     public function existsCategory($id){
        $category = $this->facade->getCategory($id);
        if($category == null){
            return false;
        }else
            return true;
    }
    
     /**
     * Comprueba si existe un libro
     * @param string $id Identificador del libro
     * @return True si existe, false en caso contrario.
     */
    public function existsBook($id){
        $book = $this->facade->getBook($id);
        if($book == null){
            return false;
        }else
            return true;
    }
}
