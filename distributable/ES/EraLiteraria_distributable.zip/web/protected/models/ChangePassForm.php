<?php

/**
 * Modelo ChangePassForm
 * Encargado de gestionar el formulario que permite cambiar de contraseña.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class ChangePassForm extends CFormModel
{
    /**
     * @var string $oldPassword Contraseña anterior
     */
	public $oldPassword;
    
    /**
     * @var string $newPassword Contraseña nueva
     */
    public $newPassword;
    
    /**
     * @var string $repeatNewPass Repetición de la nueva contraseña
     */
    public $repeatNewPass;

    /**
     * @var UserIdentity $_identity Objeto que controla si un usuario puede autenticarse en el sistema.
     */
	private $_identity;
    
    /**
     * @var PersistenceFacade $facade Fachada para acceder a la capa de persistencia
     */
    private $facade;

    public function init()
	{
        $this->facade = new PersistenceFacade();
	}


	public function rules()
	{
		return array(
			array('oldPassword, newPassword,repeatNewPass', 'required','message' => 'El campo es obligatorio.'),
            array('repeatNewPass', 'compare', 'compareAttribute'=>'newPassword','message'=>'Los campos Contraseña nueva y Repetir contraseña deben coincidir'),
            array('oldPassword', 'checkOldPassword','message' => 'Ha ocurrido un error al cambiar la contraseña')
		);
	}
 
	public function attributeLabels()
	{
		return array(
			'oldPassword'=>'Contraseña anterior',
            'newPassword'=>'Contraseña nueva',
            'repeatNewPass'=>'Repetir Contraseña',
		);
	}
    
    /**
     * Comprueba si la contraseña anterior introducida coincide con la guardada en el sistema.
     * Si no coincide se añade un error al formulario.
     */
    public function checkOldPassword(){
        if(!User::checkPassword($this->oldPassword)){
             $this->addError('oldPassword','Ha ocurrido un error al cambiar la contraseña.');
        }  
    }
    

    /**
     * Cambia la contraseña
     * 
     * @return True si se cambia correctamente, false en caso contrario.
     */
	public function changePassword()
	{
        try{
            $user = $this->facade->getUser(Yii::app()->user->id);
                
            if(!$user){
                return false;
            }
        
            $user->updateUser(Yii::app()->user->id, $this->newPassword);
        }catch(Exception $e){
            return false;
        }
        
        return true;
	}
}
