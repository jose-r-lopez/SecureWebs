<?php

/**
 * Modelo Category
 * Entidad que representa una categoría.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.model
 */
class Category extends CActiveRecord
{

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}


	public function tableName()
	{
		return 'categories';
	}
	
	
	public function primaryKey()
	{
		return 'category_id';
	}


	public function rules()
	{
		return array(
            array('label, parent_id', 'required'),
		);
	}


	public function relations()
	{
		return array(
             'books' => array(self::HAS_MANY, 'Book', 'isbn')
		);
	}

	public function attributeLabels()
	{
		return array(
            'category_id' => 'Categoría',
			'parent_id' => 'Categoría padre',
            'label' => 'Etiqueta',
		);
	}
    
	public function search()
	{
		$criteria=new CDbCriteria;

		$criteria->compare('category_id',$this->categoria,true);
		$criteria->compare('parent_id',$this->parent_id,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
    
    
    /**
     * Obtiene la etiqueta de la categoría padre.
     * @return string La etiqueta de la categoría padre.
     */
    public function getParentLabel(){
        $facade = new PersistenceFacade();
        return $facade->getParentLabel($this->category_id);
    }
}