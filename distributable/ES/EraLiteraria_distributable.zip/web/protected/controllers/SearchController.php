<?php

/**
 * Controlador SearchController
 * Encargado de las peticiones del usuario relacionadas con la búsqueda de datos en la aplicación.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class SearchController extends Controller
{
     /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column2';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
     /**
     * @var categoryMenu Listado de categorías a mostrar
     */
    public $categoryMenu;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }


    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('index','advanced','advancedResults','publisher',),
                'users' => array('*'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Muestra los resultados de una consulta básica.
     * @param string $param Palabra o palabras que se deben usar en la búsqueda.
     * @return Vista results con los resultados de la búsqueda.
     */
	public function actionIndex($param = null)
	{
        $books = null;
            
        if(isset($param))
            $books = $this->facade->searchBook($param);

        $this->render("results", array("books" => $books, "text" => $param));
    }
    
    /**
     * Muestra el formulario que permite la búsqueda avanzada.
     *
     * @return Vista advanced con el formulario.
     */
    public function actionAdvanced(){
 
        $formats = $this->facade->getFormats();
        $languages = $this->facade->getLanguages();
        
        $sort = array("0" => "Precio: De más caro a más barato", "1" =>"Precio: De mas barato a más caro", "2" =>"Año de publicación: De más antiguo a más nuevo", "3" => "Año de publicación: De más nuevo a más antiguo");
        
        $this->render("advanced", array("formats" => $formats, "languages" => $languages, "sort" => $sort));
    }
    
    /**
     * Muestra los resultados de una consulta compleja.
     *
     * @return Vista results con los resultados de la búsqueda.
     */
     public function actionAdvancedResults(){
     
        $formats = $this->facade->getFormats();
        $languages = $this->facade->getLanguages();
         
     if(isset($_POST["isbnSearch"]) || isset($_POST["authorSearch"]) || isset($_POST["titleSearch"])  ||isset($_POST["publisherSearch"])  ||    isset($_POST["formatSearch"])  || isset($_POST["languageSearch"])  || isset($_POST["sort"] )){
            
            if(isset($_POST["formatSearch"]) && $_POST["formatSearch"] > 0)
                $format = $formats[$_POST["formatSearch"]];
            else
                $format = null;
            
            if(isset($_POST["languageSearch"]) && $_POST["languageSearch"] > 0)
                $languaje = $languages[$_POST["languageSearch"]];
            else
                $languaje = null;
            
        
            $books = $this->facade->advancedSearchBook($_POST["isbnSearch"], $_POST["authorSearch"], $_POST["titleSearch"], $_POST["publisherSearch"], $format , $languaje, $_POST["sort"]);
            $this->render("results", array("books" => $books, "text" => "búsqueda por varios criterios"));
        }
     }
    
     /**
     * Busca los libros de una editorial por su nombre.
     * @param string $id Nombre de la editorial
     * @return Vista publisher que muestra los libros de una editorial
     */
    public function actionPublisher($id){
        $id = str_replace('_', ' ', $id);
        $books = $this->facade->searchPublisher($id);
        $this->render("publisher", array("books" => $books, "id" =>  $id));
    }
    
}