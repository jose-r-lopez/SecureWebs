<?php

/**
 * Controlador OrderController
 * Encargado de las peticiones del usuario relacionadas con sus pedidos.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class OrderController extends Controller
{
    /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column1';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('address','payment','success','error','userorders'),
                'users' => array('@'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Permite establecer o cambiar la dirección de envío.
     * 
     * @return Vista address para mostrar el formulario (o si ocurre un error), redirige a actionPayment si no hay errores.
     */
    public function actionAddress(){
        $address = $this->facade->getAddress(Yii::app()->user->id);
        $error = null;
        $model = new AddressForm;
        $provinces = AddressForm::getProvinces();

		if(isset($_POST['ajax']) && $_POST['ajax']==='address-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}


		if(isset($_POST['AddressForm']))
		{
			$model->attributes = $_POST['AddressForm'];
			if($model->validate() && $model->saveAddress())
				$this->redirect(array('/order/payment')); 
            else
                $error = "Ha ocurrido un error al introducir la dirección";
		}

		$this->render('address',array('model'=>$model,'address' =>$address,'provinces' => $provinces, "error" => $error));
    }
    
    /**
     * Se ejecuta cuando finaliza la tramitación de un pedido.
     * 
     * @return Vista success para mostrar que el pedido ha finalizado.
     */
    public function actionSuccess(){
    
        $cart = Yii::app()->session["cart"];
        
        //actualizar a pagado
        if(Yii::app()->session["cart"] != null)
             $this->facade->updateToPaid($cart->getOrderID());
        
        //borrar cesta
        Yii::app()->session["cart"] = null;
    
        $this->render('success');
    }
    
    /**
     * Se ejecuta cuando un pedido finaliza de forma errónea.
     * 
     * @return Vista error para mostrar que el pedido ha finalizado incorrectamente.
     */
    public function actionError(){
        
         $cart = Yii::app()->session["cart"];
         if($cart != null){
            $this->facade->updateToError($cart->getOrderID());
         }
        
        $this->render('error');
    }
    
    /**
     * Devuelve todos los pedidos del usuario que se encuentra en sesión.
     * 
     * @return Vista userorders para mostrar los pedidos de un usuario.
     */
    public function actionUserorders(){
        $orders = $this->facade->getOrdersByUser(Yii::app()->user->id);
        $this->render('userorders',array("orders" => $orders));
    }
    
    /**
     * Crea la entidad Order para la tramitación de un pedido. Muestra al usuarios los detalles de un pedido concreto y
     * crea el formulario que permite conectarse con la pasarela de pago.
     * 
     * @return Vista payment para mostrar los detalles de un pedido.
     */
    public function actionPayment(){
         
        $order = new Order();
        $address = $this->facade->getAddress(Yii::app()->user->id);
        $error = null;
        $cart = Yii::app()->session["cart"];
         
        if($cart != null){
            if($cart->getOrderID() == null){
                $orderID = $this->facade->getNextOrderId();
                $order->order_id = $orderID;
                $order->email = Yii::app()->user->id;
                $order->status = "CREATED";
                $order->totalPrice = $cart->getTotalPriceWithShipping();
                $order->creationTime = date('Y-m-d H:i:s');

                $items = $cart->getItems();
                $this->facade->saveOrder($order);

                $orderItems = array();    
                foreach($items as $item){
                    $product = $item->getProduct();
                    $orderItem = new OrderItem();
                    $orderItem->order_id = $orderID;
                    $orderItem->isbn = $product->isbn;
                    $orderItem->units = $item->getUnits();
                    $orderItem->totalPrice = $item->getUnits() * $product->price;
                    $orderItem->save();
                }
                
                 $cart->setOrderID($orderID);
            }

            if($address != null && $cart != null){
                try{
                    $tpv = new Ceca();
                    $tpv->setEntorno();
                    $tpv->setMerchantID(BankData::$MERCHANT_ID);
                    $tpv->setClaveEncriptacion(BankData::$ENCRIPTATION_KEY);
                    $tpv->setAcquirerBIN(BankData::$ACQUIRER_BIN);
                    $tpv->setUrlOk(Yii::app()->getBaseUrl(true) . "/index.php/order/success");
                    $tpv->setUrlNok(Yii::app()->getBaseUrl(true) . "/index.php/order/error");
                    $tpv->setNumOperacion($cart->getOrderID());
                    $tpv->setImporte($cart->getTotalPriceWithShipping());
                    $tpv->setSubmit('orderSubmit','Tramitar pedido');
                    $form = $tpv->create_form();
                }
                catch (Exception $e){   
		    $form = "";
                    $error = "Ha ocurrido un error en el pedido: " . $e->getMessage();
                }

            }else{
                $form = "";
                $error = "Ha ocurrido un error en el pedido";
            }
            
        }else{
	    $form = "";
            $error = "Ha ocurrido un error en el pedido: "  . $e->getMessage();    
        }
           
       $this->render('payment',array('address'=>$address, 'form' =>$form, 'error' => $error));

     }
}