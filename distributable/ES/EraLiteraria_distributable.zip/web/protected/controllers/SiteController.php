<?php

/**
 * Controlador SiteController
 * Encargado de las peticiones del usuario relacionadas con las partes generales de la aplicación.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class SiteController extends Controller
{
    /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column2';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    

	public function actions()
	{
		return array(
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}
    
    /**
     * Muestra la pantalla principal.
     * @return Vista index.
     */
	public function actionIndex()
	{  
        $news = $this->facade->getNewBooksCarousel();
        $comingSoon = $this->facade->getComingSoonCarousel();

		$this->render('index',array('news' => $news, 'comingSoon' => $comingSoon));
	}
    
    /**
     * Muestra el mapa del sitio
     * @return Vista sitemap.
     */
    public function actionSitemap()
	{  
        $categories = $this->facade->getAllCategories();
		$this->render('sitemap',array('categories' => $categories));
	}

    /**
     * Muestra el formulario de contacto.
     * @return Vista contact que muestra el formulario.
     */
	public function actionContact()
	{
		$model=new ContactForm;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];
			if($model->validate())
			{
				Yii::app()->user->setFlash('contact','Gracias por contatar con nosotros. Te contestaremos tan pronto como nos sea posible.');
				$this->refresh();
			}
		}
		$this->render('contact',array('model'=>$model));
	}

}