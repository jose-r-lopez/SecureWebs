<?php

/**
 * Controlador BookController
 * Encargado de las peticiones del usuario relacionadas con los productos de la aplicación.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class BookController extends Controller
{
   /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column2';
    
    /**
     * @var categoryMenu Listado de categorías a mostrar
     */
    public $categoryMenu;
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('categories', 'view', 'news', 'comingsoon', 'publishers'),
                'users' => array('*'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Muestra las novedades.
     * @return Vista news que muestra un listado de libros.
     */
    public function actionNews(){
        $books = $this->facade->getNewBooks();
        $this->render('news', array("books" => $books));
    }
    
     /**
     * Muestra los próximos lanzamientos.
     * @return Vista comingsoon que muestra un listado de libros.
     */
    public function actionComingsoon(){
        $books = $this->facade->getComingSoon();
        $this->render('comingsoon', array("books" => $books));
    }
    
   /**
     * Muestra las editoriales
     * @return Vista publishers que muestra un listado de editoriales
     */
    public function actionPublishers(){
        $publishers = $this->facade->getPublishers();
        $this->render('publishers', array("publishers" => $publishers));
    }
    
    /**
     * Muestra los libros de una categoría. Se debe obtener los hijos de la categoría seleccionada si existen ya qe
     * también se mostrarán los libros que pertenezcan a las categorías hijas.
     * @param string $id Identificador de una categoría
     * @param string $name Nombre de una categoría
     * @return Vista index que muestra los libros de una categoría.
     */
	public function actionCategories($id, $name)
	{
        $this->layout='//layouts/column2';
        $categories = $this->facade->getCategoryByParent($id);
        
        $totalBooks = array();
        $this->categoryMenu = array();
        $url = Yii::app()->createUrl('/');
        array_push($this->categoryMenu,array('label'=>"Todas las categorías", 'url' => $url));
        
         if(count($categories) == 0){
             $category = $this->facade->getCategory($id);
             $parentCategory = $this->facade->getCategory($category->parent_id);
             if($parentCategory != null){
                 $urlLabel = trim($parentCategory->label);
                 $urlLabel = str_replace(' ', '_', $urlLabel);
                $urlLabel = str_replace(chr(46), '', $urlLabel);
                $urlLabel = str_replace(',', '', $urlLabel);
                 $url = Yii::app()->createUrl('book/categories',array('id'=>$parentCategory->category_id, 'name'=>$urlLabel));
                 array_push($this->categoryMenu,array('label'=>$parentCategory->label, 'url'=> $url));
             }
             array_push($this->categoryMenu,array('label'=>$category->label));
             
              $books = $this->facade->getBooksByCategory($id);
                foreach($books as $book){
                    if(isset($book))
                        array_push($totalBooks,$book);
                }
             
         }else{
             
            $parentCategory = $this->facade->getCategory($categories[0]->parent_id);
            if($parentCategory != null){
                array_push($this->categoryMenu,array('label'=>$parentCategory->label));
            }
             
            foreach($categories as $category){
                $urlLabel = trim($category->label);
               
                $urlLabel = str_replace(' ', '_', $urlLabel);
                $urlLabel = str_replace(chr(46), '', $urlLabel);
                $urlLabel = str_replace(',', '', $urlLabel);
                $url = Yii::app()->createUrl('book/categories',array('id'=>$category->category_id, 'name'=>$urlLabel));
                array_push($this->categoryMenu, array('label'=>$category->label, 'url'=> $url));
            }
             
             $books = $this->facade->getBooksByCategory($id);
                foreach($books as $book){
                    if(isset($book))
                        array_push($totalBooks,$book);
                }
    
             
            foreach($categories as $category){
                $books = $this->facade->getBooksByCategory($category->category_id);
                foreach($books as $book){
                    if(isset($book))
                        array_push($totalBooks,$book);
                }
            }
         }
        
        $name = trim($name);
               
                $name = str_replace('_', ' ', $name);
        
		$this->render('index', array(
            "books" => $totalBooks, "category" =>$name));
	}
    
    /**
     * Muestra los datos de un libro.
     * @param string $id Identificador de un libro
     * @return Vista view que muestra los datos de un libro.
     */
    public function actionView($id){
        
        $this->layout='//layouts/column1';
        $submenu = null;
        $error = null;
        
        if(Yii::app()->session["errorConfirm"] != null){
            $error = Yii::app()->session["errorConfirm"];
            Yii::app()->session["errorConfirm"] = null;
        }

        $book = $this->facade->getBook($id);
        if($book != null){
            $category = $this->facade->getCategory($book->category_id);
            $reviews = $this->facade->getReviewsByIsbn($id);

            $urlLabel = trim($category->label);
            $urlLabel = str_replace(' ', '_', $urlLabel);
            $urlLabel = str_replace(chr(46), '', $urlLabel);
            $urlLabel = str_replace(',', '', $urlLabel);

            $this->render('view', array(
                "book" => $book, 'reviews' => $reviews, "categoryName" => $category->label, "urlName" => $urlLabel, "categoryID" => $category->category_id, "error" => $error));
        }else{
            throw new CHttpException(404,'Libro no encontrado.');
        }
    }
}