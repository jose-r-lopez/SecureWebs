<?php

/**
 * Controlador AccountController
 * Encargado de las peticiones del usuario relacionadas con su cuenta.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class AccountController extends Controller
{
     /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column1';
    
     /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('login','register'),
                'users' => array('*'),
            ),
            
            array('allow', 
                'actions' => array('logout','index','modifypassword','modifyname','modifyaddress'),
                'users' => array('@'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }

    /**
     * Permite el inicio de sesión.
     * 
     * @return Vista Login para mostrar el formulario (o si ocurre un error), pantalla principal si se inicia sesión correctamente.
     */
	public function actionLogin()
	{
        $model = new LoginForm;
        $error = null;
        $registerResult = null;
        
        if(Yii::app()->session["registerResult"] != null){
            $registerResult = Yii::app()->session["registerResult"];
            Yii::app()->session["registerResult"] = null;
        }
        
		
		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['LoginForm']))
		{
			$model->attributes = $_POST['LoginForm'];
			if($model->validate() && $model->login()){
				$this->redirect(array('/'));
            }else{
                $error = Yii::app()->session["loginError"];
                Yii::app()->session["loginError"] = null;
            }
		}
		// display the login form
		$this->render('login',array('model'=>$model, 'error' => $error, 'registerResult' => $registerResult));
	}
    
    /**
     * Permite el registro de usuarios.
     * 
     * @return Vista Register para mostar el formulario (o si ocurre un error), pantalla anterior si se logra el registro.
     */
    public function actionRegister()
	{
		$model = new RegisterForm;
        $error = null;

		if(isset($_POST['ajax']) && $_POST['ajax']==='register-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}


		if(isset($_POST['RegisterForm']))
		{
			$model->attributes = $_POST['RegisterForm'];
			if($model->validate() && $model->register()){
                Yii::app()->session["registerResult"] = "Registro correcto"; 
                $this->redirect("login");
            }else{
                $error =  Yii::app()->session["registerError"]; 
                 Yii::app()->session["registerError"] = null;
            }
		}

		$this->render('register',array('model'=>$model, 'error' => $error));
	}
    
    /**
     * Permite ver la cuenta del usuario.
     * 
     * @return Vista Index.
     */
    public function actionIndex(){
        $success = null;
        if(Yii::app()->session["success"] != null){
            $success = Yii::app()->session["success"];
            Yii::app()->session["success"] = null;
        }
        $this->render('index', array('success' => $success));
    }
    
    /**
     * Permite modificar la contraseña de un usuario.
     * 
     * @return Vista modifypassword para mostrar el formulario (o si ocurre un error), redirige a actionIndex si se cambia correctamente.
     */
    public function actionModifypassword(){
        
        $model = new ChangePassForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='change-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['ChangePassForm']))
		{
			$model->attributes = $_POST['ChangePassForm'];
			if($model->validate() && $model->changePassword()){
               Yii::app()->session["success"] = "Contraseña cambiada con éxito";
               $this->redirect(array('/account/')); 
            }
		}
        
        $this->render('modifypassword',array('model'=>$model));
    }
    
    /**
     * Permite modificar el nombre del usuario.
     * 
     * @return Vista modifyname para mostrar el formulario (o si ocurre un error), redirige a actionIndex si se cambia correctamente.
     */
    public function actionModifyname(){
        
        $name = $this->facade->getUserName();
        $error = null;
        if(isset($_POST['name']))
		{
            if($this->validateName($_POST['name'])){
                $this->facade->updateUserName(Yii::app()->user->id,$_POST['name']);
                Yii::app()->user->setName($_POST['name']);
                Yii::app()->session["success"] = "Nombre cambiado con éxito";
                $this->redirect(array('/account/')); 
            }else{
                $error = "Nombre no válido";
            }
        }
        
        
        $this->render('modifyname', array('name' => $name, 'error' => $error));
    }
    

    /**
     * Permite modificar la dirección de envío.
     * 
     * @return Vista modifyaddress para mostrar el formulario (o si ocurre un error), redirige a actionIndex si se cambia correctamente.
     */
    public function actionModifyaddress(){
    
        $provinces = AddressForm::getProvinces();
        
        $model = new AddressForm;
        $oldAddress = $this->facade->getAddress(Yii::app()->user->id);
        $model->address = $oldAddress['address'];
	    $model->postCode = $oldAddress['postCode'];
        $model->city = $oldAddress['city'];
        $model->province = $oldAddress['province'];

		if(isset($_POST['ajax']) && $_POST['ajax']==='address-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['AddressForm']))
		{
			$model->attributes = $_POST['AddressForm'];
			if($model->validate() && $model->saveAddress()){
                Yii::app()->session["success"] = "Dirección cambiada con éxito";
				$this->redirect(array('/account/'));
            }
		}
        $this->render('modifyaddress',array('model'=>$model,'provinces' => $provinces));
    }
    
    /**
     * Permite salir de sesión.
     * 
     * @return Vista anterior.
     */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		$this->redirect(Yii::app()->homeUrl);
	}
    

    private function validateName($name){
        if (strcmp($name, "") === 0){
            return false;
        } 

        if (strlen($name) > 99){
            return false;
        }

        return true;
    }
}