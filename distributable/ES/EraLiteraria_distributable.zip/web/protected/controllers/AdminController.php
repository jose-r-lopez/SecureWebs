<?php

/**
 * Controlador AdminController
 * Encargado de las peticiones del usuario relacionadas con el panel de administrador
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class AdminController extends Controller
{
    /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column1Admin';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
     

     public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }
    
    public function init(){
        $this->facade = new PersistenceFacade();
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('index','products','orders','users', 'categories','addProduct','editProduct','deleteProduct', 'addCategory','deleteCategory','editCategory','deleteUser' , 'addUser','deleteOrder','showOrder','changeOrder','error'),
                'roles'=>array('admin'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Indica que la primera pantalla del panel de administración es la lista de productos.
     * @return Redirige a actionProducts.
     */
    public function actionIndex(){
        $this->redirect(Yii::app()->createUrl("/admin/products"));
    }
    
    /**
     * Muestra el listado de productos de la aplicación.
     * @return Vista products que muestra el listado de productos.
     */
    public function actionProducts(){
        $error = $this->getErrorMsg();
        $books = $this->facade->getBooks();
        
        $this->render("products", array("books" => $books, "error" => $error));
    }
    
   /**
     * Muestra el listado de categorías de la aplicación.
     * @return Vista categories que muestra el listado de categorías.
     */
    public function actionCategories(){
        $error = $this->getErrorMsg();
        $categories = $this->facade->getCategories();
        $this->render("categories",array("categories" => $categories, "error" => $error));
    }
    
    /**
     * Muestra el listado de pedidos de la aplicación.
     * @return Vista orders que muestra el listado de pedidos.
     */
    public function actionOrders(){
        $error = $this->getErrorMsg();
        $orders = $this->facade->getOrders();
        $this->render("orders",array("orders" => $orders, "error" => $error));
    }
    
     /**
     * Muestra el listado de usuarios de la aplicación.
     * @return Vista users que muestra el listado de usuarios.
     */
    public function actionUsers(){
        $error = $this->getErrorMsg();
        $users = $this->facade->getUsers();
        $this->render("users",array("users" => $users, "error" => $error));
    }
    
    /**
     * Añade un libro.
     * @return Vista addProduct para mostrar el formulario para añadir un libro (o si ocurre un error), redirige a actionProducts si se añade correctamente.
     */
    public function actionAddProduct(){
        $model = new BookForm;
        $categories = $this->facade->getCategories();
        $error = null;
		if(isset($_POST['ajax']) && $_POST['ajax']==='add-product-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['BookForm']))
		{
			$model->attributes = $_POST['BookForm'];
			if($model->validate() && $model->createBook())
				$this->redirect(array('/admin/products'));
            else
                $error = "Ha habido un error al crear el producto";
		}
        
        $this->render("addProduct",array("model" => $model, "categories" => $categories, "error" => $error));
    }
    
    /**
     * Añade una categoría.
     * @return Vista addCategory para mostrar el formulario para añadir una categoría (o si ocurre un error), redirige a actionCategories si se añade correctamente.
     */
    public function actionAddCategory(){
        
        $model = new CategoryForm;
        $categories = $this->facade->getAllCategories();
        $error = null;
		if(isset($_POST['ajax']) && $_POST['ajax']==='add-category-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['CategoryForm']))
		{
			$model->attributes = $_POST['CategoryForm'];
			if($model->validate() && $model->createCategory())
				$this->redirect(array('/admin/categories'));
            else
                $error = "Ha habido un error al crear la categoría";
		}
        
        $this->render("addCategory",array("model" => $model, "categories" => $categories, "error" => $error));
    }
    
    /**
     * Borra una categoría
     * @param string $id Identificador de la categoría
     * @return Redirige a actionCategories.
     */
    public function actionDeleteCategory($id){
        $books = $this->facade->getBooksByCategory($id);
        $category = $this->facade->getCategory($id);
        if($category != null && $books == null){
            $this->facade->deleteCategory($id);
        }else{
            Yii::app()->session["error"] = "Ha habido un error al borrar la categoría";
        }
        
        $this->redirect(array('/admin/categories'));
    }
    
    /**
     * Edita una categoría.
     * @param string $id Identificador de la categoría
     * @return Vista editCategory para mostrar el formulario (o si ocurre un error), redirige a actionCategories si se a editado correctamente.
     */
    public function actionEditCategory($id){

        $error = null;
        $category = $this->facade->getCategory($id);
        $categories = $this->facade->getAllCategories();
        
        $model = new CategoryForm;
        $model->label = $category->label;
        $model->parentCategory = $category->parent_id;
        $model->categoryID = $category->category_id;
        
		if(isset($_POST['ajax']) && $_POST['ajax']==='edit-category-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['CategoryForm']))
		{
			$model->attributes = $_POST['CategoryForm'];
			if($model->validate() && $model->editCategory())
				$this->redirect(array('/admin/categories'));
            else
                $error = "Ha habido un error al editar la categoría";
		}
        
        $this->render("editCategory",array("model" => $model, "categories" => $categories, "category" => $category, "error" => $error));
    }
    
    /**
     * Edita un libro
     * @param string $id Identificador de un libro
     * @return Vista editProduct para mostrar el formulario (o si ocurre un error), redirige a actionProducts si se edita correctamente.
     */
    public function actionEditProduct($id){
        
        $error = null;
        $model = new BookForm;

        $categories = $this->facade->getCategories();
        $book = $this->facade->getBook($id);
        
        $model->isbn = $book->isbn;
        $model->name = $book->name;
        $model->author = $book->author;
        $model->publisher = $book->publisher;
        $model->price = $book->price;
        $model->stock = $book->stock;
        $model->cover = $book->cover;
        $model->pages = $book->pages;
        $model->year = $book->year;
        $model->description = $book->description;
        $model->format = $book->format;
        $model->language = $book->language;
        $model->category_id = $book->category_id;
        $model->upload_Date =  $book->upload_Date;

		if(isset($_POST['ajax']) && $_POST['ajax']==='edit-product-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['BookForm']))
		{
			$model->attributes = $_POST['BookForm'];
			if($model->validate() && $model->editBook())
				$this->redirect(array('/admin/products'));
            else
                $error = "Ha habido un error al editar el libro";
		}

        $this->render("editProduct",array("model" => $model, "categories" => $categories, "error" => $error));
    }
    
    /**
     * Borra un libro.
     * @param string $id Identificador de un libro
     * @return Redirige a actionProducts.
     */
    public function actionDeleteProduct($id){
     
        $book = $this->facade->getBook($id);
        $orders = $this->facade->getOrdersByProduct($id);
        $reviews = $this->facade->getReviewsByIsbn($id);
        
        if($book != null && $orders == null && $reviews == null){
            $this->facade->deleteBook($id);
        }else{
             Yii::app()->session["error"] = "Ha habido un error al borrar el producto";
        }

        $this->redirect(array('/admin/products'));
    }
    
    /**
     * Borra un usuario.
     * @return Redirige a actionUsers.
     */
    public function actionDeleteUser(){
        
        if(isset($_POST['id']) && !empty($_POST['id']))
		{
            $id = $_POST['id'];
            $user = $this->facade->getUser($id);
            $address = $this->facade->getAddress($id);
            $orders = $this->facade->getOrdersByUser($id);
            $reviews = $this->facade->getReviewByEmail($id);
            
            if($user != null && $address == null && $orders == null && $reviews == null){
                $this->facade->deleteUser($id);
            }else{
                Yii::app()->session["error"] = "Ha habido un error al borrar al usuario";
            }
        }
       
     
        $this->redirect(array('/admin/users'));
    }
    
    /**
     * Añade un usuario.
     * @return Vista addUser para mostrar el formulario (o si ocurre un error), redirige a actionUsers si se añade correctamente.
     */
    public function actionAddUser(){
        $model = new UserForm;
        $error = null;
		if(isset($_POST['ajax']) && $_POST['ajax']==='add-user-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['UserForm']))
		{
			$model->attributes = $_POST['UserForm'];
			if($model->validate() && $model->addUser())
                 $this->redirect(array('/admin/users'));
            else
                $error = "Ha habido un error al crear un usuario";
		}
        
        $this->render("addUser",array("model" => $model, "error" => $error));

    }
    
    /**
     * Borra un pedido.
     * @param string $id Identificador de un pedido
     * @return Redirige a actionOrders.
     */
    public function actionDeleteOrder($id){
        $order = $this->facade->getOrder($id);
        if($order != null){
            $this->facade->deleteOrder($id);
        }else{
             Yii::app()->session["error"] = "Ha habido un error al borrar el pedido";
        }
        
        $this->redirect(array('/admin/orders'));
    }
    
    /**
     * Muestra los datos de un pedido.
     * @param string $id Identificador de un pedido
     * @return Vista showOrder que muestra los datos de un pedido, redirige a actionOrders si ocurre un error con el pedido seleccionado.
     */
    public function actionShowOrder($id){
        $order = $this->facade->getOrder($id);
        if($order != null){
             $this->render("showOrder",array("order" => $order));
        }else{
            Yii::app()->session["error"] = "El pedido no existe";
            $this->redirect(array('/admin/orders'));
        }
    }
    
    /**
     * Cambia el estado de un pedido.
     * @param string $param Estado del pedido
     * @param string $id Identificador de un pedido
     * @return Redirige a actionShowOrder
     */
    public function actionchangeOrder($param, $id){
        $order = $this->facade->getOrder($id);
        if($order != null){
            if(strcmp($param,"created") === 0){
                $this->facade->updateToCreated($id);
            }else if(strcmp($param,"paid") === 0){
                $this->facade->updateToPaid($id);
            }else if(strcmp($param,"sent") === 0){
                $this->facade->updateToSent($id);
            }else{
                $this->facade->updateToError($id);
            }
        }
        $this->redirect(array('/admin/showOrder', 'id'=>$id));
    }
    
    private function getErrorMsg(){
        if(Yii::app()->session["error"] != null){
            $error = Yii::app()->session["error"];
            Yii::app()->session["error"] = null;
            return $error;
        }
        
        return null;
    }
    
}