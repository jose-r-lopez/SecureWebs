<?php

/**
 * Controlador ShoppingCartController
 * Encargado de las peticiones del usuario relacionadas con su cesta de la compra
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class ShoppingCartController extends Controller
{
    /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column1';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('index', 'add', 'delete','update', 'confirm'),
                'users' => array('*'),
            ),

            array('deny', 
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Muestra la cesta de la compra.
     * @return Vista index que muestra el contenido de la cesta de la compra.
     */
    public function actionIndex(){
        $this->render('index');
    }
    
    /**
     * Añade un libro a la cesta de la compra, si ya estaba dentro de ella se actualizan las unidades.
     * @param string $id Identificador del libro a añadir.
     * @return Redirige a actionConfirm
     */
	public function actionAdd($id){
      
        $item = $this->facade->getBook($id);
        $error = null;
        if($item != null){
            $cart = $this->getShoppingCart();
            //si tiene stock
             if($item->stock > 0){
                 //si ya existe en el carrito
                 if($cart->existsItem($item->isbn)){
                    $cart->addOneMore($item);
                 }else{
                    $cart->addToShoppingCart($item);
                 }
             }else{
                    Yii::app()->session["errorConfirm"] = "Ha ocurrido un error al agregar el libro a la cesta";
             }
        }else{
             Yii::app()->session["errorConfirm"] = "Ha ocurrido un error al agregar el libro a la cesta";
        }
        
       $this->redirect(array("/shoppingCart/confirm", "id" => $id)); 
    }
    
    /**
     * Muestra una pantalla de confirmación que indica que el libro ha sido añadido.
     * @param string $id Identificador del libro añadido.
     * @return Vista add que muestra una confirmación de la inserción, vista error si ocurre un error.
     */
    public function actionConfirm($id){

        $item = $this->facade->getBook($id);
        
        if($item == null){
            Yii::app()->session["errorConfirm"] = "Ha ocurrido un error al agregar el libro a la cesta";
             $this->redirect(array("/shoppingCart/index"));
        }else{
            $category = $this->facade->getCategory($item->category_id);
            if($category == null){
                 Yii::app()->session["errorConfirm"] = "Ha ocurrido un error al agregar el libro a la cesta";
                 $this->redirect(array("/shoppingCart/index"));
            }else{
                $this->render('add', array("item" => $item, "categorylabel" => $category->label));
            }
        }
        
       
    }
    
    /**
     * Borra un libro de la cesta de la compra.Función AJAX.
     * @param string $id Identificador de un libro
     * @return Precio total y número de items actualizados.
     */
    public function actionDelete($id){
        $cart = $this->getShoppingCart();
        if($cart->existsItem($id)){
            $cart->removeItemShoppingCart($id);
        }
        
        $data = array();
        $data["total"] = $cart->getTotalPrice();
        $data["units"] = $cart->getNumberOfItems();
        $data["totalShipping"] = $cart->getTotalPriceWithShipping();
        $data["isbn"] = $id;
        exit(json_encode($data));
    }
    
    /**
     * Actualiza las unidades de un libro de la cesta. Función AJAX.
     * @param string $id Identificador de un libro
     * @return Precio total y número de items actualizados.
     */
    public function actionUpdate($id){
        if(!empty($_POST["units"])){
            $units = $_POST["units"];
            if($units >= 1){
                $cart = $this->getShoppingCart();
                if($cart->existsItem($id)){
                    $cart->updateShoppingCart($cart->getProduct($id), $units);
                }
            }
        }
        
        $cart = $this->getShoppingCart();
        $data = array();
        $data["total"] = $cart->getTotalPrice();
        $data["units"] = $cart->getNumberOfItems();
        $data["totalShipping"] = $cart->getTotalPriceWithShipping();
        
         exit(json_encode($data));
    }
    
    private function getShoppingCart(){
        
        if(!isset(Yii::app()->session["cart"]))
		{
            $cart = new ShoppingCart();
			Yii::app()->session["cart"] = $cart;
		}else{
		   $cart = Yii::app()->session["cart"];
        }
        
        return $cart;
    }
}