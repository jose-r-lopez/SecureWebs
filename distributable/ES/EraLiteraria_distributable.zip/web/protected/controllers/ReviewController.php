<?php

/**
 * Controlador ReviewController
 * Encargado de las peticiones del usuario relacionadas con las críticas sobre los libros.
 * 
 * @author Leticia del Valle Varela
 * @version 0.1
 * @package application.controllers
 */
class ReviewController extends Controller
{
     /**
     * @var layout Tipo de layout usado en las vistas
     */
    public $layout='//layouts/column1';
    
    /**
     * @var facade Fachada para acceder a la capa de persistencia
     */
    private $facade;
    
    public function init()
    {
        $this->facade = new PersistenceFacade();
    }
    

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    public function accessRules()
    {
        return array(

            array('allow', 
                'actions' => array('create'),
                'users' => array('@'),
            ),

            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }
    
   /**
    * Crea una crítica de un libro.
    * @param string $id Identificador de un libro.
    * @return Vista userorders para mostrar el formulario(o si ocurre un error), redirige al action view de BookController si se crea con éxito.
    */
   public function actionCreate($id){
       
       $book = $this->facade->getBook($id);
       $error = null;
       $model = new ReviewForm;
		if(isset($_POST['ajax']) && $_POST['ajax']==='create-review-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		if(isset($_POST['ReviewForm']))
		{
			$model->attributes = $_POST['ReviewForm'];
			if($model->validate() && $model->createReview($id))
				$this->redirect(array('/book/view', "id" => $id));
            else
                $error = "Ha habido un error al crear la crítica. ";
                
		}

       $category = $this->facade->getCategory($book->category_id);
       
       if(Yii::app()->session["error"] != null){
            $error .= Yii::app()->session["error"];
            Yii::app()->session["error"] = null;
       }
           
           
       $this->render("create", array("model" => $model, "book" => $book, 'error' => $error, "categorylabel" => $category->label));
   }


}