<?php

/**
 * This behavior adds layout-related functions to the application
 */
class LayoutBehavior extends CBehavior
{

  /**
   * @return Menu configured Menu Widget for the top menu
   */
  public function getMenu()
  {
    static $menu;

    if (!isset($menu)) {
        $categoryPersistence = new CategoryPersistence();
        $categories = $categoryPersistence->getAllCategories();

        $menu = array();

        foreach($categories as $category){
            $urlLabel = trim($category->label);
            $urlLabel = str_replace(' ', '_', $urlLabel);
            $urlLabel = str_replace(chr(46), '', $urlLabel);
            $urlLabel = str_replace(',', '', $urlLabel);
            $url = Yii::app()->createUrl('book/categories',array('id'=>$category->category_id, 'name'=>$urlLabel));
            array_push($menu, array('label'=>$category->label, 'url'=>$url));
        }
        
    }   
    
    return $menu;
  }
  
    public function getSearchModel(){
        return new SearchForm();
    }
}