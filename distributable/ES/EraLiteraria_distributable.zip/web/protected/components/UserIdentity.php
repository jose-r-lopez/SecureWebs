<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{

	public function authenticate()
	{
		$authorizer=Yii::app()->authManager;
		 
		$this->errorCode=self::ERROR_PASSWORD_INVALID;
        
        $userPersistence = new UserPersistence();     
        $user =  $userPersistence->getUser($this->username);
        
        if($user == null){
            return false;
        }else{
            //se comprueba la contraseña
            $saltedPW =  $this->password . $user->salt;
            $hashedPW = hash('sha256', $saltedPW);
            if(strcmp($user->pass, $hashedPW) === 0) {
                $this->errorCode=self::ERROR_NONE;
                $this->setState('id', $user->email);  
                $this->username = $user->name;
                if(strcmp($user->role,'admin') === 0){
                    if (!$authorizer->isAssigned($user->role,$user->email)){
                        $authorizer->assign($user->role, $user->email);
                        $authorizer->save();
                    }
                }
                return true;
            }else{				
                return false;
            }
        }   
	}
    
     public function getId() {
		return  $this->getState('id');
	}
    
    
    public function checkUser(){
        $authorizer=Yii::app()->authManager;
        
        $userPersistence = new UserPersistence();     
        $user = $userPersistence->getUser($this->username);
        
        if($user == null){
            return false;
        }else
            return true;
    }
    
}