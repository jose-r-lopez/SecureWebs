<?php


class WebUser extends CWebUser {

    public function userLogin($identity,$duration=0)
	{
		$id=$identity->getId();
		$states=$identity->getPersistentStates();
		
		$this->changeuserIdentity($id,$identity->getName(),$states);

		if ($this->absoluteAuthTimeout)
			$this->setState($this::AUTH_ABSOLUTE_TIMEOUT_VAR, time()+$this->absoluteAuthTimeout);

		return !$this->getIsGuest();
	}

    
    
    public function changeuserIdentity($id,$name,$states)
	{
		//Yii::app()->getSession()->regenerateID(true);
		$this->setId($id);
		$this->setName($name);
		$this->loadIdentityStates($states);
	}

}