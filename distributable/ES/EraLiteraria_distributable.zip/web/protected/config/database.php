<?php

// This is the database connection configuration.
return array(
	'connectionString' => 'mysql:host=localhost;dbname=eralit',
	'emulatePrepare' => true,
	'username' => 'root',
	'password' => 'test123...',
	'charset' => 'utf8',
	
);
